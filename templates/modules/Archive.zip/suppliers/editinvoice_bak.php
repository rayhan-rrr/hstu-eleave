<?php

 use App\Helper\Includes\NumberToWord;
 use App\Helper\Includes\BanglaConverter;

include $this->getTemplatePath().'php_includes/db_conx.php';

 $hasSuccess = '';

  if (isset($_SESSION['success'])) {
      
      $_Success = $_SESSION['success'];

      $_SESSION['success'] = '';
    }

  if (isset($_SESSION['error'])) {
      
      $_Error = $_SESSION['error'];

      $_SESSION['error'] = '';
    }

  if (isset($_SESSION['msg'])) {
    
    $_Message = $_SESSION['msg'];

    $_SESSION['msg'] = '';
  }

    
?>


<?php
if ($auth['user']->img!="") {
    $usrimg = 'profileimg/'.$auth['user']->img;
  } else {
    $usrimg = 'dist/img/avatar.png';
  }
?>
 

<!DOCTYPE html>
<html>
<head>
  
<? print $this->fetch('/ui_includes/head.phtml'); ?>

    <!-- autocomplete -->
    <link rel="stylesheet" href="<? echo $baseUrl ?>dist/css/easy-autocomplete.css">
    <!-- autocomplete -->
      <link rel="stylesheet" href="<? echo $baseUrl ?>dist/css/easy-autocomplete.themes.css">
      <!-- Select2 -->
<link rel="stylesheet" href="<?php echo htmlspecialchars($baseUrl); ?>plugins/select2/select2.min.css">
<!-- DataTables -->
  <link rel="stylesheet" href="<?php echo htmlspecialchars($baseUrl); ?>plugins/datatables/dataTables.bootstrap.css">

<!-- iCheck for checkboxes and radio inputs -->
  <link rel="stylesheet" href="<?php echo htmlspecialchars($baseUrl); ?>plugins/iCheck/all.css">

<!-- jQuery Confirmation -->
  <link rel="stylesheet" href="<?php echo htmlspecialchars($baseUrl); ?>dist/css/jquery-confirm.min.css">

    
<style type="text/css">

  .serial_range, .withinRange, .individual, .combined{
    display: none;
  }

</style>


 <!-- angular -->
  <script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/angular/angular.min.js"></script>

  <!-- angular animate -->
  <script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/angular/angular-animate.min.js"></script>

  <!-- angular animate bootstrap -->
  <script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/angular/ui-bootstrap-tpls.min.js"></script>


</head>
<body class="hold-transition skin-blue sidebar-mini">
<!-- --mod: menu wrapper custom end -->
  <? print $this->fetch('/ui_includes/main_navigation.phtml'); ?>
  <!-- --mod: menu wrapper custom end -->
  
  <div class="wrapper page-wrapper">

    <header class="main-header">
      <? print $this->fetch('/ui_includes/header.phtml'); ?>
    </header>
    <!-- Left side column. contains the logo and sidebar -->
    <?// print $this->fetch('/ui_includes/leftpanel.phtml'); ?>

    <!-- Content Wrapper. Contains page content -->
   <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    


    <!-- Main content -->
    <section class="content" ng-app="addSerials">
      <div class="row" id="controllerid" ng-controller="addSerialsController">
      
        <div class="col-md-12">
          <!-- here -->

            <!-- Horizontal Form -->
          <div class="box box-solid box-default">
            <div class="box-header with-border">
              <h3 class="box-title">Create New Purchase</h3>

            </div>
            <!-- /.box-header -->
            <!-- form start -->

            <input type="hidden"  name="formfor" value="addto">
            
              <div class="box-body">


              <!-- here start -->
              <div class="col-md-12">

                <!-- supplier information box -->
                <div class="box-body">

                  <div class="col-md-6">
                    <div class="form-group <? if(isset($errors['supplier'])) echo 'has-error' ?>">
                      <label for="supplier" class="col-sm-3 control-label">Supplier Name</label>

                      <div class="col-sm-8">
                        <select name="supplier" id="supplier" required class="form-control supplier select2" style="width: 100%;">
                                
                          <option value="">Select Supplier</option>
                          <?php
                          $sql = "SELECT * FROM `suppliers` WHERE `active`=1;";
                          $result = mysqli_query($db_conx,$sql );
                          $total_cat = mysqli_num_rows($result);
                          if($total_cat>0){
                            while($row = mysqli_fetch_array($result)){
                              echo "<option value=".$row['id'].">".$row['name']."</option>";
                            }
                          }
                          ?>
                        </select>
                      
                        <? if(isset($errors['supplier'])) { ?>
                        <span class="help-block"><? echo $errors['supplier'][0]; ?></span>

                        <? } ?>
                      </div>

                    </div>
                    <div class="col-md-12">
                      
                      <p class="col-md-6">Address: <span id="sup_addr"></span></p>
                      <p class="col-md-6">Balance: <span id="sup_balance"></span></p>

                    </div>
                    <div class="form-group <? if(isset($errors['remarks'])) echo 'has-error' ?>">
                      <label for="remarks" class="col-sm-3 control-label">Remarks</label>

                      <div class="col-sm-8">
                        <input name="remarks" type="text" class="form-control" id="invremarks" placeholder="Enter Remarks" autocomplete="off" value="<? if(isset($old['remarks'])) echo $old['remarks']; ?>">
                      
                        <? if(isset($errors['remarksSup'])) { ?>
                        <span class="help-block"><? echo $errors['remarks'][0]; ?></span>

                        <? } ?>
                      </div>

                    </div>
                  </div>

                  <div class="col-md-6">
                    
                    <div class="form-group <? if(isset($errors['invoice'])) echo 'has-error' ?> col-md-12">
                      <label for="invoice" class="col-sm-4 control-label">Invoice Number</label>

                      <div class="col-sm-8">
                        <input name="invoice" type="text" class="form-control" id="invoice" placeholder="Enter Invoice Number" autocomplete="off" value="<? if(isset($old['invoice'])) echo $old['invoice']; ?>" required>
                      
                        <? if(isset($errors['invoice'])) { ?>
                        <span class="help-block"><? echo $errors['invoice'][0]; ?></span>

                        <? } ?>
                      </div>

                    </div>
                    <br>

                    <div class="form-group <? if(isset($errors['invoice_date'])) echo 'has-error' ?> col-md-12">
                      <label for="datepicker" class="col-sm-4 control-label">Invoice Date</label>

                      <div class="col-sm-8">
                        
                        <div class="input-group date">
                          <div class="input-group-addon">
                            <i class="fa fa-calendar"></i>
                          </div>
                          <input type="text" name="invoice_date" class="form-control pull-right" id="datepicker" autocomplete="off">
                        </div>
                      
                        <? if(isset($errors['invoice_date'])) { ?>
                        <span class="help-block"><? echo $errors['invoice_date'][0]; ?></span>

                        <? } ?>
                      </div>

                    </div>
                    

                  </div>
                </div>
                <!-- supplier information box end -->

                <!-- tabs start -->
                <div class="col-md-12">

                  <div class="col-md-6">
                    <!-- Custom Tabs -->
                    <div class="nav-tabs-custom">
                      <ul class="nav nav-tabs">
                        <li class="active"><a href="#tab_1" data-toggle="tab" aria-expanded="true">Easy</a></li>
                        <li class=""><a href="#tab_2" data-toggle="tab" aria-expanded="false">Navigational</a></li>
                        
                        
                      </ul>
                      <div class="tab-content">
                        <div class="tab-pane active" id="tab_1">
                          <div class="">
                           
                            <!-- /.box-header -->
                            <!-- form start -->
                              <div class="box-body">
                                <div class="form-group col-md-12">
                                  <label for="productmodel" class="col-sm-3 control-label">Model No</label>

                                  <div class="col-sm-9">
                                    <input type="text" class="form-control" id="productmodel">
                                  </div>
                                  <input type="hidden"  name="productid" id="productid">
                                </div>

                                <div class="form-group col-md-12">
                                  <label for="productcode" class="col-sm-3 control-label">Code</label>

                                  <div class="col-sm-9">
                                    <input type="text" class="form-control" id="productcode">
                                  </div>
                                </div>
                                <div class="form-group col-md-12">
                                  
                                  <p class="col-sm-9 control-label pull-right">
                                    <b>Brand: </b> <span id="productbrand"></span> | <b> Group: </b> <span id="productgroup"></span> | <b>In Stock:</b> <span id="availableqty"></span>
                                  </p>

                                </div>


                                <!-- buyrate -->
                                <div class="form-group col-md-12">
                                  <label for="productprice" class="col-sm-3 control-label">Buying Cost</label>

                                  <div class="col-sm-9">
                                    <input class="form-control" id="productprice">
                                  </div>
                                </div>

                                <div class="form-group col-md-12">
                                  <label for="productwholesale" class="col-sm-3 control-label">Wholesale Price</label>

                                  <div class="col-sm-9">
                                    <input type="text" class="form-control" id="productwholesale">
                                    
                                  </div>
                                </div>
                                <div class="form-group col-md-12">
                                  <label for="productsellprice" class="col-sm-3 control-label">Retail Price</label>

                                  <div class="col-sm-9">
                                    <input type="text" class="form-control" id="productsellprice">
                                  </div>
                                </div>
                                <div class="form-group col-md-12">
                                  <label for="productqty" class="col-sm-3 control-label">Purchased Quantity</label>

                                  <div class="col-sm-9">
                                    <input type="text" class="form-control" id="productqty" placeholder="Quantity">
                                  </div>
                                  <p class="col-sm-9 control-label pull-right"><b>Total Cost: </b> <span id="totalcost"></span></p>
                                </div>
                                

                              </div>
                              <!-- /.box-body -->
                              
                              <div class="box-footer">
                                <button class="btn btn-danger pull-left" id="cleareasy" onclick="clearfields()">Clear</button>
                                <button class="btn btn-success pull-right" id="addeasy" disabled="disabled">Add to Invoice</button>
                              </div>
                              <!-- /.box-footer -->

                          </div>
                        </div>
                        <!-- /.tab-pane -->
                        <div class="tab-pane" id="tab_2">
                          <div class="">
                            
                            <!-- /.box-header -->
                            <!-- form start -->

                              <div class="box-body">
                                <!-- category -->
                                <div class="form-group col-md-12" id="categoryf">
                                  <label for="procategory" class="col-sm-3 control-label">Category</label>
                                  <div class="col-sm-9">
                                    <select name="category" id="procategory" class="form-control select2 procategory" style="width: 100%;">
                                      <option value="">Please Select</option>
                                      <?php 

                                      $sql = "SELECT * FROM `category` WHERE `active`=1;";
                                    $result = mysqli_query($db_conx,$sql );
                                    $total_cat = mysqli_num_rows($result);
                                    if($total_cat>0){
                                      
                                      while($row = mysqli_fetch_array($result)){
                                        echo "<option value=".$row['id'].">".$row['name']."</option>";
                                        }
                                      }
                                       ?>
                                      
                                    </select>
                                  </div>
                                </div>

                                <!-- brand -->
                                <div class="form-group col-md-12" id="brandf">
                                  <label for="probrand" class="col-sm-3 control-label">Brand</label>
                                  <div class="col-sm-9">
                                    <select name="probrand" id="probrand" class="form-control probrand select2" style="width: 100%;">
                                      <option value="">Please Select</option>
                                      <?php 

                                    $sql = "SELECT * FROM `brands` WHERE `active`=1;";
                                    $result = mysqli_query($db_conx,$sql );
                                    $total_cat = mysqli_num_rows($result);
                                    if($total_cat>0){
                                      
                                      while($row = mysqli_fetch_array($result)){
                                        echo "<option value=".$row['id'].">".$row['name']."</option>";
                                        }
                                      }
                                       ?>
                                      
                                    </select>
                                  </div>
                                </div>

                                <!-- group -->
                                <div class="form-group col-md-12">
                                  <label for="probrand" class="col-sm-3 control-label">Group</label>
                                  <div class="col-sm-9">
                                    <select name="progroup" id="progroup" class="form-control progroup select2" style="width: 100%;">
                                      <option value="">Select Category First</option>
                                      

                                      
                                    </select>
                                  </div>
                                </div>

                                <!-- product name -->
                                <!-- brand -->
                                <div class="form-group col-md-12">
                                  <label for="promodel" class="col-sm-3 control-label">Model No</label>
                                  <div class="col-sm-9">
                                    <select name="promodel" id="promodel" class="form-control promodel select2" style="width: 100%;">
                                      
                                      <option value="">Select Category, Brand First</option>
                                      
                                    </select>
                                  </div>
                                  <input type="hidden"  name="productid" id="productid">
                                </div>

                                <div class="form-group col-md-12">

                                  <p class="col-sm-9 control-label pull-right">
                                    <b>Code: </b> <span id="procode"></span> | <b>In Stock:</b> <span id="proavailableqty"></span>
                                  </p>
                                </div>
                                
                                <!-- buy rate -->

                                <div class="form-group col-md-12">
                                  <label for="proprice" class="col-sm-3 control-label">Cost</label>

                                  <div class="col-sm-9">
                                    
                                    <input class="form-control" id="proprice" placeholder="Enter Product Cost" >
                                  </div>
                                </div>

                                <div class="form-group col-md-12">
                                  
                                  <label for="prowholesale" class="col-sm-3 control-label">Wholesale Price</label>

                                  <div class="col-sm-9">
                                    <input type="text" class="form-control" id="prowholesale">
                                  </div>
                                  
                                </div>

                                
                                <div class="form-group col-md-12">
                                  <label for="prosellprice" class="col-sm-3 control-label">Retail Price</label>

                                  <div class="col-sm-9">
                                    <input type="text" class="form-control" id="prosellprice">
                                  </div>
                                </div>
                                <div class="form-group col-md-12">
                                  <label for="proqty" class="col-sm-3 control-label">Purchased Quantity</label>

                                  <div class="col-sm-9">
                                    <input type="text" class="form-control" id="proqty" placeholder="Purchased Quantity">
                                  </div>
                                  <p class="col-sm-9 control-label pull-right"><b>Total Cost: </b> <span id="navtotalcost"></span></p>
                                </div>
                               
                                
                                
                              </div>
                              <!-- /.box-body -->
                              
                              <div class="box-footer">
                                <button class="btn btn-danger pull-left" id="clearnav" onclick="clearnavfields()">Clear</button>
                                <button class="btn btn-success pull-right" id="navadd" disabled="disabled">Add To Invoice</button>
                              </div>
                              <!-- /.box-footer -->

                          </div>
                        </div>
                        
                      </div>
                      <!-- /.tab-content -->
                    </div>
                    <!-- nav-tabs-custom -->
                  </div>

                  <div class="col-md-6">
                    <!-- SERIAL NUMBER Section -->
                    <!-- <br><br><br><br><br> -->
                    <div class="box box-primary serialbox"  style="display: none;">
                      <div class="box-body box-profile">

                        <div class="form-group has_serial" id="has_serialf">
                          

                          <div class="form-group" id="warrantyf">

                              <h4 class="text-center">Serial Distribution</h4>                      

                            <div class="col-md-12 checkbox" style="text-align: left;">

                              
                              <label class="col-md-4">
                                <input type="radio" name="rangechoice" id="rangechoice" value='individual' class="flat-red rangechoice">
                                Individual
                              </label>
                              <label class="col-md-4">
                                <input type="radio" name="rangechoice" id="rangechoice" value="withinRange" class="flat-red rangechoice">
                                Within Range
                              </label>
                              <label class="col-md-4">
                                <input type="radio" name="rangechoice" id="rangechoice" value='combined' class="flat-red rangechoice">
                                Combined
                              </label>
                              
                            </div>

                          </div>

                          <!-- range format for SERIAL WITHIN RANGE -->
                          <div class="col-md-12 withinRange">

                            <form name="serialsRangeFrm" ng-submit="rangeSerial()">

                              <div class="form-group"> 

                                <div class="col-md-12 input_box">
                                  <div class="col-sm-4">
                                    <label for="srartfrom" class="control-label text-right">First Serial. </label>
                                  </div>
                                  <div class="col-sm-6">
                                    <input type="text" name="startfrom" class="form-control withinRangeFirst" id="startfrom" ng-model="startfrom" oninput="this.value = this.value.toUpperCase()" required />
                                    
                                  </div>
                                </div>
                              </div>
                              <br><br>
                              <div class="form-group"> 


                                <div class="col-md-12 input_box">
                                  <div class="col-sm-4">
                                    <label for="endto" class="control-label text-right">Last Serial. </label>
                                  </div>
                                  <div class="col-sm-6">
                                    <input type="text" name="endto" class="form-control" id="endto" ng-model="endto" placeholder="Hit Enter" oninput="this.value = this.value.toUpperCase()" required />
                                    
                                  </div>
                                </div>
                              </div>

                              <div class="col-md-12">
                                <br>
                                <div class="col-sm-3"></div>
                                <button class="col-md-6 btn btn-success btn-sm" ng-disabled="serialsRangeFrm.$invalid" ng-click="rangeSerial()">Add Serials</button>
                              </div>

                              

                            </form>

                            <!-- <ul>
                              <br>
                              <h4 class="col-md-12" ng-show="rangeSLs.length>0">Added Serials: </h4>
                              <li ng-repeat="serial in rangeSLs" class="{'fadeOut' : serial.done}">
                                <span>{{serial}}</span>
                              </li>
                            </ul> -->
                            <ul>
                              <h4 class="col-md-12" ng-show="rangeSLs.length>0">Added Serials: </h4>
                              <li ng-repeat="serial in rangeSLs" class="{'fadeOut' : serial.done}">
                                <span class="fa fa-close" ng-click="rangedeleteSerial($index)"></span>
                                <span>{{serial.title}}</span>
                              </li>
                            </ul>




                            
                            
                          </div>
                          <!-- range format for SERIAL WITHIN RANGE  end -->

                          <!-- range format for  INDIVIDUAL SERIAL -->
                          <div class="col-md-12 individual">

                            <div class="box-item individualslbox" id="itemsform">

                              <form name="serialsFrm" ng-submit="addSerial()">
                                <div class="col-md-12">
                                  <label class="col-md-4 text-right" for="newSerial"><h5>Add Serials: </h5></label>

                                  <input class="col-md-6 individualInput" type="text" name="newSerial" ng-model="newSerial" placeholder="Hit Enter" oninput="this.value = this.value.toUpperCase()" required />
                                 <button class="col-md-2 btn btn-success btn-xs" ng-disabled="serialsFrm.$invalid" ng-click="addSerial()">Add</button>
                                </div>
                                  
                                 
                              </form>

                              <ul>
                                <h4 class="col-md-12" ng-show="addedserials.length>0">Added Serials: </h4>
                                <li ng-repeat="serial in addedserials" class="{'fadeOut' : serial.done}">
                                  <span class="fa fa-close" ng-click="deleteSerial($index)"></span>
                                  <span>{{serial.title}}</span>
                                </li>
                              </ul>
                            

                          </div>
                              
                            </div>
                            <div class="col-sm-5"></div>
                            <!-- <button type="button" id="addnew" class="col-sm-4 btn bg-gray" style="margin-top: 10px;"><b><i class="fa fa-plus"></i> Add More</b></button>
                            <div class="col-sm-5"></div> -->
                          </div>
                          <!-- range format for  INDIVIDUAL SERIAL  end -->

                          <!-- range format for  Combined SERIAL -->

                          <div class="col-md-12 combined">

                              <form name="comserialsRangeFrm" ng-submit="comrangeSerial()">

                                <div class="form-group"> 

                                  <div class="col-md-12 input_box">
                                    <div class="col-sm-4">
                                      <label for="comsrartfrom" class="control-label text-right">First Serial. </label>
                                    </div>
                                    <div class="col-sm-6">
                                      <input type="text" name="comstartfrom" class="form-control combinedFocus" id="comstartfrom" ng-model="comstartfrom" oninput="this.value = this.value.toUpperCase()" required />
                                      
                                    </div>
                                  </div>
                                </div>
                                <br><br>
                                <div class="form-group"> 


                                  <div class="col-md-12 input_box">
                                    <div class="col-sm-4">
                                      <label for="comendto" class="control-label text-right">Last Serial. </label>
                                    </div>
                                    <div class="col-sm-6">
                                      <input type="text" name="comendto" class="form-control" id="comendto" ng-model="comendto" placeholder="Hit Enter" oninput="this.value = this.value.toUpperCase()" required />
                                      
                                    </div>
                                  </div>
                                </div>

                                <div class="col-md-12" style="padding-top: 5px;">
                                  <div class="col-sm-4"></div>
                                  <button class="col-md-6 btn btn-success btn-sm" ng-disabled="comserialsRangeFrm.$invalid" ng-click="comrangeSerial()">Add Ranges</button>
                                </div>
                                 <br> <br> <br>
                              </form>


                              <form name="comserialsFrm" ng-submit="comaddSerial()">
                                <div class="col-md-12" style="padding-top: 5px;">
                                  <label class="col-md-4 text-right" for="comnewSerial"><h5>Add Serials: </h5></label>

                                  <input class="col-md-6" type="text" name="comnewSerial" ng-model="comnewSerial" placeholder="Hit Enter" oninput="this.value = this.value.toUpperCase()" required />
                                  
                                 <button class="col-md-2 btn btn-success btn-xs" ng-disabled="comserialsFrm.$invalid" ng-click="comaddSerial()">Add</button>
                                </div>
                                  
                                 
                              </form>

                              <ul>
                                <br>
                                <h4 class="col-md-12" ng-show="addedserials.length>0">Added Serials: </h4>
                                <li ng-repeat="serial in comrangeSLs" class="{'fadeOut' : serial.done}">
                                  <span>{{serial}}</span>
                                </li>
                              </ul>

                              <ul>
                                <li ng-repeat="serial in comaddedserials" class="{'fadeOut' : serial.done}">
                                  <span class="fa fa-close" ng-click="comdeleteSerial($index)"></span>
                                  <span>{{serial.title}}</span>
                                </li>
                              </ul>
                              
                          </div>
                          <!-- range format for  Combined SERIAL end-->
                          
                        <!-- form-group end -->

                      </div>

                    </div>

                    <!-- SERIAL NUMBER Section  END-->

                    <!-- invoice total -->
                    <div class="box-body bg-gray" id="billitems">
                      <h7 class="widget-user-username">Added Products in this invoice</h7><br>
                      <div class="row">
                        <div class="col-sm-1 border-right">
                          <div class="description-block">
                            <span class="description-text">SL No.</span>
                          </div>
                          <!-- /.description-block -->
                        </div>
                        <!-- /.col -->
                        <div class="col-sm-5 border-right">
                          <div class="description-block">
                            <span class="description-text">Description</span>
                          </div>
                          <!-- /.description-block -->
                        </div>
                        
                        <div class="col-sm-2 border-right">
                          <div class="description-block">
                            <span class="description-text">Unit Price</span>
                          </div>
                          <!-- /.description-block -->
                        </div>
                        <!-- /.col -->
                        <div class="col-sm-1 border-right">
                          <div class="description-block">
                            <span class="description-text">QTY</span>
                          </div>
                          <!-- /.description-block -->
                        </div>
                        <div class="col-sm-3">
                          <div class="description-block">
                            <span class="description-text">Total Price</span>
                          </div>
                          <!-- /.description-block -->
                        </div>
                        <!-- <div class="col-sm-1">
                          <div class="description-block">
                            <span class="description-text">Del</span>
                          </div>
                        </div> -->
                        <!-- /.col -->
                      </div>
                      <!-- /.row -->

                      <!-- draw items -->
                      
                    </div>
                    <div class="box-footer">
                      <h5>Invoice Total: <span id="billtotal"></span>
                            TK</h5>
                      <button id="createinvoice" class="col-md-12 btn btn-success pull-right "><i class="glyphicon glyphicon-shopping-cart" style="margin-right: 10px;"> </i> Create Invoice</button>
                    </div>
                      

                    </div>
                  </div>



                  
                </div>


                <!-- tabs end -->
       
              </div>
              <!-- /.box-body -->
              
              <!-- /.box-footer -->

          </div>
          <!-- /.box -->
          <!-- here end -->
          <!-- /.box -->
        </div>
        <!-- end of add category form -->

        <div class="col-md-6">

          <!-- serials modal -->
          <div class="modal fade no-print" id="editSerials" role="dialog">
            <div class="modal-dialog">
            
              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-header bg-info">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h3 class="box-title">Serials of <b>{{ selectedItemName }}<b></h3>
                </div>
                
                <div class="modal-body">
                  <div class="box-body individualslbox">

                      
                    <ul>
                      <li ng-repeat="serial in selectedItemSL" class="{'fadeOut' : serial.done}">
                        <span class="fa fa-close" ng-click="DelSelectedItemSL($index)"></span>
                        <span>{{serial.title}}</span>
                      </li>
                    </ul>
                        
      
                    

                        

                        
                        
                  </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa  fa-remove"></i>Close</button>
                </div>
                </form>
                
              </div>
              
            </div>
          </div>

          <!-- modal end -->
          
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->

    
  </div>
  <!-- /.content-wrapper -->

<style type="text/css">
    
$melon: #F97D75;
$black: #2E3641;

.individualslbox *, .combined *, .itemserialsBox * {
  font-size: 14px;
  font-family: 'Titillium Web', sans-serif;
  color: $black;
}

.individualslbox h1, .combined h1, .itemserialsBox h1{
  font-size: 32px;
}

.individualslbox input, .combined input {
  border: 0;
  margin-right: 5px;
  background: transparent;
  border: 1px solid black;

  width: 200px;
  padding: 8px;
  @include transition(all .3s ease);
  
  &:focus, &:active {
    outline: 0;
    width: 200px;
    border-bottom-color: $melon;
  }
}

.individualslbox button, .combined button, .itemserialsBox button {
  
  border: 0;
  padding: 8px 20px;
  cursor: pointer;
  
  &:focus, &:active {
    outline: 0;
  }
}

.individualslbox ul, .withinRange ul, .combined ul, .itemserialsBox ul {
  list-style: none;
  padding-left: 0;
  margin-top: 25px;
}

.individualslbox li, .withinRange li, .combined li, .itemserialsBox li {
  border: 1px solid black;
  display: inline-block;
  padding: 5px 10px;
  margin-right: 5px;
  margin-bottom: 5px;
}


.individualslbox .fa-close, .withinRange .fa-close, .combined .fa-close, .itemserialsBox .fa-close {
  cursor: pointer;
}

[contenteditable] {
  &:focus, &:active {
    outline:0;
  }
}
</style>




  <!-- footer -->
  <? print $this->fetch('/ui_includes/footer.phtml'); ?>

  <!-- Control Sidebar -->
  <? print $this->fetch('/ui_includes/control-sidebar.phtml'); ?>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>bootstrap/js/bootstrap.min.js"></script>


<!-- bootstrap-confirmation.min.js -->

<script src="<?php echo htmlspecialchars($baseUrl); ?>bootstrap/js/bootstrap-confirmation.min.js"></script>


<!-- FastClick -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>dist/js/app.min.js"></script>
<!-- sidebar toggle -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>dist/js/sidebar-toggle.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>dist/js/demo.js"></script>

<!-- autocomplete -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>dist/js/jquery.easy-autocomplete.js"></script>

<!-- Select2 -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/select2/select2.full.min.js"></script>

<!-- DataTables -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/datatables/dataTables.bootstrap.min.js"></script>
<!-- bootstrap datepicker -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/datepicker/bootstrap-datepicker.js"></script>

<!-- iCheck 1.0.1 -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/iCheck/icheck.min.js"></script>

<!-- jQuery Confirmation -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>dist/js/jquery-confirm.min.js"></script>


<script>

  // define variables

  var cartProducts = [];

  var serials = [];


  var rangeSerials = null;
  var comSerials = [];

  //for final deleting in modal
  var selecteditemid = null;


  var supplier = null;

  var productid = null;
  var model_no = null;
  var code = null;
  var category = null;
  var brand = null;
  var group = null;
  var has_serial = null;
  var buyrate = null;
  var wholesale_rate = null;
  var sellrate = null;
  var qty = null;
  var groupname = null;
  var itemtotalprice = null;
  var itemcount = 0;
  var billtotal = 0;
  var rangechoice = null;

  var addtype = null;

  var cart = new Array();

  var individualcount = 1;
  var mixcount = 1;

  var individual_box = null;

  // variable definition end

  function clearfields(){
      $("#productmodel").val("");
      $("#productid").val("");

      $("#productcategory").val("");
      $("#productbrand").html("");
      $("#productgroup").html("");
      $("#productcode").val("");

      $("#productprice").val("");
      $("#productwholesale").val("");
      $("#productsellprice").val("");
      $("#productqty").val("");
      $("#totalcost").html("");

      model_no = null;
      itemtotalprice = null;
      has_serial = null;
      rangechoice = null;

      individual_box = null;

      $("#addeasy").attr("disabled", "disabled");

      addtype = null;

    }

    function clearnavfields(){
      
      $("#procategory").val("").trigger('change');
      $("#probrand").val("").trigger('change');
      $("#progroup").val("").trigger('change');
      $("#promodel").val("").trigger('change');
      $("#procode").html("");
      $("#proavailableqty").html("");

      $("#proprice").val("");
      $("#prowholesale").val("");

      $("#prosellprice").val("");
      $("#proqty").val("");
      $("#navtotalcost").html("");

      model_no = null;
      itemtotalprice = null;
      has_serial = null;
      rangechoice = null;

      individual_box = null;

      $("#navadd").attr("disabled", "disabled");

      addtype = null;

    }
  
  

  $(".supplier").select2().on("select2:select", function (e) {

      var selected_element = $(e.currentTarget);
      var select_val = selected_element.val();


      $.ajax({

        url : '/public/suppliers/getsupplier',
        type : 'post',
        data : {
          supplier : select_val
        },
        success : function(data) {
          
          var selectedSup = JSON.parse(data);

          if (selectedSup.name) {

            supplier = selectedSup.id;
            $("#sup_addr").html(selectedSup.address);
            $("#sup_balance").html(selectedSup.balance);
          
          }

        }
      });

  });

  $(".procategory").select2().on("select2:select", function (e) {

      var selected_element = $(e.currentTarget);
      var select_val = selected_element.val();

      var selectedbrand = $("#probrand").val();

      nogroup = null;

      // grab the groups for selected category---------------------

      $.ajax({

        url : '/public/suppliers/getcategorygroups',
        type : 'post',
        data : {
          category : select_val,
        },
        success : function(data) {
          

          if (data!='nogroup') {

            $("#progroup").html(data);
          
          }
          if (data=='nogroup') {
            $("#progroup").html('<option value="">No Group Found</option>');
            
          }

        },
        complete: function() {
          
          //any code for group selection must be here ---------------------------------

          $(".progroup").select2().on("select2:select", function (e) {

            var selected_element = $(e.currentTarget);
            var select_val = selected_element.val();

            var selectedcategory = $("#procategory").val();
            var selectedbrand = $("#probrand").val();

            $.ajax({

              url : '/public/suppliers/getproducts',
              type : 'post',
              data : {
                category : selectedcategory,
                brand: selectedbrand,
                group: select_val
              },
              success : function(data) {
                

                if (data!='noproduct') {

                  $("#promodel").html(data);

                
                }
                if (data=='noproduct') {
                  $("#promodel").html('<option value="">No Product Found</option>');

                }

              },
              complete: function() {
                
                $(".promodel").select2();
              }
            });

            


          });
        }
      });

      var selectedgroup = $("#progroup").val();

      //if the category has no group and brand has already selected-----------------
      
      if (selectedbrand!='' && selectedgroup=='') {


        $.ajax({

          url : '/public/suppliers/getproducts',
          type : 'post',
          data : {
            category : select_val,
            brand: selectedbrand
          },
          success : function(data) {
            
            if (data!='noproduct') {

              $("#promodel").html(data);

            
            }
            if (data=='noproduct') {
              $("#promodel").html('<option value="">No Group Found</option>');

            }

          },
          complete: function() {

            $(".promodel").select2();
          }
        });
      }

  });

  $(".probrand").select2().on("select2:select", function (e) {

      var selected_element = $(e.currentTarget);
      var select_val = selected_element.val();

      var selectedcategory = $("#procategory").val();
      var selectedgroup = $("#progroup").val();

      //for each time brand selection-----------------
      
      if (selectedcategory!='') {


        $.ajax({

          url : '/public/suppliers/getproducts',
          type : 'post',
          data : {
            category : selectedcategory,
            brand: select_val,
            group: selectedgroup
          },
          success : function(data) {
            

            if (data!='noproduct') {

              $("#promodel").html(data);

            
            }
            if (data=='noproduct') {
              $("#promodel").html('<option value="">No Group Found</option>');

            }

          },
          complete: function() {
            
            // $(".promodel").select2().on("select2:select", function (e) {

            //   var selected_element = $(e.currentTarget);
            //   var select_val = selected_element.val();
            //   navModelSelected(select_val);

            // });
            $(".promodel").select2();
          }
        });
      }

  });

  $(".progroup").select2();
  $(".promodel").select2();

  $(".promodel").select2().on("select2:select", function (e) {

    var selected_element = $(e.currentTarget);
    var select_val = selected_element.val();
    navModelSelected(select_val);

  });

  function navModelSelected(thisproductid) {
    
    $.ajax({

      url : '/public/suppliers/selectedproductdata',
      type : 'post',
      data : {
        id : thisproductid
      },
      success : function(data) {

        updateNavSelectedModel(data);
        
      }
    });

    


  }

  function updateNavSelectedModel(data) {
    var product = JSON.parse(data);

    productid = product.id;
    model_no = product.model_no;
    code = product.code;
    has_serial = product.has_serial;
    buyrate = product.buy_rate;
    wholesale_rate = product.wholesale_rate;
    sellrate = product.sell_rate;
    qty = product.qty;

    $("#procode").html(code);

    $("#proavailableqty").html(qty);
    $("#proprice").val(buyrate);

    
    $("#prosellprice").val(sellrate);
    $("#prowholesale").val(wholesale_rate);
    $("#proavailableqty").html(qty);



    //show the serial box
    if (has_serial=='1') {
      $("#has_serial_true").prop("checked", true).iCheck('update');
      $("#has_serial_false").removeAttr('checked').iCheck('update');

      $(".serialbox").show();
      $("#proqty").prop("readonly", true);

    } else{
      $("#has_serial_true").removeAttr('checked').iCheck('update');
      $("#has_serial_false").prop("checked", true).iCheck('update');

      $(".serialbox").hide();
       $("#proqty").prop("readonly", false);
    }

    addtype = 2;
  }


  $("#partstart").keyup(function () {

      var thisval = $(this).val();

      if ($.isNumeric(thisval)) {
        
        $(this).removeClass("bg-red");
        $("#addeasy").removeAttr("disabled");
        $("#navadd").removeAttr("disabled");
      } else {
        $(this).addClass("bg-red");
        $("#addeasy").attr("disabled", "disabled");
        $("#navadd").attr("disabled", "disabled");
      }
    });
  $("#partend").keyup(function () {

      var thisval = $(this).val();

      if ($.isNumeric(thisval)) {
        
        $(this).removeClass("bg-red");
        $("#addeasy").removeAttr("disabled");
        $("#navadd").removeAttr("disabled");
      } else {
        $(this).addClass("bg-red");
        $("#addeasy").attr("disabled", "disabled");
        $("#navadd").attr("disabled", "disabled");
      }
    }); 
    $("#mixstart").keyup(function () {

      var thisval = $(this).val();

      if ($.isNumeric(thisval)) {
        
        $(this).removeClass("bg-red");
        $("#addeasy").removeAttr("disabled");
        $("#navadd").removeAttr("disabled");
      } else {
        $(this).addClass("bg-red");
        $("#addeasy").attr("disabled", "disabled");
        $("#navadd").attr("disabled", "disabled");
      }
    }); 
    $("#mixend").keyup(function () {

      var thisval = $(this).val();

      if ($.isNumeric(thisval)) {
        
        $(this).removeClass("bg-red");
        $("#addeasy").removeAttr("disabled");
        $("#navadd").removeAttr("disabled");
      } else {
        $(this).addClass("bg-red");
        $("#addeasy").attr("disabled", "disabled");
        $("#navadd").attr("disabled", "disabled");
      }
    });  

  
  $('.withinRangeFirst').keypress(function(event){
    var keycode = (event.keyCode ? event.keyCode : event.which);
    if(keycode == '13'){
      $("#endto").focus();
      event.preventDefault();
      return false;
    }
  });

  $('#comstartfrom').keypress(function(event){
    var keycode = (event.keyCode ? event.keyCode : event.which);
    if(keycode == '13'){
      $("#comendto").focus();
      event.preventDefault();
      return false;
    }
  });

  $('#productprice').keypress(function(event){
    var keycode = (event.keyCode ? event.keyCode : event.which);
    if(keycode == '13'){
      $("#productwholesale").focus();
      event.preventDefault();
      return false;
    }
  });
  $('#productwholesale').keypress(function(event){
    var keycode = (event.keyCode ? event.keyCode : event.which);
    if(keycode == '13'){
      $("#productsellprice").focus();
      event.preventDefault();
      return false;
    }
  });
  $('#productsellprice').keypress(function(event){
    var keycode = (event.keyCode ? event.keyCode : event.which);
    if(keycode == '13'){
      $("#productqty").focus();
      event.preventDefault();
      return false;
    }
  });

  //Date picker
  $('#datepicker').datepicker({
     todayHighlight: true,
    autoclose: true
  });

  //Flat red color scheme for iCheck
  $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
    checkboxClass: 'icheckbox_flat-green',
    radioClass: 'iradio_flat-green'
  });

  //for serial number section
  $("input[name='has_serial']").on('ifChecked', function(event){

      var qtyeasyval = $("#productqty").val();
      var qtynavval = $("#proqty").val();
       if($(this).val()=="1")
       {
          // if (qtynavval || qtyeasyval) {

            $(".serialbox").show();
             $("#productqty").prop("readonly", true);

          // } else {

          //   $.alert("Please give quantity first!");
          //   $(this).removeAttr('checked').iCheck('update');
          //   $(this).removeClass("iradio_flat-green").iCheck('update');



          // }
          
       }
       else
       {
           $("#productqty").prop("readonly", false);
          $(".serialbox").hide();
          $(".combined").hide();
          $(".withinRange").hide(); 
          $(".individual").hide(); 
       }

    });
    
    $("input[name='rangechoice']").on('ifChecked', function(event){

      rangechoice = $(this).val();

     if($(this).val()=="withinRange") {

      var selectedopt = $(this);

      if (addtype == 1 || addtype == 2) {

        $(".withinRange").show();
        $(".individual").hide(); 
        $(".combined").hide();

        $('.withinRangeFirst').focus();

      } else {

        $.alert("Please select product first!");

        $("input[name=rangechoice]").removeAttr('checked').iCheck('update');
        $("input[name=rangechoice]").removeClass("iradio_flat-green").iCheck('update');

      }


     } else if($(this).val()=="individual"){

      if (addtype == 1) {

        var prodqty =  $("#productqty").val();

        individualcount = prodqty;

        $(".individual").show();
        $(".withinRange").hide(); 
        $(".combined").hide();

        $('.individualInput').focus(); 

      } else if(addtype == 2) {

        var prodqty =  $("#proqty").val();

        individualcount = prodqty;

        $(".individual").show();
        $(".withinRange").hide(); 
        $(".combined").hide();

        $('.individualInput').focus(); 



      } else {

        $.alert("Please select product first!");

        $("input[name=rangechoice]").removeAttr('checked').iCheck('update');
        $("input[name=rangechoice]").removeClass("iradio_flat-green").iCheck('update');
            
      }

     } else if($(this).val()=="combined"){

      if (addtype==1) {

        var prodqty =  $("#productqty").val();

        $(".combined").show();
        $(".withinRange").hide(); 
        $(".individual").hide();

        $('.combinedFocus').focus(); 


      } else if (addtype==2) {

        var prodqty =  $("#proqty").val();

        $(".combined").show();
        $(".withinRange").hide(); 
        $(".individual").hide();

      } else {

        $.alert("Please select product first!");
        $("input[name=rangechoice]").removeAttr('checked').iCheck('update');
        $("input[name=rangechoice]").removeClass("iradio_flat-green").iCheck('update');
        
      }

      

      

      
      $('#mixend').keypress(function(event) {
            if (event.keyCode == 13) {
                event.preventDefault();
                return false;
            }
        });
      


      $('#mixend').change(function () {

            if (addtype==1) {

              var stockqty = $("#productqty").val();

            } else if (addtype==2) {

              var stockqty = $("#proqty").val();

            }

            var mixstart =  $("#mixstart").val();
            var mixend =  $("#mixend").val();
            var mixtotal = mixend - mixstart;
            var mix_individual =mixtotal - prodqty;
            individual_box = prodqty - mixtotal;

            if(mixtotal <= 0 || mixtotal+1>stockqty){

              $('#itemsformmix').empty();

              $.alert('Invalid Range.');

              $(this).addClass('bg-red');
              $("#addeasy").attr("disabled", "disabled");
              $("#navadd").attr("disabled", "disabled");

            } else if (mixtotal > 0) {

              $('#itemsformmix').empty();

              mixcount = individual_box-1;
              
              for(i=1;i<individual_box;i++){
                  var com_itemsformcon='<div class="col-sm-1" id="items'+i+'">'+ i +'</div><div class="col-sm-11" ><input style="margin-right:2px;" type="text" name="mixserial[0]" class="col-sm-6" id="mixitem'+i+'" placeholder="Serial"></div></div>';
                  
                  $("#itemsformmix").append(com_itemsformcon);
                  
                }

                $("#addeasy").removeAttr("disabled")
            }


            // }else if(mixtotal>prodqty){
            //   $.alert('please check product Quantity and given range.');
            // }

            

          

          });


     }

  });

  //draw individual serial input box------------
  
  // $('#addnew').click(function () {

  //   individualcount = individualcount+1;

  //   var itemsformcon = '<div class="col-sm-1" id="itemsl">'+individualcount+'.</div><div class="col-sm-11" ><input style="margin-right:2px;" type="text" name="indserial&#91;'+ (individualcount-1) +'&#93;" class="col-sm-6" id="item'+individualcount+'" placeholder="Serial"><input style="margin-right:2px;" type="text" name="indremark&#91;' + (individualcount-1) + '&#93;" class="col-sm-5 itmprice" id="itemrem'+individualcount+'" placeholder="Remarks" /></div>';

  //   $("#itemsform").append(itemsformcon);

  // });

  //serial section end


  //calculate item total
    function calculateEasyItemTotal(argument) {
      
      var prodqty =  $("#productqty").val();
      var prodprice =  $("#productprice").val();
      if ($.isNumeric(prodqty)) {

        $("#productqty").removeClass("bg-red");

        itemtotalprice = prodqty*prodprice;
        $("#totalcost").html(itemtotalprice);
        $("#addeasy").removeAttr("disabled");

        if (prodqty==0) {
          $("#addeasy").prop('disabled', true);
        }

      } else {
        jQuery("#productqty").addClass("bg-red");
        $("#addeasy").attr("disabled", "disabled");
      }
    } 
    function calculateNavItemTotal() {
     
      var prodqty =  $("#proqty").val();
      var prodprice =  $("#proprice").val();
      if ($.isNumeric(prodqty)) {

        $("#proqty").removeClass("bg-red");

        itemtotalprice = prodqty*prodprice;

        $("#navtotalcost").html(itemtotalprice);
        $("#navadd").removeAttr("disabled");

        if (prodqty==0) {
          $("#navadd").prop('disabled', true);
        }

      } else {
        jQuery("#proqty").addClass("bg-red");
        $("#navadd").attr("disabled", "disabled");
      }
    }

  

  



  $(document).ready(function() {


    var optionsname = {
          url: function(phrase) {
            return "/suppliers/purchase/getproductdata?phrase=" + phrase + "&format=json";
          },

          getValue: "model_no",
          list: {

            onSelectItemEvent: function() {
 

              productid = $("#productmodel").getSelectedItemData().id;
              model_no = $("#productmodel").getSelectedItemData().model_no;
              code = $("#productmodel").getSelectedItemData().code;
              category = $("#productmodel").getSelectedItemData().category;
              brand = $("#productmodel").getSelectedItemData().brand;
              group = $("#productmodel").getSelectedItemData().group;
              groupname = $("#productmodel").getSelectedItemData().groupname;
              has_serial = $("#productmodel").getSelectedItemData().has_serial;
              buyrate = $("#productmodel").getSelectedItemData().buyrate;
              wholesale_rate = $("#productmodel").getSelectedItemData().wholesale_rate;
              sellrate = $("#productmodel").getSelectedItemData().sellrate;
              qty = $("#productmodel").getSelectedItemData().qty;

              $("#productcode").val(code).trigger("change");
              $("#productbrand").html(brand).trigger("change");
              $("#productgroup").html(groupname).trigger("change");
              $("#availableqty").html(qty).trigger("change");
              $("#productprice").val(buyrate).trigger("change");

              
              $("#productsellprice").val(sellrate).trigger("change");
              $("#productwholesale").val(wholesale_rate).trigger("change");

              $("#productid").val(productid).trigger("change");

              //show the serial box
              if (has_serial=='1') {
                $("#has_serial_true").prop("checked", true).iCheck('update');
                $("#has_serial_false").removeAttr('checked').iCheck('update');

                $(".serialbox").show();
                $("#productqty").prop("readonly", true);

              } else{
                $("#has_serial_true").removeAttr('checked').iCheck('update');
                $("#has_serial_false").prop("checked", true).iCheck('update');

                $(".serialbox").hide();
                $("#productqty").prop("readonly", false);
              }

              addtype = 1;

              

            }
          },
          template: {
              type: "description",
              fields: {
                  description: "brand"
              }
          },
          theme: "blue-light",

          showAnimation: {
            type: "fade", //normal|slide|fade
            time: 100,
            callback: function() {}
          },

          hideAnimation: {
            type: "slide", //normal|slide|fade
            time: 100,
            callback: function() {}
          }


        };

        //for code search
        var optionscode = {
          url: function(phrase) {
            return "/suppliers/purchase/getproductdata?phrase=" + phrase + "&format=json&type=code";
          },

          getValue: "code",
          list: {

            onSelectItemEvent: function() {

              productid = $("#productcode").getSelectedItemData().id;
              model_no = $("#productcode").getSelectedItemData().model_no;
              code = $("#productcode").getSelectedItemData().code;
              category = $("#productcode").getSelectedItemData().category;
              brand = $("#productcode").getSelectedItemData().brand;
              group = $("#productcode").getSelectedItemData().group;
              groupname = $("#productcode").getSelectedItemData().groupname;
              has_serial = $("#productcode").getSelectedItemData().has_serial;
              buyrate = $("#productcode").getSelectedItemData().buyrate;
              wholesale_rate = $("#productcode").getSelectedItemData().wholesale_rate;
              sellrate = $("#productcode").getSelectedItemData().sellrate;
              qty = $("#productcode").getSelectedItemData().qty;

              $("#productmodel").val(model_no).trigger("change");
              $("#productbrand").html(brand).trigger("change");
              $("#productgroup").html(groupname).trigger("change");
              $("#availableqty").html(qty).trigger("change");
              $("#productprice").val(buyrate).trigger("change");

              
              $("#productsellprice").val(sellrate).trigger("change");
              $("#productwholesale").val(wholesale_rate).trigger("change");

              $("#productid").val(productid).trigger("change");

              //show the serial box
              if (has_serial=='1') {
                $("#has_serial_true").prop("checked", true).iCheck('update');
                $("#has_serial_false").removeAttr('checked').iCheck('update');

                $(".serialbox").show();

                $("#proqty").prop("readonly", true);

              } else{
                $("#has_serial_true").removeAttr('checked').iCheck('update');
                $("#has_serial_false").prop("checked", true).iCheck('update');

                $(".serialbox").hide();

                $("#proqty").prop("readonly", false);
              }

              addtype = 1;

            }
          },
          template: {
              type: "description",
              fields: {
                  description: "brand"
              }
          },
          theme: "blue-light",

          showAnimation: {
            type: "fade", //normal|slide|fade
            time: 100,
            callback: function() {}
          },

          hideAnimation: {
            type: "slide", //normal|slide|fade
            time: 100,
            callback: function() {}
          }


        };

    $("#productmodel").easyAutocomplete(optionsname);
    $("#productcode").easyAutocomplete(optionscode);
  //----------------------------- prices check -----------------------------------
    $('#productprice').keyup(function () {

      var thisprice = $('#productprice').val();

      if ($.isNumeric(thisprice)) {
        
        $(this).removeClass("bg-red");
        $("#addeasy").removeAttr("disabled");
      } else {
        $(this).addClass("bg-red");
        $("#addeasy").attr("disabled", "disabled");
      }
    });  

    $('#productwholesale').keyup(function () {

      var thisprice = $('#productwholesale').val();

      if ($.isNumeric(thisprice)) {
        
        $(this).removeClass("bg-red");
        $("#addeasy").removeAttr("disabled")
      } else {
        $(this).addClass("bg-red");
        $("#addeasy").attr("disabled", "disabled");
      }
    });        

    $('#productsellprice').keyup(function () {

      var thisprice = $('#productsellprice').val();
      var prodqty =  $("#productqty").val();
      if ($.isNumeric(thisprice)) {
        
        $(this).removeClass("bg-red");
        $("#addeasy").removeAttr("disabled");
        if(prodqty!=''){

          var totalprice = prodqty*thisprice;
          $("#totalcost").html(totalprice);
        }
      } else {
        $(this).addClass("bg-red");
        $("#addeasy").attr("disabled", "disabled");
      }
    });

    //qty calculation
      $('#productqty').keyup(function () {

        var prodqty =  $("#productqty").val();
        var prodprice =  $("#productprice").val();
        if ($.isNumeric(prodqty)) {

          $("#productqty").removeClass("bg-red");

          itemtotalprice = prodqty*prodprice;
          $("#totalcost").html(itemtotalprice);
          $("#addeasy").removeAttr("disabled");
        } else {
          jQuery("#productqty").addClass("bg-red");
          $("#addeasy").attr("disabled", "disabled");
        }
      });
      $('#proqty').keyup(function () {

        var prodqty =  $("#proqty").val();
        var prodprice =  $("#proprice").val();
        if ($.isNumeric(prodqty)) {

          $("#proqty").removeClass("bg-red");

          itemtotalprice = prodqty*prodprice;

          $("#navtotalcost").html(itemtotalprice);
          $("#navadd").removeAttr("disabled");
        } else {
          jQuery("#proqty").addClass("bg-red");
          $("#navadd").attr("disabled", "disabled");
        }
      });

         

    

    function addEasyToInvoice(serial_type, serial) {

      if (cartProducts.indexOf(parseInt(productid)) == -1) {
        cartProducts.push(parseInt(productid));
      
        itemfinalprice = Math.round (itemtotalprice*100) / 100;

        if (itemfinalprice) {

          var model =  model_no;
          var id = productid;
          
          var buyrate = $('#productprice').val();
          var wholesalerate = $('#productwholesale').val();
          var sellrate = $("#productsellprice").val();
          
          var qty = $("#productqty").val();

          // totalprofit+=itemprofit;
          // $("#totalprofit").html(totalprofit.toFixed(2));

          itemcount++;

          var cartitem = {
             "id" :             id,
             "model" :          model,
             "buyrate" :        buyrate,
             "sellrate" :       sellrate,
             "wholesalerate" :  wholesalerate,
             "qty" :            qty,
             'serial_type' :    serial_type, //NO NEED
             "serial" :         serial
          }; 

          cart[id] =cartitem;

          if (serial) {

            var itemsdraw = '<div class="row" id="row'+id+'"><div class="col-sm-5"><div class="description-block"><span class="description-text" id="itemname">'+model+'</span></div>  </div><div class="col-sm-2"><div class="description-block"><span class="description-text" id="itemunitpr">'+buyrate+'</span></div></div><div class="col-sm-1"><div class="description-block"><span class="description-text" id="itemqtySL'+id+'">'+qty+'</span></div></div><div class="col-sm-2"><div class="description-block"><span class="description-text" id="itemtotalSL'+id+'">'+itemfinalprice+'</span></div></div><div class="col-sm-1" id="deleteitem"  key="'+id+'"><div class="description-block bg-red"><i class="glyphicon glyphicon-trash"></i></div></div><!-- here the serials--><div class="col-md-12"><button type="button" class="btn btn-xs btn-info pull-right" data-toggle="modal" data-target="#editSerials" data-proid="'+ id +'">View Serials</button></div>';

          } else {

            var itemsdraw = '<div class="row" id="row'+id+'"><div class="col-sm-5"><div class="description-block"><span class="description-text" id="itemname">'+model+'</span></div>  </div><div class="col-sm-2"><div class="description-block"><span class="description-text" id="itemunitpr">'+buyrate+'</span></div></div><div class="col-sm-1"><div class="description-block"><span class="description-text" id="itemqty">'+qty+'</span></div></div><div class="col-sm-2"><div class="description-block"><span class="description-text" id="itemtotal">'+itemfinalprice+'</span></div></div><div class="col-sm-1" id="deleteitem"  key="'+id+'"><div class="description-block bg-red"><i class="glyphicon glyphicon-trash"></i></div></div></div>';

          }

          $('#billitems').append(itemsdraw);

          billtotal += itemfinalprice;
          billtotal = Math.round (billtotal*100) / 100;


          $("#billtotal").html(billtotal.toFixed(2));
          clearfields();

          serials = [];
          rangeSerials = null;
          comSerials = [];

          angular.element(document.getElementById('controllerid')).scope().clearallSls();
          angular.element(document.getElementById('controllerid')).scope().$apply();

        }

      } else {

        clearfields();
        serials = [];
        rangeSerials = null;
        comSerials = [];
        angular.element(document.getElementById('controllerid')).scope().clearallSls();
        angular.element(document.getElementById('controllerid')).scope().$apply();
        $.alert("Product already available in cart!");

      }


    }

    $('#editSerials').on('show.bs.modal', function (event) {
    
      var button = $(event.relatedTarget);
      selecteditemid = button.data('proid');

      var thisitemName = cart[selecteditemid]['model'];
      var thisitemSL = cart[selecteditemid]['serial'];

      angular.element(document.getElementById('controllerid')).scope().showSerialMod(thisitemName, thisitemSL);
      angular.element(document.getElementById('controllerid')).scope().$apply();

    });


    //navigational-------------
    $('#proprice').keyup(function () {

      var thisprice = $('#proprice').val();

      if ($.isNumeric(thisprice)) {
        
        $(this).removeClass("bg-red");
        $("#navadd").removeAttr("disabled")
      } else {
        $(this).addClass("bg-red");
        $("#navadd").attr("disabled", "disabled");
      }
    });

    
    $('#prowholesale').keyup(function () {

      var thisprice = $('#prowholesale').val();

      if ($.isNumeric(thisprice)) {
        
        $(this).removeClass("bg-red");
        $("#navadd").removeAttr("disabled")
      } else {
        $(this).addClass("bg-red");
        $("#navadd").attr("disabled", "disabled");
      }
    });        

    // $('#prosellprice').keyup(function () {

    //   var thisprice = $('#prosellprice').val();
    //   var prodqty =  $("#proqty").val();
    //   if ($.isNumeric(thisprice)) {
        
    //     $(this).removeClass("bg-red");
    //     $("#navadd").removeAttr("disabled");
    //     if(prodqty!=''){

    //       var totalprice = prodqty*thisprice;
    //       $("#navtotalcost").html(totalprice);
    //     }
    //   } else {
    //     $(this).addClass("bg-red");
    //     $("#navadd").attr("disabled", "disabled");
    //   }
    // });


    //easy add
    $('#addeasy').click(function (){

      if (has_serial=='1'){

        if (rangechoice==null) 
        {

          $.alert('Please fillup serial numbers fields first.');

        }
        if(rangechoice == 'withinRange')
        {


            addEasyToInvoice(rangechoice, rangeSerials);

            has_serial=null;

            $(".serialbox").hide();

            $("#has_serial_true").removeAttr('checked').iCheck('update');
            $("#has_serial_false").prop("checked", true).iCheck('update');
            $("[id='rangechoice']").removeAttr('checked').iCheck('update');

            $(".withinRange").hide();
            $(".individual").hide(); 
            $(".combined").hide();   
          
        
        }
        if(rangechoice == 'individual')
        {

          var stoctqty = $("#productqty").val();

         
          if (serials.length==0) {
            $.alert("Please give serials!");
          } else{
            

            addEasyToInvoice(rangechoice, serials);

            has_serial = null;
            $(".serialbox").hide();

            $("#has_serial_true").removeAttr('checked').iCheck('update');
            $("#has_serial_false").prop("checked", true).iCheck('update');
            $("[id='rangechoice']").removeAttr('checked').iCheck('update');

            $(".withinRange").hide();
            $(".individual").hide(); 
            $(".combined").hide();   


          }
        
        }

        if(rangechoice == 'combined')
        {

 

          var stockqty = $("#productqty").val();


          addEasyToInvoice(rangechoice, comSerials);

          has_serial = null;
          $(".serialbox").hide();

          $("#has_serial_true").removeAttr('checked').iCheck('update');
          $("#has_serial_false").prop("checked", true).iCheck('update');
          $("[id='rangechoice']").removeAttr('checked').iCheck('update');

          $(".withinRange").hide();
          $(".individual").hide(); 
          $(".combined").hide(); 

            
        }

      } else {

        addEasyToInvoice(null, null);

      }

      

      
    });

    //navigational add product
    $('#navadd').click(function (){


      if (has_serial=='1'){

        if (rangechoice==null) 
        {

          $.alert('Please give serial numbers first.');

        }
        if(rangechoice == 'withinRange')
        {
          

            addNavToInvoice(rangechoice, rangeSerials);

            has_serial=null;

            $(".serialbox").hide();

            $("#has_serial_true").removeAttr('checked').iCheck('update');
            $("#has_serial_false").prop("checked", true).iCheck('update');
            $("[id='rangechoice']").removeAttr('checked').iCheck('update');

            $(".withinRange").hide();
            $(".individual").hide(); 
            $(".combined").hide();   

          

          
        
        }
        if(rangechoice == 'individual')
        {

          var stoctqty = $("#proqty").val();

          if (serials.length==0) {
          
            $.alert("Please give serials!");
          
          } else {

            var serial = serials;
            

            

            addNavToInvoice(rangechoice, serial);

            has_serial = null;
            $(".serialbox").hide();

            $("#has_serial_true").removeAttr('checked').iCheck('update');
            $("#has_serial_false").prop("checked", true).iCheck('update');
            $("[id='rangechoice']").removeAttr('checked').iCheck('update');

            $(".withinRange").hide();
            $(".individual").hide(); 
            $(".combined").hide();   


            $('#commonpart').val('');
            $('#partstart').val('');
            $('#partend').val('');
            $('#withinrange_rem').val('');

            // var indSLCon = '<div class="col-sm-1" id="itemsl">1.</div><div class="col-sm-11" ><input style="margin-right:2px;" type="text" name="indserial[0]" class="col-sm-6" id="item1" placeholder="Serial"></div>';

            // individualcount = 1;

            // $('.individualslbox').empty();

            // $('.individualslbox').append(indSLCon);

          }
        
        }

        if(rangechoice == 'combined')
        {

          var stockqty = $("#proqty").val();          

          addNavToInvoice(rangechoice, comSerials); 

          has_serial = null;
          $(".serialbox").hide();

          $("#has_serial_true").removeAttr('checked').iCheck('update');
          $("#has_serial_false").prop("checked", true).iCheck('update');
          $("[id='rangechoice']").removeAttr('checked').iCheck('update');

          $(".withinRange").hide();
          $(".individual").hide();
          $(".combined").hide(); 
          
        }

      } else {

        addNavToInvoice(null, null);

      }


      

    });
    
    function addNavToInvoice(serial_type, serial) {

      if (cartProducts.indexOf(parseInt(productid)) == -1) {
        
        cartProducts.push(parseInt(productid));


        itemfinalprice = Math.round (itemtotalprice*100) / 100;

        if (itemfinalprice) {

          var model =  model_no;
          var id = productid;
          
          var buyrate = $('#proprice').val();
          var wholesalerate = $('#prowholesale').val();
          var sellrate = $("#prosellprice").val();
          
          var qty = $("#proqty").val();

          // totalprofit+=itemprofit;
          // $("#totalprofit").html(totalprofit.toFixed(2));

          itemcount++;

          var cartitem = {
             "id" :             id,
             "model" :          model,
             "buyrate" :        buyrate,
             "sellrate" :       sellrate,
             "wholesalerate" :  wholesalerate,
             "qty" :            qty,
             'serial_type' :    serial_type,
             "serial" :         serial
          }; 

          cart[id] = cartitem;


          if (serial) {


            var itemsdraw = '<div class="row" id="row'+id+'"><div class="col-sm-5"><div class="description-block"><span class="description-text" id="itemname">'+model+'</span></div>  </div><div class="col-sm-2"><div class="description-block"><span class="description-text" id="itemunitpr">'+buyrate+'</span></div></div><div class="col-sm-1"><div class="description-block"><span class="description-text" id="itemqtySL'+id+'">'+qty+'</span></div></div><div class="col-sm-2"><div class="description-block"><span class="description-text" id="itemtotalSL'+id+'">'+itemfinalprice+'</span></div></div><div class="col-sm-1" id="deleteitem"  key="'+id+'"><div class="description-block bg-red"><i class="glyphicon glyphicon-trash"></i></div></div><!-- here the serials--><div class="col-md-12"><button type="button" class="btn btn-xs btn-info pull-right" data-toggle="modal" data-target="#editSerials" data-proid="'+ id +'">View Serials</button></div>';

          } else {

            var itemsdraw = '<div class="row" id="row'+id+'"><div class="col-sm-5"><div class="description-block"><span class="description-text" id="itemname">'+model+'</span></div>  </div><div class="col-sm-2"><div class="description-block"><span class="description-text" id="itemunitpr">'+buyrate+'</span></div></div><div class="col-sm-1"><div class="description-block"><span class="description-text" id="itemqty">'+qty+'</span></div></div><div class="col-sm-2"><div class="description-block"><span class="description-text" id="itemtotal">'+itemfinalprice+'</span></div></div><div class="col-sm-1" id="deleteitem"  key="'+id+'"><div class="description-block bg-red"><i class="glyphicon glyphicon-trash"></i></div></div></div>';

          }

          $('#billitems').append(itemsdraw);

          billtotal += itemfinalprice;
          billtotal = Math.round (billtotal*100) / 100;


          $("#billtotal").html(billtotal.toFixed(2));
          clearnavfields();

          serials = [];
          rangeSerials = null;
          comSerials = [];

          angular.element(document.getElementById('controllerid')).scope().clearallSls();
          angular.element(document.getElementById('controllerid')).scope().$apply();

        }

      } else {

        clearfields();
        serials = [];
        rangeSerials = null;
        comSerials = [];
        angular.element(document.getElementById('controllerid')).scope().clearallSls();
        angular.element(document.getElementById('controllerid')).scope().$apply();
        $.alert("Product already available in cart!");


      }
      
    }

      



    //navigational--------------------------------------


    $("#proname").change(function(){

      var code = $("#proname").find('option:selected').attr('code');
      var buyprice = $("#proname").find('option:selected').attr('buyrate');
      var sellrate = $("#proname").find('option:selected').attr('sellrate');
      var warehouse = $("#proname").find('option:selected').attr('warehouse');
      var prowholesale = $("#proname").find('option:selected').attr('wholesale');

      $("#procode").html(code);
      

      $("#prowholesale").html(prowholesale);
      $("#proprice").val(buyprice);
      $("#prosellprice").val(sellrate);
      $("#prowarehouse").html(warehouse);

    });



    //profit
    $('#profinalprice').keyup(function () {
      var finalprice = $('#profinalprice').val();
      if ($.isNumeric(finalprice)) {

        $('#profinalprice').removeClass('bg-red');

        var profit = calculateProfit();

        $('#proprofit').html(profit);

        $('#proprofit').removeClass('bg-green');
        $('#proprofit').removeClass('bg-red');

        if (profit > 0) {

            $('#proprofit').addClass('bg-green');

        } else {
          $('#proprofit').addClass('bg-red');
        }

      } else{
        $('#profinalprice').addClass('bg-red');
      }

    });

    var deleteattemp = 0;
    //function to remove product from cart
    $(document).on("click", "#deleteitem" , function() {
      
      var itemid = $(this).attr('key');
      $('#row'+itemid).remove();
      
      for (var i = 0; i < cart.length; i++) {
        if(cart[i]){
          if (cart[i]['id']==itemid) {
            //this is the matching item

            var deleteprice = cart[i]['buyrate'];
            var deleteqty = cart[i]['qty'];

            var deletetotal = deleteprice*deleteqty;

            billtotal = billtotal  -  deletetotal;
            billtotal = Math.round (billtotal*100) / 100;
            $("#billtotal").html(billtotal.toFixed(2));

            cart.splice(i, 1);
          }
        }
      }
      var index = cartProducts.indexOf(parseInt(itemid));
      if (index !== -1) cartProducts.splice(index, 1);

    });

    // create the bill

    $("#createinvoice").click(function () {

      var supplier = $("#supplier").val();
      var invoice = $("#invoice").val();
      var remarks = $("#invremarks").val();
      var date    = $("#datepicker").val();
      
      var notfilled = '';

      if (supplier=='') {
        notfilled += '"Supplier" ';
      }
      if (invoice=='') {
        notfilled += '"Invoice Number" ';
      }
      if (date=='') {
        notfilled += '"Date"';
      }

      if (supplier=='' || invoice=='' || date=='') {
        
        $.alert("Please fillup "+notfilled);

      } else {

        if (!cart.length > 0) {

          $.alert("Please add products to invoice first!");

        } else {

          if (billtotal>0) {

            $("#createinvoice").html("Creating Invoice"); 

            $("#createinvoice").attr("disabled", "disabled");      

            jQuery.ajax({

                  url : '/public/suppliers/createinvoice',
                  type : 'post',
                  data : {
                    supplier :    supplier,
                    invoice :  invoice,
                    remarks:  remarks,
                    date:     date,
                    cart:     cart
                  },
                  success : function(data) {

                      var returndata = JSON.parse(data);

                      if (returndata.reply=='done') {

                        $.confirm({

                            title: 'Invoice Created!',
                            content: 'Continue to View Invoice',
                            
                            buttons: {
                                continue: function () {
                                    // $.alert('Confirmed!');

                                    var url = "/supplier/invoice/"+returndata.invoice;
                                    window.location.replace(url);

                                }
                                
                            }
                        });
                      }
                     
                      

                    }
                  
              });
          
          } else {
            $.alert("Invoice Total can not be zero!");
          }

          

        }

        

      }

    });
} );

</script>

<script>
  
var app = angular.module('addSerials', ['ui.bootstrap']);

//angular code

// angular
//   .module('addSkills', [])
  app.controller('addSerialsController', function($scope, $http) {

    $scope.selectedItemSL = [];


    $scope.addedserials = [];
    $scope.rangeSLs = [];
    $scope.comaddedserials = [];
    var comrangeSLs = [];
    var comaddedserials = [];

    $scope.addSerial = function() {
      

      if (serials.indexOf($scope.newSerial) == -1) {


        var thisSerial = $scope.newSerial;

        //check into database if the serial already exist
        var config = {
          method : 'POST',
          url : "/public/products/newserial/check/",
          data : {
            'serial' : thisSerial,
          }
        };

        var request = $http(config);

        request.then(function (response) {
          
          if (response.data=='valid') {

            $scope.addedserials.push({'title': thisSerial, 'done':false})


            // serials.push($scope.newSerial)
            serials.push(thisSerial)
            $scope.newSerial = ''

            if (addtype==1) {
              $("#productqty").val(serials.length);
              $("#addeasy").attr('disabled', false);
              calculateEasyItemTotal();
            }

            if (addtype==2) {
              $("#proqty").val(serials.length);
              $("#navadd").attr('disabled', false);
              calculateNavItemTotal();
            }

            return false

          } else if(response.data=='invalid') {

            $.alert("Duplicate serial!");
            $scope.newSerial = ''
            return false;

          }
          
        }),function (error) {
          alert(error.data);
        }

        //serial checking end

        $scope.newSerial = '' 
        return false

      } else {
        $.alert("Duplicate serial!");
        
        $scope.newSerial = ''
        return false;
      }

    }

    $scope.rangeSerial = function() {



      var srartfrom = $scope.startfrom;

      var endto = $scope.endto;

      if (startfrom!="" && endto !="") {

        var startNumber = srartfrom.match(/\d+/g);

        if (!startNumber) {
          $.alert("Invalid Start serial.");

          $scope.startfrom = ''
          $scope.endto = ''
          return false

        }
        var startNumber = startNumber.pop();
        var commonText1 = srartfrom.replace(startNumber.toString(), '');



        var endNumber = endto.match(/\d+/g);

        if (!endNumber) {
          $.alert("Invalid End serial.");

          $scope.startfrom = ''
          $scope.endto = ''
          return false

        }
        var endNumber = endNumber.pop();
        var commonText2 = endto.replace(endNumber.toString(), '');

        

        if (commonText1!=commonText2) {
          $.alert("Serials mismatch!");
        } else {

          //check into database if the serials already exist
          var config = {
            method : 'POST',
            url : "/public/products/newserial/rangecheck",
            data : {
              'commonpart' : commonText1,
              'start'      : startNumber,
              'end'        : endNumber,
            }
          };

          var request = $http(config);

          request.then(function (response) {
            
            if (response.data.valid=='yes') {




              // $scope.rangeSLs = response.data.serials;

              rangeSerials = response.data.serials;

              

              for (var i = 0; i <= rangeSerials.length - 1; i++) {
                $scope.rangeSLs.push({'title': rangeSerials[i], 'done':false});
              }


              if (addtype==1) {
                $("#productqty").val(response.data.serials.length);
                $("#addeasy").attr('disabled', false);
                calculateEasyItemTotal();
              }

              if (addtype==2) {
                $("#proqty").val(response.data.serials.length);
                $("#navadd").attr('disabled', false);
                calculateNavItemTotal();
              }



              return false

            } else if(response.data.valid=='no') {

              $.alert("<p>Duplicate Serials: "+ response.data.duplicates+"</p>");

              $scope.startfrom = ''
              $scope.endto = ''
              return false

            }
            
          }),function (error) {
            alert(error.data);
          }

          //serial checking end

        }

        



      } else $.alert("Please fillup First and Last serials both.");

      $scope.startfrom = ''
      $scope.endto = ''
      return false

    }


    //for combined serials

    $scope.comrangeSerial = function() {

      var srartfrom = $scope.comstartfrom;

      var endto = $scope.comendto;

      if (startfrom!="" && endto !="") {

        var startNumber = srartfrom.match(/\d+/g);

        if (!startNumber) {
          $.alert("Invalid Start serial.");

          $scope.comstartfrom = ''
          $scope.comendto = ''
          return false

        }
        var startNumber = startNumber.pop();
        var commonText1 = srartfrom.replace(startNumber.toString(), '');



        var endNumber = endto.match(/\d+/g);

        if (!endNumber) {
          $.alert("Invalid End serial.");

          $scope.comstartfrom = ''
          $scope.comendto = ''
          return false

        }
        var endNumber = endNumber.pop();
        var commonText2 = endto.replace(endNumber.toString(), '');

        

        if (commonText1!=commonText2) {
          $.alert("Serials mismatch!");
        } else {

          //check into database if the serials already exist
          var config = {
            method : 'POST',
            url : "/public/products/newserial/rangecheck",
            data : {
              'commonpart' : commonText1,
              'start'      : startNumber,
              'end'        : endNumber,
            }
          };

          var request = $http(config);

          request.then(function (response) {
            
            if (response.data.valid=='yes') {

              //only the values
              var responseData = response.data.serials;
              comSerials = comSerials.concat(response.data.serials);
              //

              for (var i = 0; i <= responseData.length - 1; i++) {
                $scope.comaddedserials.push({'title': responseData[i], 'done':false});
              }

              if (addtype==1) {
                $("#productqty").val(comSerials.length);
                $("#addeasy").attr('disabled', false);
                calculateEasyItemTotal();
              }

              if (addtype==2) {
                $("#proqty").val(comSerials.length);
                $("#navadd").attr('disabled', false);
                calculateNavItemTotal();
              }

              return false

            } else if(response.data.valid=='no') {

              $.alert("<p>Duplicate Serials: "+ response.data.duplicates+"</p>");

              $scope.comstartfrom = ''
              $scope.comendto = ''
              return false

            }
            
          }),function (error) {
            alert(error.data);
          }

          //serial checking end

        }

        



      } else $.alert("Please fillup First and Last serials both.");

      $scope.comstartfrom = ''
      $scope.comendto = ''
      return false

    }

    $scope.comaddSerial = function() {
      

      if (comSerials.indexOf($scope.comnewSerial) == -1) {


        var thisSerial = $scope.comnewSerial;

        //check into database if the serial already exist
        var config = {
          method : 'POST',
          url : "/public/products/newserial/check/",
          data : {
            'serial' : thisSerial,
          }
        };

        var request = $http(config);

        request.then(function (response) {
          
          if (response.data=='valid') {

            $scope.comaddedserials.push({'title': thisSerial, 'done':false})

            

            // serials.push($scope.newSerial)
            // comaddedserials.push(thisSerial)
            $scope.comnewSerial = ''

            comSerials.push(thisSerial);

            // comSerials = comrangeSLs.concat(comaddedserials);


            if (addtype==1) {
              $("#productqty").val(comSerials.length);
              $("#addeasy").attr('disabled', false);
              calculateEasyItemTotal();
            }

            if (addtype==2) {
              $("#proqty").val(comSerials.length);
              $("#navadd").attr('disabled', false);
              calculateNavItemTotal();
            }

            return false

          } else if(response.data=='invalid') {

            $.alert("Duplicate serial!");
            $scope.comnewSerial = ''
            return false;

          }
          
        }),function (error) {
          alert(error.data);
        }

        //serial checking end

        $scope.comnewSerial = '' 
        return false

      } else {
        $.alert("Duplicate serial!");
        
        $scope.comnewSerial = ''
        return false;
      }

    }

    



    $scope.deleteSerial = function(index) {  

      $scope.addedserials.splice(index, 1);
      serials.splice(index, 1);

      

      if (addtype==1) {
        $("#productqty").val(serials.length);        
        calculateEasyItemTotal();
      }

      if (addtype==2) {
        $("#proqty").val(serials.length);
        calculateNavItemTotal();
      }

    }

    $scope.rangedeleteSerial = function(index) {
      $scope.rangeSLs.splice(index, 1);
      rangeSerials.splice(index, 1);

      
       

      if (addtype==1) {

        $("#productqty").val(rangeSerials.length);
        calculateEasyItemTotal();
      }

      if (addtype==2) {

        $("#proqty").val(rangeSerials.length);
        calculateNavItemTotal();
      }

      // //rebuild the comSerials
      // comSerials = $scope.comrangeSLs.concat(serials);

    }

    $scope.comdeleteSerial = function(index) {
      $scope.comaddedserials.splice(index, 1);
      comSerials.splice(index, 1);

      

      if (addtype==1) {
        $("#productqty").val(comSerials.length);
        calculateEasyItemTotal();
      }

      if (addtype==2) {
        $("#proqty").val(comSerials.length);
        calculateNavItemTotal();
      }

    }

    $scope.clearallSls = function (argument) {
      $scope.comaddedserials = [];
      $scope.rangeSLs = [];
      $scope.addedserials = [];

    }

    //show selected modal - generate content
    var selectedItemSL = [];
    $scope.showSerialMod = function(thisitemName, thisitemSL) {

        $scope.selectedItemName = thisitemName;
        $scope.selectedItemSL = [];
        selectedItemSL = [];//for serial update

        for (var i = 0; i <= thisitemSL.length - 1; i++) {
          $scope.selectedItemSL.push({'title': thisitemSL[i], 'done':false});
          selectedItemSL.push(thisitemSL[i]);
        }


    }

    $scope.DelSelectedItemSL = function(index) {
      
      if (selectedItemSL.length>1) {

        $scope.selectedItemSL.splice(index, 1);
        selectedItemSL.splice(index, 1);


        var buyrate = cart[selecteditemid]['buyrate'];
        var oldqty = cart[selecteditemid]['qty'];

        var newqty = $scope.selectedItemSL.length;

        cart[selecteditemid]['qty'] = newqty;

        var qtydifference = newqty - oldqty;

        var newItemTotal = buyrate * newqty;

        var differingAmt = newItemTotal - (buyrate * oldqty);

        $("#itemqtySL"+selecteditemid).html(newqty);
        $("#itemtotalSL"+selecteditemid).html(newItemTotal);

        var oldBilltotal = parseFloat($("#billtotal").html());
        var newBilltotal = oldBilltotal + differingAmt;

        billtotal = newBilltotal;

        $("#billtotal").html(newBilltotal.toFixed(2));

        //update cart
        cart[selecteditemid]['serial'] = selectedItemSL;


      } else {
        $.alert("Item must have atlest one serial.")
      }


    }


  })


</script>
</body>
</html>
