<?php

 use App\Helper\Includes\NumberToWord;
 use App\Helper\Includes\BanglaConverter;

include $this->getTemplatePath().'php_includes/db_conx.php';

 $hasSuccess = '';

  if (isset($_SESSION['success'])) {
      
      $_Success = $_SESSION['success'];

      $_SESSION['success'] = '';
    }

  if (isset($_SESSION['error'])) {
      
      $_Error = $_SESSION['error'];

      $_SESSION['error'] = '';
    }

  if (isset($_SESSION['msg'])) {
    
    $_Message = $_SESSION['msg'];

    $_SESSION['msg'] = '';
  }

    
?>


<?php
if ($auth['user']->img!="") {
    $usrimg = 'profileimg/'.$auth['user']->img;
  } else {
    $usrimg = 'dist/img/avatar.png';
  }
?>
 

<!DOCTYPE html>
<html>
<head>
  
<? print $this->fetch('/ui_includes/head.phtml'); ?>

    <!-- autocomplete -->
    <link rel="stylesheet" href="<? echo $baseUrl ?>dist/css/easy-autocomplete.css">
    <!-- autocomplete -->
      <link rel="stylesheet" href="<? echo $baseUrl ?>dist/css/easy-autocomplete.themes.css">
      <!-- Select2 -->
<link rel="stylesheet" href="<?php echo htmlspecialchars($baseUrl); ?>plugins/select2/select2.min.css">
<!-- DataTables -->
  <link rel="stylesheet" href="<?php echo htmlspecialchars($baseUrl); ?>plugins/datatables/dataTables.bootstrap.css">

<!-- iCheck for checkboxes and radio inputs -->
  <link rel="stylesheet" href="<?php echo htmlspecialchars($baseUrl); ?>plugins/iCheck/all.css">

<!-- jQuery Confirmation -->
  <link rel="stylesheet" href="<?php echo htmlspecialchars($baseUrl); ?>dist/css/jquery-confirm.min.css">

    
<style type="text/css">

  .serial_range, .withinRange, .individual, .combined{
    display: none;
  }

</style>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    <? print $this->fetch('/ui_includes/header.phtml'); ?>

  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <? print $this->fetch('/ui_includes/leftpanel.phtml'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    


    <!-- Main content -->
    <section class="content">
      <div class="row">
      
        <div class="col-md-12">
          <!-- here -->
          








            <!-- Horizontal Form -->
          <div class="box box-solid box-default">
            <div class="box-header with-border">
              <h3 class="box-title">Create New Purchase</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form class="form-horizontal" onsubmit="return false;">
            <input type="hidden"  name="formfor" value="addto">
            
              <div class="box-body">


              <!-- here start -->
              <div class="col-md-12">

                <!-- supplier information box -->
                <div class="box-body">

                  <div class="col-md-6">
                    <div class="form-group <? if(isset($errors['supplier'])) echo 'has-error' ?>">
                      <label for="supplier" class="col-sm-3 control-label">Supplier Name</label>

                      <div class="col-sm-8">
                        <select name="supplier" id="supplier" required class="form-control supplier select2" style="width: 100%;">
                                
                          <option value="">Select Supplier</option>
                          <?php
                          $sql = "SELECT * FROM `suppliers` WHERE `active`=1;";
                          $result = mysqli_query($db_conx,$sql );
                          $total_cat = mysqli_num_rows($result);
                          if($total_cat>0){
                            while($row = mysqli_fetch_array($result)){
                              echo "<option value=".$row['id'].">".$row['name']."</option>";
                            }
                          }
                          ?>
                        </select>
                      
                        <? if(isset($errors['supplier'])) { ?>
                        <span class="help-block"><? echo $errors['supplier'][0]; ?></span>

                        <? } ?>
                      </div>

                    </div>
                    <div class="col-md-12">
                      
                      <p class="col-md-6">Address: <span id="sup_addr"></span></p>
                      <p class="col-md-6">Balance: <span id="sup_balance"></span></p>

                    </div>
                    <div class="form-group <? if(isset($errors['remarks'])) echo 'has-error' ?>">
                      <label for="remarks" class="col-sm-3 control-label">Remarks</label>

                      <div class="col-sm-8">
                        <input name="remarks" type="text" class="form-control" id="invremarks" placeholder="Enter Remarks" autocomplete="off" value="<? if(isset($old['remarks'])) echo $old['remarks']; ?>">
                      
                        <? if(isset($errors['remarksSup'])) { ?>
                        <span class="help-block"><? echo $errors['remarks'][0]; ?></span>

                        <? } ?>
                      </div>

                    </div>
                  </div>

                  <div class="col-md-6">
                    
                    <div class="form-group <? if(isset($errors['invoice'])) echo 'has-error' ?>">
                      <label for="invoice" class="col-sm-3 control-label">Invoice Number</label>

                      <div class="col-sm-9">
                        <input name="invoice" type="text" class="form-control" id="invoice" placeholder="Enter Invoice Number" autocomplete="off" value="<? if(isset($old['invoice'])) echo $old['invoice']; ?>" required>
                      
                        <? if(isset($errors['invoice'])) { ?>
                        <span class="help-block"><? echo $errors['invoice'][0]; ?></span>

                        <? } ?>
                      </div>

                    </div>
                    <div class="form-group <? if(isset($errors['invoice_date'])) echo 'has-error' ?>">
                      <label for="datepicker" class="col-sm-3 control-label">Invoice Date</label>

                      <div class="col-sm-9">
                        
                        <div class="input-group date">
                          <div class="input-group-addon">
                            <i class="fa fa-calendar"></i>
                          </div>
                          <input type="text" name="invoice_date" class="form-control pull-right" id="datepicker">
                        </div>
                      
                        <? if(isset($errors['invoice_date'])) { ?>
                        <span class="help-block"><? echo $errors['invoice_date'][0]; ?></span>

                        <? } ?>
                      </div>

                    </div>
                    

                  </div>
                </div>
                <!-- supplier information box end -->

                <!-- tabs start -->
                <div class="col-md-12">

                  <div class="col-md-6">
                    <!-- Custom Tabs -->
                    <div class="nav-tabs-custom">
                      <h4>Add Products to Invoice</h4>
                      <ul class="nav nav-tabs">
                        <li class="active"><a href="#tab_1" data-toggle="tab" aria-expanded="true">Easy</a></li>
                        <li class=""><a href="#tab_2" data-toggle="tab" aria-expanded="false">Navigational</a></li>
                        
                        
                      </ul>
                      <div class="tab-content">
                        <div class="tab-pane active" id="tab_1">
                          <div class="">
                           
                            <!-- /.box-header -->
                            <!-- form start -->
                            <form class="form-horizontal" onsubmit="return false;">
                              <div class="box-body">
                                <div class="form-group">
                                  <label for="productmodel" class="col-sm-3 control-label">Model No</label>

                                  <div class="col-sm-9">
                                    <input type="text" class="form-control" id="productmodel">
                                  </div>
                                  <input type="hidden"  name="productid" id="productid">
                                </div>

                                <div class="form-group">
                                  <label for="productcode" class="col-sm-3 control-label">Code</label>

                                  <div class="col-sm-9">
                                    <input type="text" class="form-control" id="productcode">
                                  </div>
                                </div>
                                <div class="form-group">
                                  
                                  <p class="col-sm-9 control-label pull-right">
                                    <b>Brand: </b> <span id="productbrand"></span> | <b> Group: </b> <span id="productgroup"></span> | <b>In Stock:</b> <span id="availableqty"></span>
                                  </p>

                                </div>


                                <!-- buyrate -->
                                <div class="form-group">
                                  <label for="productprice" class="col-sm-3 control-label">Buying Cost</label>

                                  <div class="col-sm-9">
                                    <input class="form-control" id="productprice">
                                  </div>
                                </div>

                                <div class="form-group">
                                  <label for="productwholesale" class="col-sm-3 control-label">Wholesale Price</label>

                                  <div class="col-sm-9">
                                    <input type="text" class="form-control" id="productwholesale">
                                    
                                  </div>
                                </div>
                                <div class="form-group">
                                  <label for="productsellprice" class="col-sm-3 control-label">Retail Price</label>

                                  <div class="col-sm-9">
                                    <input type="text" class="form-control" id="productsellprice">
                                  </div>
                                </div>
                                <div class="form-group">
                                  <label for="productqty" class="col-sm-3 control-label">Purchased Quantity</label>

                                  <div class="col-sm-9">
                                    <input type="text" class="form-control" id="productqty" placeholder="Quantity">
                                  </div>
                                  <p class="col-sm-9 control-label pull-right"><b>Total Cost: </b> <span id="totalcost"></span></p>
                                </div>
                                

                              </div>
                              <!-- /.box-body -->
                              
                              <div class="box-footer">
                                <button class="btn btn-danger pull-left" id="cleareasy" onclick="clearfields()">Clear</button>
                                <button class="btn btn-success pull-right" id="addeasy" disabled="disabled">Add to Invoice</button>
                              </div>
                              <!-- /.box-footer -->
                            </form>
                          </div>
                        </div>
                        <!-- /.tab-pane -->
                        <div class="tab-pane" id="tab_2">
                          <div class="">
                            
                            <!-- /.box-header -->
                            <!-- form start -->
                            <form class="form-horizontal" onsubmit="return false;">
                              <div class="box-body">
                                <!-- category -->
                                <div class="form-group" id="categoryf">
                                  <label for="procategory" class="col-sm-3 control-label">Category</label>
                                  <div class="col-sm-9">
                                    <select name="category" id="procategory" class="form-control select2 procategory" style="width: 100%;">
                                      <option value="">Please Select</option>
                                      <?php 

                                      $sql = "SELECT * FROM `category` WHERE `active`=1;";
                                    $result = mysqli_query($db_conx,$sql );
                                    $total_cat = mysqli_num_rows($result);
                                    if($total_cat>0){
                                      
                                      while($row = mysqli_fetch_array($result)){
                                        echo "<option value=".$row['id'].">".$row['name']."</option>";
                                        }
                                      }
                                       ?>
                                      
                                    </select>
                                  </div>
                                </div>

                                <!-- brand -->
                                <div class="form-group" id="brandf">
                                  <label for="probrand" class="col-sm-3 control-label">Brand</label>
                                  <div class="col-sm-9">
                                    <select name="probrand" id="probrand" class="form-control probrand select2" style="width: 100%;">
                                      <option value="">Please Select</option>
                                      <?php 

                                    $sql = "SELECT * FROM `brands` WHERE `active`=1;";
                                    $result = mysqli_query($db_conx,$sql );
                                    $total_cat = mysqli_num_rows($result);
                                    if($total_cat>0){
                                      
                                      while($row = mysqli_fetch_array($result)){
                                        echo "<option value=".$row['id'].">".$row['name']."</option>";
                                        }
                                      }
                                       ?>
                                      
                                    </select>
                                  </div>
                                </div>

                                <!-- group -->
                                <div class="form-group">
                                  <label for="probrand" class="col-sm-3 control-label">Group</label>
                                  <div class="col-sm-9">
                                    <select name="progroup" id="progroup" class="form-control progroup select2" style="width: 100%;">
                                      <option value="">Select Category First</option>
                                      

                                      
                                    </select>
                                  </div>
                                </div>

                                <!-- product name -->
                                <!-- brand -->
                                <div class="form-group">
                                  <label for="promodel" class="col-sm-3 control-label">Model No</label>
                                  <div class="col-sm-9">
                                    <select name="promodel" id="promodel" class="form-control promodel select2" style="width: 100%;">
                                      
                                      <option value="">Select Category, Brand First</option>
                                      
                                    </select>
                                  </div>
                                  <input type="hidden"  name="productid" id="productid">
                                </div>

                                <div class="form-group">

                                  <p class="col-sm-9 control-label pull-right">
                                    <b>Code: </b> <span id="procode"></span> | <b>In Stock:</b> <span id="proavailableqty"></span>
                                  </p>
                                </div>
                                
                                <!-- buy rate -->

                                <div class="form-group">
                                  <label for="proprice" class="col-sm-3 control-label">Cost</label>

                                  <div class="col-sm-9">
                                    
                                    <input class="form-control" id="proprice" placeholder="Enter Product Cost" >
                                  </div>
                                </div>

                                <div class="form-group">
                                  
                                  <label for="prowholesale" class="col-sm-3 control-label">Wholesale Price</label>

                                  <div class="col-sm-9">
                                    <input type="text" class="form-control" id="prowholesale">
                                  </div>
                                  
                                </div>

                                
                                <div class="form-group">
                                  <label for="prosellprice" class="col-sm-3 control-label">Retail Price</label>

                                  <div class="col-sm-9">
                                    <input type="text" class="form-control" id="prosellprice">
                                  </div>
                                </div>
                                <div class="form-group">
                                  <label for="proqty" class="col-sm-3 control-label">Purchased Quantity</label>

                                  <div class="col-sm-9">
                                    <input type="text" class="form-control" id="proqty" placeholder="Purchased Quantity">
                                  </div>
                                  <p class="col-sm-9 control-label pull-right"><b>Total Cost: </b> <span id="navtotalcost"></span></p>
                                </div>
                               
                                
                                
                              </div>
                              <!-- /.box-body -->
                              
                              <div class="box-footer">
                                <button class="btn btn-danger pull-left" id="clearnav" onclick="clearnavfields()">Clear</button>
                                <button class="btn btn-success pull-right" id="navadd" disabled="disabled">Add To Invoice</button>
                              </div>
                              <!-- /.box-footer -->
                            </form>
                          </div>
                        </div>
                        
                      </div>
                      <!-- /.tab-content -->
                    </div>
                    <!-- nav-tabs-custom -->
                  </div>

                  <div class="col-md-6">
                    <!-- SERIAL NUMBER Section -->
                    <br><br><br><br><br>
                    <div class="box box-primary">
                      <div class="box-body box-profile">

                        <div class="form-group has_serial <? if(isset($errors['has_serialf'])) echo 'has-error' ?>" id="has_serialf">
                          <div class="col-md-7 text-right" style="padding-top: 5px;">
                            <span style="font-size: 14px;">Does this product has serial number?</span>                      
                          </div>
                          


                          <div class="col-md-5 checkbox" style="text-align: left;">

                            <label class="col-md-6">
                              <input type="radio" name="has_serial" id="has_serial_true" value='1' class="flat-red">
                              Yes
                            </label class="col-md-6">
                            <label>
                              <input type="radio" name="has_serial" id="has_serial_false" value='0' class="flat-red" checked>
                              No
                            </label>
                            
                          </div>

                          <div class="form-group serialbox"  style="display: none;" id="warrantyf">
                            <br>
                            <br>

                              <h4 class="text-center">Serial Distribution</h4>                      

                            <div class="col-md-12 checkbox" style="text-align: left;">

                              <label class="col-md-4">
                                <input type="radio" name="rangechoice" id="rangechoice" value="withinRange" class="flat-red rangechoice">
                                Within Range
                              </label>
                              <label class="col-md-4">
                                <input type="radio" name="rangechoice" id="rangechoice" value='individual' class="flat-red rangechoice">
                                Individual
                              </label>
                              <label class="col-md-4">
                                <input type="radio" name="rangechoice" id="rangechoice" value='combined' class="flat-red rangechoice">
                                Combined
                              </label>
                              
                            </div>

                          </div>

                          <!-- range format for SERIAL WITHIN RANGE -->
                          <div class="col-md-12 withinRange">

                            <div class="form-group" id="commonPart">  
                              <div class="col-md-12 input_box">
                                <div class="col-sm-3">
                                  <label for="commonpart" class="control-label">Common Part</label>
                                </div>
                                <div class="col-sm-9">
                                  <input type="text" name="commonpart" class="form-control" id="commonpart" placeholder="ABCD"/>
                                  
                                </div>
                              </div>
                            </div>


                            <div class="form-group" id="varryingPart">  
                              <div class="col-md-12 input_box">
                                <div class="col-md-4">
                                  <label for="varryingPart" class="control-label">Varrying Part</label>
                                </div>
                                <div class="col-md-8">

                                  <div class="form-group" class="col-md-6">  
                                    
                                    <div class="col-md-4">
                                      <label for="partstart" class="control-label">Start From</label>
                                    </div>
                                    <div class="col-md-8">
                                      <input type="text" name="partstart" class="form-control" id="partstart" placeholder="11">
                                      
                                    </div>
                                   
                                  </div>

                                  <div class="form-group" class="col-md-6">  
                                    
                                    <div class="col-md-4">
                                      <label for="partend" class="control-label">End</label>
                                    </div>
                                    <div class="col-md-8">
                                      <input type="text" name="partend" class="form-control" id="partend" placeholder="25">
                                      
                                    </div>
                                   
                                  </div>
                                   
                                                              
          
                                </div>
                              </div>
                            </div>

                            <div class="form-group" id="commonPart">  
                              <div class="col-md-12 input_box">
                                <div class="col-sm-3">
                                  <label for="withinrange_rem" class="control-label">Remarks</label>
                                </div>
                                <div class="col-sm-9">
                                  <input type="text" name="withinrange_rem" class="form-control" id="withinrange_rem" placeholder="Enter Remarks"/>
                                  
                                </div>
                              </div>
                            </div>
                            
                          </div>
                          <!-- range format for SERIAL WITHIN RANGE  end -->

                          <!-- range format for  INDIVIDUAL SERIAL -->
                          <div class="col-md-12 individual">

                            <div class="box-item individualslbox" id="itemsform">
                              <!-- <div class="col-sm-1" id="itemsl">1.</div>
                              <div class="col-sm-11" >
                                <input style="margin-right:2px;" type="text" name="indserial[0]" class="col-sm-6" id="item1" placeholder="Serial">
                              
                                <input style="margin-left: :2px;" type="text" name="indremark[0]" class="col-sm-5 itemtotal" id="itemrem1" placeholder="Remarks">
                              </div> -->
                            </div>
                            <div class="col-sm-5"></div>
                            <!-- <button type="button" id="addnew" class="col-sm-4 btn bg-gray" style="margin-top: 10px;"><b><i class="fa fa-plus"></i> Add More</b></button>
                            <div class="col-sm-5"></div> -->
                          </div>
                          <!-- range format for  INDIVIDUAL SERIAL  end -->

                          <!-- range format for  Combined SERIAL -->

                          <div class="col-md-12 combined">

                              <div class="form-group" id="commonPart">  
                                <div class="col-md-12 input_box">
                                  <div class="col-sm-3">
                                    <label for="commonPart" class="control-label">Common Part</label>
                                  </div>
                                  <div class="col-sm-9">
                                    <input name="mixcommonpart" type="text" class="form-control" id="mixcommonpart" placeholder="Common Part of the Serials" >
                                    
                                  </div>
                                </div>
                              </div>


                              <div class="form-group" id="varryingPart">  
                                <div class="col-md-12 input_box">
                                  <div class="col-md-4">
                                    <label for="varryingPart" class="control-label">Varrying Part</label>
                                  </div>
                                  <div class="col-md-8">

                                    <div class="form-group" class="col-md-6">  
                                      
                                      <div class="col-md-4">
                                        <label for="varryingPartStart" class="control-label">Start From</label>
                                      </div>
                                      <div class="col-md-8">
                                        <input name="mixstart" type="text" class="form-control" id="mixstart" placeholder="Starting Part">
                                        
                                      </div>
                                     
                                    </div>

                                    <div class="form-group" class="col-md-6">  
                                      
                                      <div class="col-md-4">
                                        <label for="varryingPartEnd" class="control-label">End</label>
                                      </div>
                                      <div class="col-md-8">
                                        <input name="mixend" type="text" class="form-control" id="mixend" placeholder="End Part">
                                        
                                      </div>
                                     
                                    </div>
                                  </div>
                                </div>
                                <div class="form-group" id="commonPart">  
                                  <div class="col-md-12 input_box">
                                    <div class="col-sm-3">
                                      <label for="withinrange_rem" class="control-label">Remarks For Ranges</label>
                                    </div>
                                    <div class="col-sm-9">
                                      <input type="text" name="remarkrangemmix" class="form-control" id="remarkrangemmix" placeholder="Enter Remarks"/>
                                      
                                    </div>
                                  </div>
                                </div>

                                <div class="box-item mixIndslbox" id="itemsformmix">
                                  <!-- <div class="col-sm-1" id="itemsl">1.</div>
                                  <div class="col-sm-11" >
                                    <input style="margin-right:2px;" type="text" name="mixserial[0]" class="col-sm-6" id="mixitem1" placeholder="Serial">
                                  
                                    <input style="margin-left: :2px;" type="text" name="mixremark[0]" class="col-sm-5 itemtotal" id="mixitemrem1" placeholder="Remarks">
                                  </div> -->
                                </div>
                                <div class="col-sm-5"></div>
                                <!-- <button type="button" id="addnewmix" class="col-sm-4 btn bg-gray" style="margin-top: 10px;"><b><i class="fa fa-plus"></i> Add More</b></button> -->
                                <div class="col-sm-5"></div>
                              </div>
                              
                          </div>
                          <!-- range format for  Combined SERIAL  END-->



                          
                        </div>
                        <!-- form-group end -->

                      </div>

                    </div>

                    <!-- SERIAL NUMBER Section  END-->

                    <!-- invoice total -->
                    <div class="box-body bg-gray" id="billitems">
                      <h7 class="widget-user-username">Added Products in this invoice</h7><br>
                      <div class="row">
                        <div class="col-sm-1 border-right">
                          <div class="description-block">
                            <span class="description-text">SL No.</span>
                          </div>
                          <!-- /.description-block -->
                        </div>
                        <!-- /.col -->
                        <div class="col-sm-5 border-right">
                          <div class="description-block">
                            <span class="description-text">Description</span>
                          </div>
                          <!-- /.description-block -->
                        </div>
                        
                        <div class="col-sm-2 border-right">
                          <div class="description-block">
                            <span class="description-text">Unit Price</span>
                          </div>
                          <!-- /.description-block -->
                        </div>
                        <!-- /.col -->
                        <div class="col-sm-1 border-right">
                          <div class="description-block">
                            <span class="description-text">QTY</span>
                          </div>
                          <!-- /.description-block -->
                        </div>
                        <div class="col-sm-3">
                          <div class="description-block">
                            <span class="description-text">Total Price</span>
                          </div>
                          <!-- /.description-block -->
                        </div>
                        <!-- <div class="col-sm-1">
                          <div class="description-block">
                            <span class="description-text">Del</span>
                          </div>
                        </div> -->
                        <!-- /.col -->
                      </div>
                      <!-- /.row -->

                      <!-- draw items -->
                      
                    </div>
                    <div class="box-footer">
                      <h5>Invoice Total: <span id="billtotal"></span>
                            TK</h5>
                      <button id="createinvoice" class="col-md-12 btn btn-success pull-right "><i class="glyphicon glyphicon-shopping-cart" style="margin-right: 10px;"> </i> Create Invoice</button>
                    </div>
                      

                    </div>
                  </div>



                  
                </div>


                <!-- tabs end -->
       
              </div>
              <!-- /.box-body -->
              
              <!-- /.box-footer -->
            </form>
          </div>
          <!-- /.box -->
          <!-- here end -->
          <!-- /.box -->
        </div>
        <!-- end of add category form -->

        <div class="col-md-6">
          
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->

    
  </div>
  <!-- /.content-wrapper -->




  <!-- footer -->
  <? print $this->fetch('/ui_includes/footer.phtml'); ?>

  <!-- Control Sidebar -->
  <? print $this->fetch('/ui_includes/control-sidebar.phtml'); ?>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>bootstrap/js/bootstrap.min.js"></script>


<!-- bootstrap-confirmation.min.js -->

<script src="<?php echo htmlspecialchars($baseUrl); ?>bootstrap/js/bootstrap-confirmation.min.js"></script>


<!-- FastClick -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>dist/js/app.min.js"></script>
<!-- sidebar toggle -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>dist/js/sidebar-toggle.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>dist/js/demo.js"></script>

<!-- autocomplete -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>dist/js/jquery.easy-autocomplete.js"></script>

<!-- Select2 -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/select2/select2.full.min.js"></script>

<!-- DataTables -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/datatables/dataTables.bootstrap.min.js"></script>
<!-- bootstrap datepicker -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/datepicker/bootstrap-datepicker.js"></script>

<!-- iCheck 1.0.1 -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/iCheck/icheck.min.js"></script>

<!-- jQuery Confirmation -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>dist/js/jquery-confirm.min.js"></script>


<script>

  // define variables

  var supplier = null;

  var productid = null;
  var model_no = null;
  var code = null;
  var category = null;
  var brand = null;
  var group = null;
  var has_serial = null;
  var buyrate = null;
  var wholesale_rate = null;
  var sellrate = null;
  var qty = null;
  var groupname = null;
  var itemtotalprice = null;
  var itemcount = 0;
  var billtotal = 0;
  var rangechoice = null;

  var addtype = null;

  var cart = new Array();

  var individualcount = 1;
  var mixcount = 1;

  // variable definition end

  function clearfields(){
      $("#productmodel").val("");
      $("#productid").val("");

      $("#productcategory").val("");
      $("#productbrand").html("");
      $("#productgroup").html("");
      $("#productcode").val("");

      $("#productprice").val("");
      $("#productwholesale").val("");
      $("#productsellprice").val("");
      $("#productqty").val("");
      $("#totalcost").html("");

      model_no = null;
      itemtotalprice = null;
      has_serial = null;
      rangechoice = null;

      $("#addeasy").attr("disabled", "disabled");

      addtype = null;

    }

    function clearnavfields(){
      
      $("#procategory").val("").trigger('change');
      $("#probrand").val("").trigger('change');
      $("#progroup").val("").trigger('change');
      $("#promodel").val("").trigger('change');
      $("#procode").html("");
      $("#proavailableqty").html("");

      $("#proprice").val("");
      $("#prowholesale").val("");

      $("#prosellprice").val("");
      $("#proqty").val("");
      $("#navtotalcost").html("");

      model_no = null;
      itemtotalprice = null;
      has_serial = null;
      rangechoice = null;

      $("#navadd").attr("disabled", "disabled");

      addtype = null;

    }
  
  

  $(".supplier").select2().on("select2:select", function (e) {

      var selected_element = $(e.currentTarget);
      var select_val = selected_element.val();


      $.ajax({

        url : '/public/suppliers/getsupplier',
        type : 'post',
        data : {
          supplier : select_val
        },
        success : function(data) {
          
          var selectedSup = JSON.parse(data);

          if (selectedSup.name) {

            supplier = selectedSup.id;
            $("#sup_addr").html(selectedSup.address);
            $("#sup_balance").html(selectedSup.balance);
          
          }

        }
      });

  });

  $(".procategory").select2().on("select2:select", function (e) {

      var selected_element = $(e.currentTarget);
      var select_val = selected_element.val();

      var selectedbrand = $("#probrand").val();

      nogroup = null;

      // grab the groups for selected category---------------------

      $.ajax({

        url : '/public/suppliers/getcategorygroups',
        type : 'post',
        data : {
          category : select_val,
        },
        success : function(data) {
          

          if (data!='nogroup') {

            $("#progroup").html(data);
          
          }
          if (data=='nogroup') {
            $("#progroup").html('<option value="">No Group Found</option>');
            
          }

        },
        complete: function() {
          
          //any code for group selection must be here ---------------------------------

          $(".progroup").select2().on("select2:select", function (e) {

            var selected_element = $(e.currentTarget);
            var select_val = selected_element.val();

            var selectedcategory = $("#procategory").val();
            var selectedbrand = $("#probrand").val();

            $.ajax({

              url : '/public/suppliers/getproducts',
              type : 'post',
              data : {
                category : selectedcategory,
                brand: selectedbrand,
                group: select_val
              },
              success : function(data) {
                

                if (data!='noproduct') {

                  $("#promodel").html(data);

                
                }
                if (data=='noproduct') {
                  $("#promodel").html('<option value="">No Product Found</option>');

                }

              },
              complete: function() {
                
                $(".promodel").select2();
              }
            });

            


          });
        }
      });

      var selectedgroup = $("#progroup").val();

      //if the category has no group and brand has already selected-----------------
      
      if (selectedbrand!='' && selectedgroup=='') {


        $.ajax({

          url : '/public/suppliers/getproducts',
          type : 'post',
          data : {
            category : select_val,
            brand: selectedbrand
          },
          success : function(data) {
            
            if (data!='noproduct') {

              $("#promodel").html(data);

            
            }
            if (data=='noproduct') {
              $("#promodel").html('<option value="">No Group Found</option>');

            }

          },
          complete: function() {

            $(".promodel").select2();
          }
        });
      }

  });

  $(".probrand").select2().on("select2:select", function (e) {

      var selected_element = $(e.currentTarget);
      var select_val = selected_element.val();

      var selectedcategory = $("#procategory").val();
      var selectedgroup = $("#progroup").val();

      //for each time brand selection-----------------
      
      if (selectedcategory!='') {


        $.ajax({

          url : '/public/suppliers/getproducts',
          type : 'post',
          data : {
            category : selectedcategory,
            brand: select_val,
            group: selectedgroup
          },
          success : function(data) {
            

            if (data!='noproduct') {

              $("#promodel").html(data);

            
            }
            if (data=='noproduct') {
              $("#promodel").html('<option value="">No Group Found</option>');

            }

          },
          complete: function() {
            
            // $(".promodel").select2().on("select2:select", function (e) {

            //   var selected_element = $(e.currentTarget);
            //   var select_val = selected_element.val();
            //   navModelSelected(select_val);

            // });
            $(".promodel").select2();
          }
        });
      }

  });

  $(".progroup").select2();
  $(".promodel").select2();

  $(".promodel").select2().on("select2:select", function (e) {

    var selected_element = $(e.currentTarget);
    var select_val = selected_element.val();
    navModelSelected(select_val);

  });

  function navModelSelected(thisproductid) {
    
    $.ajax({

      url : '/public/suppliers/selectedproductdata',
      type : 'post',
      data : {
        id : thisproductid
      },
      success : function(data) {

        updateNavSelectedModel(data);
        
      }
    });

    


  }

  function updateNavSelectedModel(data) {
    var product = JSON.parse(data);

    productid = product.id;
    model_no = product.model_no;
    code = product.code;
    has_serial = product.has_serial;
    buyrate = product.buy_rate;
    wholesale_rate = product.wholesale_rate;
    sellrate = product.sell_rate;
    qty = product.qty;

    $("#procode").html(code);

    $("#proavailableqty").html(qty);
    $("#proprice").val(buyrate);

    
    $("#prosellprice").val(sellrate);
    $("#prowholesale").val(wholesale_rate);
    $("#proavailableqty").html(qty);



    //show the serial box
    if (has_serial=='1') {
      $("#has_serial_true").prop("checked", true).iCheck('update');
      $("#has_serial_false").removeAttr('checked').iCheck('update');

      $(".serialbox").show();

    } else{
      $("#has_serial_true").removeAttr('checked').iCheck('update');
      $("#has_serial_false").prop("checked", true).iCheck('update');

      $(".serialbox").hide();
    }

    addtype = 2;
  }


  $("#partstart").keyup(function () {

      var thisval = $(this).val();

      if ($.isNumeric(thisval)) {
        
        $(this).removeClass("bg-red");
        $("#addeasy").removeAttr("disabled");
        $("#navadd").removeAttr("disabled");
      } else {
        $(this).addClass("bg-red");
        $("#addeasy").attr("disabled", "disabled");
        $("#navadd").attr("disabled", "disabled");
      }
    });
  $("#partend").keyup(function () {

      var thisval = $(this).val();

      if ($.isNumeric(thisval)) {
        
        $(this).removeClass("bg-red");
        $("#addeasy").removeAttr("disabled");
        $("#navadd").removeAttr("disabled");
      } else {
        $(this).addClass("bg-red");
        $("#addeasy").attr("disabled", "disabled");
        $("#navadd").attr("disabled", "disabled");
      }
    }); 
    $("#mixstart").keyup(function () {

      var thisval = $(this).val();

      if ($.isNumeric(thisval)) {
        
        $(this).removeClass("bg-red");
        $("#addeasy").removeAttr("disabled");
        $("#navadd").removeAttr("disabled");
      } else {
        $(this).addClass("bg-red");
        $("#addeasy").attr("disabled", "disabled");
        $("#navadd").attr("disabled", "disabled");
      }
    }); 
    $("#mixend").keyup(function () {

      var thisval = $(this).val();

      if ($.isNumeric(thisval)) {
        
        $(this).removeClass("bg-red");
        $("#addeasy").removeAttr("disabled");
        $("#navadd").removeAttr("disabled");
      } else {
        $(this).addClass("bg-red");
        $("#addeasy").attr("disabled", "disabled");
        $("#navadd").attr("disabled", "disabled");
      }
    });  

  
  

  //Date picker
  $('#datepicker').datepicker({
     todayHighlight: true,
    autoclose: true
  });

  //Flat red color scheme for iCheck
  $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
    checkboxClass: 'icheckbox_flat-green',
    radioClass: 'iradio_flat-green'
  });

  //for serial number section
  $("input[name='has_serial']").on('ifChecked', function(event){

       if($(this).val()=="1")
       {
          $(".serialbox").show();
       }
       else
       {
          $(".serialbox").hide();
          $(".combined").hide();
          $(".withinRange").hide(); 
          $(".individual").hide(); 
       }

    });
    
    $("input[name='rangechoice']").on('ifChecked', function(event){

      rangechoice = $(this).val();

     if($(this).val()=="withinRange")
     {

        $(".withinRange").show();
        $(".individual").hide(); 
         $(".combined").hide(); 


     } else if($(this).val()=="individual"){

      if (addtype == 1) {

        var prodqty =  $("#productqty").val();

        if (prodqty!='') {

              $('#itemsform').empty();

            for(var i =1 ; i <= prodqty ; i++ ){

            // individualcount = individualcount+1;

            var itemsformcon = '<div class="col-sm-1" id="items'+(i)+'">'+i+'.</div><div class="col-sm-11" ><input style="margin-right:2px;" type="text" name="indseria'+i+';" class="col-sm-6" id="item'+i+'" placeholder="Serial"><input style="margin-right:2px;" type="text" name="indremark' +i+ '" class="col-sm-5 itmprice" id="itemrem'+i+'" placeholder="Remarks" /></div>';

             $("#itemsform").append(itemsformcon);


            }

        } else {
            
            $("input[name=rangechoice]").removeAttr('checked');
            $("input[name=rangechoice]").removeClass("iradio_flat-green");
            $.alert('please give product Quantity valu.');
        }

      } else if(addtype == 2) {

        var prodqty =  $("#proqty").val();

        if (prodqty!='') {

              $('#itemsform').empty();

            for(var i =1 ; i <= prodqty ; i++ ){

            // individualcount = individualcount+1;

            var itemsformcon = '<div class="col-sm-1" id="items'+(i)+'">'+i+'.</div><div class="col-sm-11" ><input style="margin-right:2px;" type="text" name="indseria'+i+';" class="col-sm-6" id="item'+i+'" placeholder="Serial"><input style="margin-right:2px;" type="text" name="indremark' +i+ '" class="col-sm-5 itmprice" id="itemrem'+i+'" placeholder="Remarks" /></div>';

             $("#itemsform").append(itemsformcon);


            }

        } else {
            
            $(this).removeAttr('checked').iCheck('update');
            $(this).removeClass("iradio_flat-green").iCheck('update');
            $.alert('please give product Quantity valu.');
        }

      } else {
            $(this).removeAttr('checked').iCheck('update');
            $("input[name=rangechoice]").removeClass("iradio_flat-green").iCheck('update');
            $.alert('please give product Quantity valu.');
      }

      

        

      

        
      

      // alert(prodqty);
      

      // for(var i =0 ; i<prodqty ;i++){
      //   function individual_serial(){
      //     var individual_serial ='<div>rrr</div>';
          

      //   }

      // }

      $(".individual").show();
      $(".withinRange").hide(); 
      $(".combined").hide(); 

     } else if($(this).val()=="combined"){

      if (addtype==1) {
        var prodqty =  $("#productqty").val();
      } else{
        var prodqty =  $("#proqty").val();
      }

      

      if (!prodqty>0) {

        $("input[name=rangechoice]").removeAttr('checked').iCheck('update');
        $("input[name=rangechoice]").removeClass("iradio_flat-green").iCheck('update');

          $.alert('Please enter product quantity.');
      } else {

        $(".combined").show();
        $(".withinRange").hide(); 
        $(".individual").hide(); 

      }

      

      


      $('#mixend').change(function () {

            var mixstart =  $("#mixstart").val();
            var mixend =  $("#mixend").val();
            var mixtotal = mixend - mixstart;
            var mix_individual =mixtotal - prodqty;
            var individual_box = prodqty - mixtotal;

            if(mixtotal <= 0){

              $('#itemsformmix').empty();

              $.alert('Invalid Range.');
              $("#addeasy").attr("disabled", "disabled");

            }else if (mixtotal > 0) {

              $('#itemsformmix').empty();

              mixcount = individual_box-1;
              
              for(i=1;i<individual_box;i++){
                  var com_itemsformcon='<div class="col-sm-1" id="items'+i+'">'+ i +'</div><div class="col-sm-11" ><input style="margin-right:2px;" type="text" name="mixserial[0]" class="col-sm-6" id="mixitem'+i+'" placeholder="Serial"><input style="margin-left: :2px;" type="text" name="mixremark[0]" class="col-sm-5 itemtota" id="mixitemrem'+i+'" placeholder="Remarks"></div></div>';
                  
                  $("#itemsformmix").append(com_itemsformcon);
                  
                }

                $("#addeasy").removeAttr("disabled")
            }


            // }else if(mixtotal>prodqty){
            //   $.alert('please check product Quantity and given range.');
            // }

            

          

          });


     }

  });

  //draw individual serial input box------------
  
  // $('#addnew').click(function () {

  //   individualcount = individualcount+1;

  //   var itemsformcon = '<div class="col-sm-1" id="itemsl">'+individualcount+'.</div><div class="col-sm-11" ><input style="margin-right:2px;" type="text" name="indserial&#91;'+ (individualcount-1) +'&#93;" class="col-sm-6" id="item'+individualcount+'" placeholder="Serial"><input style="margin-right:2px;" type="text" name="indremark&#91;' + (individualcount-1) + '&#93;" class="col-sm-5 itmprice" id="itemrem'+individualcount+'" placeholder="Remarks" /></div>';

  //   $("#itemsform").append(itemsformcon);

  // });

  
  $('#addnewmix').click(function () {

    mixcount = mixcount+1;

    var itemsformcon = '<div class="col-sm-1" id="itemsl">'+mixcount+'.</div><div class="col-sm-11" ><input style="margin-right:2px;" type="text" name="mixserial&#91;'+ (mixcount-1) +'&#93;" class="col-sm-6" id="mixitem'+mixcount+'" placeholder="Serial"><input style="margin-right:2px;" type="text" name="mixremark&#91;' + (mixcount-1) + '&#93;" class="col-sm-5 itmprice" id="mixitemrem'+mixcount+'" placeholder="Remarks" /></div>';

    $("#itemsformmix").append(itemsformcon);

  });

  //serial section end

  

  



  $(document).ready(function() {


    var optionsname = {
          url: function(phrase) {
            return "/suppliers/purchase/getproductdata?phrase=" + phrase + "&format=json";
          },

          getValue: "model_no",
          list: {

            onSelectItemEvent: function() {
 

              productid = $("#productmodel").getSelectedItemData().id;
              model_no = $("#productmodel").getSelectedItemData().model_no;
              code = $("#productmodel").getSelectedItemData().code;
              category = $("#productmodel").getSelectedItemData().category;
              brand = $("#productmodel").getSelectedItemData().brand;
              group = $("#productmodel").getSelectedItemData().group;
              groupname = $("#productmodel").getSelectedItemData().groupname;
              has_serial = $("#productmodel").getSelectedItemData().has_serial;
              buyrate = $("#productmodel").getSelectedItemData().buyrate;
              wholesale_rate = $("#productmodel").getSelectedItemData().wholesale_rate;
              sellrate = $("#productmodel").getSelectedItemData().sellrate;
              qty = $("#productmodel").getSelectedItemData().qty;

              $("#productcode").val(code).trigger("change");
              $("#productbrand").html(brand).trigger("change");
              $("#productgroup").html(groupname).trigger("change");
              $("#availableqty").html(qty).trigger("change");
              $("#productprice").val(buyrate).trigger("change");

              
              $("#productsellprice").val(sellrate).trigger("change");
              $("#productwholesale").val(wholesale_rate).trigger("change");

              $("#productid").val(productid).trigger("change");

              //show the serial box
              if (has_serial=='1') {
                $("#has_serial_true").prop("checked", true).iCheck('update');
                $("#has_serial_false").removeAttr('checked').iCheck('update');

                $(".serialbox").show();

              } else{
                $("#has_serial_true").removeAttr('checked').iCheck('update');
                $("#has_serial_false").prop("checked", true).iCheck('update');

                $(".serialbox").hide();
              }

              addtype = 1;

              

            }
          },
          template: {
              type: "description",
              fields: {
                  description: "brand"
              }
          },
          theme: "blue-light",

          showAnimation: {
            type: "fade", //normal|slide|fade
            time: 100,
            callback: function() {}
          },

          hideAnimation: {
            type: "slide", //normal|slide|fade
            time: 100,
            callback: function() {}
          }


        };

        //for code search
        var optionscode = {
          url: function(phrase) {
            return "/suppliers/purchase/getproductdata?phrase=" + phrase + "&format=json&type=code";
          },

          getValue: "code",
          list: {

            onSelectItemEvent: function() {

              productid = $("#productcode").getSelectedItemData().id;
              model_no = $("#productcode").getSelectedItemData().model_no;
              code = $("#productcode").getSelectedItemData().code;
              category = $("#productcode").getSelectedItemData().category;
              brand = $("#productcode").getSelectedItemData().brand;
              group = $("#productcode").getSelectedItemData().group;
              groupname = $("#productcode").getSelectedItemData().groupname;
              has_serial = $("#productcode").getSelectedItemData().has_serial;
              buyrate = $("#productcode").getSelectedItemData().buyrate;
              wholesale_rate = $("#productcode").getSelectedItemData().wholesale_rate;
              sellrate = $("#productcode").getSelectedItemData().sellrate;
              qty = $("#productcode").getSelectedItemData().qty;

              $("#productmodel").val(model_no).trigger("change");
              $("#productbrand").html(brand).trigger("change");
              $("#productgroup").html(groupname).trigger("change");
              $("#availableqty").html(qty).trigger("change");
              $("#productprice").val(buyrate).trigger("change");

              
              $("#productsellprice").val(sellrate).trigger("change");
              $("#productwholesale").val(wholesale_rate).trigger("change");

              $("#productid").val(productid).trigger("change");

              //show the serial box
              if (has_serial=='1') {
                $("#has_serial_true").prop("checked", true).iCheck('update');
                $("#has_serial_false").removeAttr('checked').iCheck('update');

                $(".serialbox").show();

              } else{
                $("#has_serial_true").removeAttr('checked').iCheck('update');
                $("#has_serial_false").prop("checked", true).iCheck('update');

                $(".serialbox").hide();
              }

              addtype = 1;

            }
          },
          template: {
              type: "description",
              fields: {
                  description: "brand"
              }
          },
          theme: "blue-light",

          showAnimation: {
            type: "fade", //normal|slide|fade
            time: 100,
            callback: function() {}
          },

          hideAnimation: {
            type: "slide", //normal|slide|fade
            time: 100,
            callback: function() {}
          }


        };

    $("#productmodel").easyAutocomplete(optionsname);
    $("#productcode").easyAutocomplete(optionscode);
  //----------------------------- prices check -----------------------------------
    $('#productprice').keyup(function () {

      var thisprice = $('#productprice').val();

      if ($.isNumeric(thisprice)) {
        
        $(this).removeClass("bg-red");
        $("#addeasy").removeAttr("disabled");
      } else {
        $(this).addClass("bg-red");
        $("#addeasy").attr("disabled", "disabled");
      }
    });  

    $('#productwholesale').keyup(function () {

      var thisprice = $('#productwholesale').val();

      if ($.isNumeric(thisprice)) {
        
        $(this).removeClass("bg-red");
        $("#addeasy").removeAttr("disabled")
      } else {
        $(this).addClass("bg-red");
        $("#addeasy").attr("disabled", "disabled");
      }
    });        

    $('#productsellprice').keyup(function () {

      var thisprice = $('#productsellprice').val();
      var prodqty =  $("#productqty").val();
      if ($.isNumeric(thisprice)) {
        
        $(this).removeClass("bg-red");
        $("#addeasy").removeAttr("disabled");
        if(prodqty!=''){

          var totalprice = prodqty*thisprice;
          $("#totalcost").html(totalprice);
        }
      } else {
        $(this).addClass("bg-red");
        $("#addeasy").attr("disabled", "disabled");
      }
    });

    //qty calculation
    $('#productqty').keyup(function () {

      var prodqty =  $("#productqty").val();
      var prodprice =  $("#productprice").val();
      if ($.isNumeric(prodqty)) {

        $("#productqty").removeClass("bg-red");

        itemtotalprice = prodqty*prodprice;
        $("#totalcost").html(itemtotalprice);
        $("#addeasy").removeAttr("disabled");
      } else {
        jQuery("#productqty").addClass("bg-red");
        $("#addeasy").attr("disabled", "disabled");
      }
    });      

    $('#addeasy').click(function (){

      if (has_serial=='1'){

        if (rangechoice==null) 
        {

          $.confirm({
              title: 'Are you sure?',
              content: 'You are adding this product without giving serial information!',
              buttons: {
                  confirm: function () {
                      addEasyToInvoice(null, null);

                      has_serial=null;
                  },
                  cancel: function () {
                      $.alert('Please fillup serial numbers fields first.');
                  }
              }
          });

        }
        if(rangechoice == 'withinRange')
        {

          var commonpart = $('#commonpart').val();
          var start = $('#partstart').val();
          var end = $('#partend').val();
          var serialremark = $('#withinrange_rem').val();
          // raju match qty
          var prodqty =  $("#productqty").val();
          var total_qty = end - start ;
          

          if(prodqty!=total_qty+1){

            $.alert('Invalid Range!');
          
          }else{

            var serial = {
              "type" :        rangechoice,
              "commonpart" :  commonpart,
              "start" :       start,
              "end" :         end,
              "serialremark" : serialremark
            };

            addEasyToInvoice(rangechoice, serial);

            has_serial=null;

            $(".serialbox").hide();

            $("#has_serial_true").removeAttr('checked').iCheck('update');
            $("#has_serial_false").prop("checked", true).iCheck('update');
            $("[id='rangechoice']").removeAttr('checked').iCheck('update');

            $(".withinRange").hide();
            $(".individual").hide(); 
            $(".combined").hide();   


            $('#commonpart').val('');
            $('#partstart').val('');
            $('#partend').val('');
            $('#withinrange_rem').val('');

            var indSLCon = '<div class="col-sm-1" id="itemsl">1.</div><div class="col-sm-11" ><input style="margin-right:2px;" type="text" name="indserial[0]" class="col-sm-6" id="item1" placeholder="Serial"><input style="margin-left: :2px;" type="text" name="indremark[0]" class="col-sm-5 itemtotal" id="itemrem1" placeholder="Remarks"></div>';
            individualcount = 1;

            $('.individualslbox').empty();

            $('.individualslbox').append(indSLCon);

          }
          
          

          
        
        }
        if(rangechoice == 'individual')
        {

          var serial = new Array();
          


          for (var i = 1; i <= individualcount; i++) {
            
            var individualserial = {
              "serial" :        $('#item'+i).val(),
              "serialremark" :  $('#itemrem'+i).val()
            };

            serial.push(individualserial);

          }

          addEasyToInvoice(rangechoice, serial);

          has_serial = null;
          $(".serialbox").hide();

          $("#has_serial_true").removeAttr('checked').iCheck('update');
          $("#has_serial_false").prop("checked", true).iCheck('update');
          $("[id='rangechoice']").removeAttr('checked').iCheck('update');

          $(".withinRange").hide();
          $(".individual").hide(); 
          $(".combined").hide();   


          $('#commonpart').val('');
          $('#partstart').val('');
          $('#partend').val('');
          $('#withinrange_rem').val('');

          var indSLCon = '<div class="col-sm-1" id="itemsl">1.</div><div class="col-sm-11" ><input style="margin-right:2px;" type="text" name="indserial[0]" class="col-sm-6" id="item1" placeholder="Serial"><input style="margin-left: :2px;" type="text" name="indremark[0]" class="col-sm-5 itemtotal" id="itemrem1" placeholder="Remarks"></div>';

          individualcount = 1;

          $('.individualslbox').empty();

          $('.individualslbox').append(indSLCon);
        
        }

        if(rangechoice == 'combined')
        {


          var serial = new Array();
          
          var serialmixrange = {
            'mixcommonpart':  $('#mixcommonpart').val(),
            'mixstart':       $('#mixstart').val(),
            'mixend':         $('#mixend').val(),
            'remarkrangemmix': $('#remarkrangemmix').val()
          }

          serial.push(serialmixrange);


          for (var i = 1; i <= mixcount; i++) {
            
            var individualserial = {
              "serial" :        $('#mixitem'+i).val(),
              "serialremark" :  $('#mixitemrem'+i).val()
            };

            serial.push(individualserial);

          }

          addEasyToInvoice(rangechoice, serial);

          has_serial = null;
          $(".serialbox").hide();

          $("#has_serial_true").removeAttr('checked').iCheck('update');
          $("#has_serial_false").prop("checked", true).iCheck('update');
          $("[id='rangechoice']").removeAttr('checked').iCheck('update');

          $(".combined").hide(); 

          $('#mixcommonpart').val('');
          $('#mixstart').val('');
          $('#mixend').val('');
          $('#remarkrangemmix').val('');

          var mixIndSLCon = '<div class="col-sm-1" id="itemsl">1.</div><div class="col-sm-11" ><input style="margin-right:2px;" type="text" name="mixserial[0]" class="col-sm-6" id="mixitem1" placeholder="Serial"><input style="margin-left: :2px;" type="text" name="mixremark[0]" class="col-sm-5 itemtotal" id="mixitemrem1" placeholder="Remarks">';

          mixcount = 1;

          $('.mixIndslbox').empty()

          $('.mixIndslbox').append(mixIndSLCon);     
        
        }

      } else {

        addEasyToInvoice(null, null);

      }

      

      
    });

    function addEasyToInvoice(serial_type, serial) {
      
      itemfinalprice = Math.round (itemtotalprice*100) / 100;

      if (itemfinalprice) {

        var model =  model_no;
        var id = productid;
        
        var buyrate = $('#productprice').val();
        var wholesalerate = $('#productwholesale').val();
        var sellrate = $("#productsellprice").val();
        
        var qty = $("#productqty").val();

        // totalprofit+=itemprofit;
        // $("#totalprofit").html(totalprofit.toFixed(2));

        itemcount++;

        var cartitem = {
           "id" :             id,
           "model" :          model,
           "buyrate" :        buyrate,
           "sellrate" :       sellrate,
           "wholesalerate" :  wholesalerate,
           "qty" :            qty,
           'serial_type' :    serial_type, 
           "serial" :         serial
        }; 

        cart.push(cartitem);

        var itemsdraw = '<div class="row" id="row'+id+'"><div class="col-sm-1"><div class="description-block"><span class="description-text" id="itemnum" >'+itemcount+'</span></div></div><div class="col-sm-5"><div class="description-block"><span class="description-text" id="itemname">'+model+'</span></div>  </div><div class="col-sm-2"><div class="description-block"><span class="description-text" id="itemunitpr">'+buyrate+'</span></div></div><div class="col-sm-1"><div class="description-block"><span class="description-text" id="itemqty">'+qty+'</span></div></div><div class="col-sm-2"><div class="description-block"><span class="description-text" id="itemtotal">'+itemfinalprice+'</span></div></div><div class="col-sm-1"><div class="description-block"></div></div></div>';

        $('#billitems').append(itemsdraw);

        billtotal += itemfinalprice;
        billtotal = Math.round (billtotal*100) / 100;


        $("#billtotal").html(billtotal.toFixed(2));
        clearfields();

      }


    }


    //navigational-------------
    $('#proprice').keyup(function () {

      var thisprice = $('#proprice').val();

      if ($.isNumeric(thisprice)) {
        
        $(this).removeClass("bg-red");
        $("#navadd").removeAttr("disabled")
      } else {
        $(this).addClass("bg-red");
        $("#navadd").attr("disabled", "disabled");
      }
    });

    
    $('#prowholesale').keyup(function () {

      var thisprice = $('#prowholesale').val();

      if ($.isNumeric(thisprice)) {
        
        $(this).removeClass("bg-red");
        $("#navadd").removeAttr("disabled")
      } else {
        $(this).addClass("bg-red");
        $("#navadd").attr("disabled", "disabled");
      }
    });        

    $('#prosellprice').keyup(function () {

      var thisprice = $('#prosellprice').val();
      var prodqty =  $("#proqty").val();
      if ($.isNumeric(thisprice)) {
        
        $(this).removeClass("bg-red");
        $("#navadd").removeAttr("disabled");
        if(prodqty!=''){

          var totalprice = prodqty*thisprice;
          $("#navtotalcost").html(totalprice);
        }
      } else {
        $(this).addClass("bg-red");
        $("#navadd").attr("disabled", "disabled");
      }
    });

    //qty calculation
    $('#proqty').keyup(function () {

      var prodqty =  $("#proqty").val();
      var prodprice =  $("#prosellprice").val();
      if ($.isNumeric(prodqty)) {

        $("#proqty").removeClass("bg-red");

        itemtotalprice = prodqty*prodprice;

        $("#navtotalcost").html(itemtotalprice);
        $("#navadd").removeAttr("disabled");
      } else {
        jQuery("#proqty").addClass("bg-red");
        $("#navadd").attr("disabled", "disabled");
      }
    });

    


    //navigational add product
    $('#navadd').click(function (){


      if (has_serial=='1'){

        if (rangechoice==null) 
        {

          $.confirm({
              title: 'Are you sure?',
              content: 'You are adding this product without giving serial information!',
              buttons: {
                  confirm: function () {
                      addNavToInvoice(null, null);

                      has_serial=null;
                  },
                  cancel: function () {
                      $.alert('Please fillup serial numbers fields first.');
                  }
              }
          });

        }
        if(rangechoice == 'withinRange')
        {

          var commonpart = $('#commonpart').val();
          var start = $('#partstart').val();
          var end = $('#partend').val();
          var serialremark = $('#withinrange_rem').val();
          
          var serial = {
            "type" :        rangechoice,
            "commonpart" :  commonpart,
            "start" :       start,
            "end" :         end,
            "serialremark" : serialremark
          };

          addNavToInvoice(rangechoice, serial);

          has_serial=null;

          $(".serialbox").hide();

          $("#has_serial_true").removeAttr('checked').iCheck('update');
          $("#has_serial_false").prop("checked", true).iCheck('update');
          $("[id='rangechoice']").removeAttr('checked').iCheck('update');

          $(".withinRange").hide();
          $(".individual").hide(); 
          $(".combined").hide();   


          $('#commonpart').val('');
          $('#partstart').val('');
          $('#partend').val('');
          $('#withinrange_rem').val('');

          var indSLCon = '<div class="col-sm-1" id="itemsl">1.</div><div class="col-sm-11" ><input style="margin-right:2px;" type="text" name="indserial[0]" class="col-sm-6" id="item1" placeholder="Serial"><input style="margin-left: :2px;" type="text" name="indremark[0]" class="col-sm-5 itemtotal" id="itemrem1" placeholder="Remarks"></div>';
          individualcount = 1;

          $('.individualslbox').empty();

          $('.individualslbox').append(indSLCon);
        
        }
        if(rangechoice == 'individual')
        {

          var serial = new Array();
          

          for (var i = 1; i <= individualcount; i++) {
            
            var individualserial = {
              "serial" :        $('#item'+i).val(),
              "serialremark" :  $('#itemrem'+i).val()
            };

            serial.push(individualserial);

          }

          addNavToInvoice(rangechoice, serial);

          has_serial = null;
          $(".serialbox").hide();

          $("#has_serial_true").removeAttr('checked').iCheck('update');
          $("#has_serial_false").prop("checked", true).iCheck('update');
          $("[id='rangechoice']").removeAttr('checked').iCheck('update');

          $(".withinRange").hide();
          $(".individual").hide(); 
          $(".combined").hide();   


          $('#commonpart').val('');
          $('#partstart').val('');
          $('#partend').val('');
          $('#withinrange_rem').val('');

          var indSLCon = '<div class="col-sm-1" id="itemsl">1.</div><div class="col-sm-11" ><input style="margin-right:2px;" type="text" name="indserial[0]" class="col-sm-6" id="item1" placeholder="Serial"><input style="margin-left: :2px;" type="text" name="indremark[0]" class="col-sm-5 itemtotal" id="itemrem1" placeholder="Remarks"></div>';

          individualcount = 1;

          $('.individualslbox').empty();

          $('.individualslbox').append(indSLCon);
        
        }

        if(rangechoice == 'combined')
        {

          var serial = new Array();
          
          var serialmixrange = {
            'mixcommonpart':  $('#mixcommonpart').val(),
            'mixstart':       $('#mixstart').val(),
            'mixend':         $('#mixend').val(),
            'remarkrangemmix': $('#remarkrangemmix').val()
          }

          serial.push(serialmixrange);

          for (var i = 1; i <= mixcount; i++) {
            
            var individualserial = {
              "serial" :        $('#mixitem'+i).val(),
              "serialremark" :  $('#mixitemrem'+i).val()
            };

            serial.push(individualserial);

          }

          addNavToInvoice(rangechoice, serial); 

          has_serial = null;
          $(".serialbox").hide();

          $("#has_serial_true").removeAttr('checked').iCheck('update');
          $("#has_serial_false").prop("checked", true).iCheck('update');
          $("[id='rangechoice']").removeAttr('checked').iCheck('update');

          $(".combined").hide(); 

          $('#mixcommonpart').val('');
          $('#mixstart').val('');
          $('#mixend').val('');
          $('#remarkrangemmix').val('');

          var mixIndSLCon = '<div class="col-sm-1" id="itemsl">1.</div><div class="col-sm-11" ><input style="margin-right:2px;" type="text" name="mixserial[0]" class="col-sm-6" id="mixitem1" placeholder="Serial"><input style="margin-left: :2px;" type="text" name="mixremark[0]" class="col-sm-5 itemtotal" id="mixitemrem1" placeholder="Remarks">';

          mixcount = 1;

          $('.mixIndslbox').empty()

          $('.mixIndslbox').append(mixIndSLCon);        
        
        }

      }


      

    });
    
    function addNavToInvoice(serial_type, serial) {


      itemfinalprice = Math.round (itemtotalprice*100) / 100;

      if (itemfinalprice) {

        var model =  model_no;
        var id = productid;
        
        var buyrate = $('#proprice').val();
        var wholesalerate = $('#prowholesale').val();
        var sellrate = $("#prosellprice").val();
        
        var qty = $("#proqty").val();

        // totalprofit+=itemprofit;
        // $("#totalprofit").html(totalprofit.toFixed(2));

        itemcount++;

        var cartitem = {
           "id" :             id,
           "model" :          model,
           "buyrate" :        buyrate,
           "sellrate" :       sellrate,
           "wholesalerate" :  wholesalerate,
           "qty" :            qty,
           'serial_type' :    serial_type, 
           "serial" :         serial
        }; 

        cart.push(cartitem);

        var itemsdraw = '<div class="row" id="row'+id+'"><div class="col-sm-1"><div class="description-block"><span class="description-text" id="itemnum" >'+itemcount+'</span></div></div><div class="col-sm-5"><div class="description-block"><span class="description-text" id="itemname">'+model+'</span></div>  </div><div class="col-sm-2"><div class="description-block"><span class="description-text" id="itemunitpr">'+buyrate+'</span></div></div><div class="col-sm-1"><div class="description-block"><span class="description-text" id="itemqty">'+qty+'</span></div></div><div class="col-sm-2"><div class="description-block"><span class="description-text" id="itemtotal">'+itemfinalprice+'</span></div></div><div class="col-sm-1"><div class="description-block"></div></div></div>';

        $('#billitems').append(itemsdraw);

        billtotal += itemfinalprice;
        billtotal = Math.round (billtotal*100) / 100;


        $("#billtotal").html(billtotal.toFixed(2));
        clearnavfields();

      }
      
    }
    

    $('#paidamt').keyup(function () {
        $("#returnamt").val("");
        $("#dueamt").val("");


        var paidamt = parseFloat($("#paidamt").val());

        if (paidamt>billtotal) {

          returnamt=paidamt - billtotal;
          $("#returnamt").val(returnamt);

        } else if(paidamt<billtotal){

          dueamt=billtotal - paidamt;
          $("#dueamt").val(dueamt);
        }
          

      });

      



    //navigational--------------------------------------


    $("#proname").change(function(){

      var code = $("#proname").find('option:selected').attr('code');
      var buyprice = $("#proname").find('option:selected').attr('buyrate');
      var sellrate = $("#proname").find('option:selected').attr('sellrate');
      var warehouse = $("#proname").find('option:selected').attr('warehouse');
      var prowholesale = $("#proname").find('option:selected').attr('wholesale');

      $("#procode").html(code);
      

      $("#prowholesale").html(prowholesale);
      $("#proprice").val(buyprice);
      $("#prosellprice").val(sellrate);
      $("#prowarehouse").html(warehouse);

    });

    //qty calculation
    $('#proqty').keyup(function () {

      var prodqty =  $("#proqty").val();
      var prodprice =  $("#prosellprice").val();

      if ($.isNumeric(prodqty)) {
        jQuery("#proqty").removeClass("bg-red");
        var totalprice = prodqty*prodprice;
        
        $("#prototalprice").html(totalprice);


      } else {
        jQuery("#proqty").addClass("bg-red");
      }
    });

    //profit calculation
    function calculateProfit(){
      var finalprice = $('#profinalprice').val();
      var buyprice = $('#proprice').html();
      var sellqty = $('#proqty').val();
      var profit = finalprice-(buyprice*sellqty);
      return profit;
    }
    //check
    $("#prosamerate").click(function () {
        
        if($('#prosamerate').is(':checked')){
          
          var prodprice =  $("#prosellprice").val();
          var sellqty = $('#proqty').val();
          var total = prodprice*sellqty;

          $('#profinalprice').val(total);

          var profit = calculateProfit();

          $('#proprofit').html(profit);

          $('#proprofit').removeClass('bg-green');
          $('#proprofit').removeClass('bg-red');

          if (profit > 0) {
              $('#proprofit').addClass('bg-green');
          } else {
            $('#proprofit').addClass('bg-red');
          }

        }

    });

    //profit
    $('#profinalprice').keyup(function () {
      var finalprice = $('#profinalprice').val();
      if ($.isNumeric(finalprice)) {

        $('#profinalprice').removeClass('bg-red');

        var profit = calculateProfit();

        $('#proprofit').html(profit);

        $('#proprofit').removeClass('bg-green');
        $('#proprofit').removeClass('bg-red');

        if (profit > 0) {

            $('#proprofit').addClass('bg-green');

        } else {
          $('#proprofit').addClass('bg-red');
        }

      } else{
        $('#profinalprice').addClass('bg-red');
      }

    });

    //price change calculation
    $('#prosellprice').keyup(function () {

      var prodqty =  $("#proqty").val();
      var prodprice =  $("#prosellprice").val();

      if ($.isNumeric(prodprice)) {
        
        jQuery("#prosellprice").removeClass("bg-red");

        if(prodqty!=''){

          var totalprice = prodqty*prodprice;
        
          $("#prototalprice").html(totalprice);
        }

      } else {
        $("#prosellprice").addClass("bg-red");
      }
    });


    // create the bill

    $("#createinvoice").click(function () {

      var supplier = $("#supplier").val();
      var invoice = $("#invoice").val();
      var remarks = $("#invremarks").val();
      var date    = $("#datepicker").val();
      
      var notfilled = '';

      if (supplier=='') {
        notfilled += '"Supplier" ';
      }
      if (invoice=='') {
        notfilled += '"Invoice Number" ';
      }
      if (date=='') {
        notfilled += '"Date"';
      }

      if (supplier=='' || invoice=='' || date=='') {
        
        $.alert("Please fillup "+notfilled);

      } else {

        $("#createinvoice").html("Creating Invoice"); 

        $("#createinvoice").attr("disabled", "disabled");      

        jQuery.ajax({

              url : '/public/suppliers/createinvoice',
              type : 'get',
              data : {
                supplier :    supplier,
                invoice :  invoice,
                remarks:  remarks,
                date:     date,
                cart:     cart
              },
              success : function(data) {

                    var returndata = JSON.parse(data);

                    if (returndata.reply=='done') {

                      $.confirm({

                          title: 'Invoice Created!',
                          content: 'Continue to View Invoice',
                          
                          buttons: {
                              continue: function () {
                                  // $.alert('Confirmed!');

                                  var url = "/supplier/invoice/"+returndata.invoice;
                                  window.location.replace(url);

                              }
                              
                          }
                      });
                    }
                   
                    

                  }
                
            });

      }

    });
} );

</script>
</body>
</html>
