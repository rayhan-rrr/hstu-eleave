<?php 

namespace App\Controllers;

use App\Models\Admin;
use App\Models\Accounts\AccountDailyCash;
use App\Models\Accounts\AccountTransactions;
use App\Models\Accounts\AccountChecks;
use App\Models\Accounts\AccountCash;

use App\Models\Accounts\AccountBank;
use App\Models\Accounts\AccountBankAC;
use App\Models\Accounts\AccountAsset;
use App\Models\Accounts\AccountRevenue;
use App\Models\Accounts\AccountCustomer;

use App\Models\Sales\SalesInvoice;

use App\Controllers\Controller;

use Respect\Validation\Validator as v;


class BalanceController extends Controller
{

	public function todaysBalanceAction($request, $response)
	{

		if(!$this->auth->check())
		{
			return $response->withRedirect($this->router->pathFor('auth.login'));
		}
		
		$balance = AccountDailyCash::where('date', date('Y-m-d'))->first();


		$this->container->view->addAttribute('Title', "Today's Account");

		$this->container->view->addAttribute('balance', $balance);


		return $this->view->render($response, "modules/balance/todaysAccount.phtml");


	}

	public function openBalancePostAction($request, $response)
	{

		if(!$this->auth->check())
		{
			return $response->withRedirect($this->router->pathFor('auth.login'));
		}

		$validation = $this->validator->validate($request, [

			'opening_balance'	=> v::notEmpty()->numeric(),
			'note'				=> v::stringType(),

		]);

		if ($validation->failed()) {
	
			return $response->withRedirect($this->router->pathFor('balance.today'));
			
		}

		$balance = AccountDailyCash::where('date', date('Y-m-d'))->first();

		if (!$balance) {

			$openingBalance = $request->getParam('opening_balance');
			$note = $request->getParam('note');

			$balance = AccountDailyCash::create([

					'date'      		=> date('Y-m-d'),
					'opening_balance'   => $openingBalance,
					'balance' 			=> $openingBalance,
					'opening_note'		=> $note,
					'created_by' 		=> $_SESSION['user'],
					'active'		=> '1',

				]);


			$_SESSION['success'] = 'success';

			$_SESSION['msg'] = "Account Balance Opened successfully!";

			return $response->withRedirect($this->router->pathFor('balance.today'));

		}


		$_SESSION['error'] = "Account Balance Already Opened!";

		return $response->withRedirect($this->router->pathFor('balance.today'));


	}

	public function overviewAction($request, $response)
	{

		if(!$this->auth->check())
		{
			return $response->withRedirect($this->router->pathFor('auth.login'));
		}
		

		$this->container->view->addAttribute('Title', "Accounts Overview");


		return $this->view->render($response, "modules/balance/overview.phtml");


	}

	public function unprocessedChequeAction($request, $response)
	{

		if(!$this->auth->check())
		{
			return $response->withRedirect($this->router->pathFor('auth.login'));
		}
		

		$this->container->view->addAttribute('Title', "Unprocessed Cheque");


		return $this->view->render($response, "modules/balance/unprocessedCheque.phtml");


	}

	public function getUnprocessedAction($value='')
	{
		if(!$this->auth->check())
		{
			return $response->withRedirect($this->router->pathFor('auth.login'));
		}



		$db_conx = $this->DbConnect->connect();



		// storing  request (ie, get/post) global array to a variable  
		$requestData= $_REQUEST;

		// echo $requestData['start']."<br>";
		// echo $requestData['length']; die();


		$columns = array( 
		// datatable column index  => database column name
			0 =>'check_num', 
			1 => 'bank',
			2 => 'branch',
			3 => 'amount',
			4 => 'invoice',
			5 => 'customer'
		);




		// getting total number records without any search
		$sql = "SELECT * FROM (SELECT account_checks.id, account_checks.invoice_id, account_checks.amount, account_checks.check_num, account_checks.bank, account_checks.branch, account_checks.check_date, sales_invoice.invoice, (SELECT name FROM customers WHERE id=sales_invoice.customer) customer, account_checks.active, account_checks.status FROM account_checks LEFT JOIN sales_invoice ON account_checks.invoice_id=sales_invoice.id) res WHERE active='1' AND status='Pending' ";
		$query=mysqli_query($db_conx, $sql) or die("/public/products/getproducts: error");
		$totalData = mysqli_num_rows($query);
		$totalFiltered = $totalData;  // when there is no search parameter then total number rows = total number filtered rows.




		$sql = "SELECT * FROM (SELECT account_checks.id, account_checks.invoice_id, account_checks.amount, account_checks.check_num, account_checks.bank, account_checks.branch, account_checks.check_date, sales_invoice.invoice, (SELECT name FROM customers WHERE id=sales_invoice.customer) customer, account_checks.active, account_checks.status FROM account_checks LEFT JOIN sales_invoice ON account_checks.invoice_id=sales_invoice.id) res ";
		$sql.=" WHERE 1 = 1 AND active='1' AND status='Pending' ";

		// getting records as per search parameters
		if( !empty($requestData['columns'][0]['search']['value']) ){   //name
			$sql.=" AND check_num LIKE '%".$requestData['columns'][0]['search']['value']."%' ";
		}
		if( !empty($requestData['columns'][1]['search']['value']) ){  //code
			$sql.=" AND bank LIKE '%".$requestData['columns'][1]['search']['value']."%' ";
		}
		if( !empty($requestData['columns'][2]['search']['value']) ){  //code
			$sql.=" AND branch LIKE '%".$requestData['columns'][2]['search']['value']."%' ";
		}
		if( !empty($requestData['columns'][3]['search']['value']) ){  //code
			$sql.=" AND invoice LIKE '%".$requestData['columns'][3]['search']['value']."%' ";
		}
		if( !empty($requestData['columns'][4]['search']['value']) ){  //code
			$sql.=" AND customer LIKE '%".$requestData['columns'][4]['search']['value']."%' ";
		}

		$query=mysqli_query($db_conx, $sql) or die("/public/products/getproducts: error 1");
		$totalFiltered = mysqli_num_rows($query); // when there is a search parameter then we have to modify total number filtered rows as per search result.
			
		$sql.=" ORDER BY ". $columns[$requestData['order'][0]['column']]."   ".$requestData['order'][0]['dir']."   LIMIT ".$requestData['start']." ,".$requestData['length']."   ";  // adding length

		$query=mysqli_query($db_conx, $sql) or die("/public/products/getproducts: error 2");

			


		$data = array();
		while( $row=mysqli_fetch_array($query) ) {  // preparing an array
			$nestedData=array(); 

			$nestedData[] = "<span><a href='/balance/chequedetails/".$row['id']."'>".$row["check_num"]."</a></span>";

			

		    $nestedData[] = $row["bank"];


		    $nestedData[] = $row["branch"];
			
			$nestedData[] = $row["amount"];

			$nestedData[] = $row["invoice"];
				
			$nestedData[] = $row["customer"];
			
			
			$data[] = $nestedData;
		}



		$json_data = array(
					"draw"            => intval( $requestData['draw'] ),   // for every request/draw by clientside , they send a number as a parameter, when they recieve a response/data they first check the draw number, so we are sending same number in draw. 
					"recordsTotal"    => intval( $totalData ),  // total number of records
					"recordsFiltered" => intval( $totalFiltered ), // total number of records after searching, if there is no searching then totalFiltered = totalData
					"data"            => $data   // total data array
					);

		echo json_encode($json_data);  // send data as json format
	}


	public function chequeDetailsAction($request, $response, $args)
	{

		if(!$this->auth->check())
		{
			return $response->withRedirect($this->router->pathFor('auth.login'));
		}
		
		$chequeId = $args['id'];

		$cheque = AccountChecks::find($chequeId);

		if ($cheque) {
	
			$this->container->view->addAttribute('Title', "Cheque Details");
			$this->container->view->addAttribute('cheque', $cheque);

			return $this->view->render($response, "modules/balance/chequeDetails.phtml");
		}

		$_SESSION['error'] = 'error';
		$_SESSION['msg'] = "No Cheque Found!";
		return $response->withRedirect($this->router->pathFor('balance.chequeall'));


	}

	public function withdrawPostAction($request, $response, $args)
	{

		if(!$this->auth->check())
		{
			return $response->withRedirect($this->router->pathFor('auth.login'));
		}
		


		$chequeId = $request->getParam('chequeid');

		$cheque = AccountChecks::find($chequeId);

		if ($cheque) {
			
			$cheque_type = $request->getParam('cheque_type');

			$bankid = $request->getParam('bankid');

			$bankname = $request->getParam('bankname');
			$branchname = $request->getParam('branchname');
			$withdrawDate = $request->getParam('withdrawDate');
			$note = $request->getParam('checknote');

			$dateformat =  explode( '/', $withdrawDate );
			$month = $dateformat[0];
			$day = $dateformat[1];
			$year = $dateformat[2];

			$withdrawDate = $year."-".$month."-".$day;


			$validation = $this->validator->validate($request, [
				'bankname'		=> v::stringType(),
				'branchname'	=> v::stringType(),
				'withdrawDate'  => v::notEmpty()->stringType(),
				'cheque_type'	=> v::notEmpty()->stringType(),
			]);

			if ($cheque_type=='Account Payee') {
				
				$validation = $this->validator->validate($request, [

					'bankid'		=> v::notEmpty()->numeric(),
				
				]);

			}

			if ($validation->failed()) {
				
				$_SESSION['error'] = 'error';
				$_SESSION['msg'] = 'Wrong input! Please try again.';
				return $response->withRedirect('/balance/chequedetails/'.$cheque->id);
				
			}

			if ($cheque_type=='Account Payee') {
				
				$cheque->cheque_type 	= $cheque_type;
				$cheque->w_bank_id 	= $bankid;
				$cheque->w_date 	= $withdrawDate;
				$cheque->remarks 	= $note;

				$cheque->save();


			}

			if ($cheque_type=='Bearer') {
				
				$cheque->cheque_type 	= $cheque_type;
				$cheque->w_bank 	= $bankname;
				$cheque->w_branch 	= $branchname;
				$cheque->w_date 	= $withdrawDate;
				$cheque->remarks 	= $note;

				$cheque->save();


				$accountCash = AccountCash::create([

					'invoice'		=> $cheque->id,
					'inv_type'		=> 'accounts_cheque',
					'debit'			=> $cheque->amount,
					'note'			=> 'Balance from cheque is transferred to cash.',
					'created_by'	=> $_SESSION['user'],
					'active'		=> 1

				]);

				$dailyCash = AccountDailyCash::where('date', date('Y-m-d'))->first();

				$dailyCash->balance = $dailyCash->balance + $cheque->amount;

				$dailyCash->save();
			}

			$cheque->save();

			if ($tocash) {
				


				$accountCash = AccountCash::create([

					'invoice'		=> $cheque->id,
					'inv_type'		=> 'accounts_cheque',
					'debit'			=> $tocashAmount,
					'note'			=> 'Balance from cheque is transferred to cash.',
					'created_by'	=> $_SESSION['user'],
					'active'		=> 1

				]);

				//effects the daily cash

				$dailyCash = AccountDailyCash::where('date', date('Y-m-d'))->first();

				$dailyCash->balance = $dailyCash->balance +$tocashAmount;

				$dailyCash->save();


				//rest of the amount goes to bank
				if ($tocashAmount<$cheque->amount) {


					//that means it has some amount to transfer to bank.

					if ($cheque->invoice_id && $cheque->type='sales') {

						$invoice = SalesInvoice::find($cheque->invoice_id);


						$accountBank = AccountBank::create([

							'invoice'		=> $invoice->id,
							'inv_type'		=> 'sales',
							'debit'			=> $cheque->amount - $tocashAmount,
							'check_num'		=> $cheque->check_num,
							'note'			=> 'Cheque from sales invoice is withdrawed and partial amount is transferred to cash.',
							'created_by'	=> $_SESSION['user'],
							'active'		=> 1

						]);

					} else {
						//if cheque is not from sales invoice
						
						$accountBank = AccountBank::create([

							'invoice'		=> $cheque->id,
							'inv_type'		=> 'accounts_cheque',
							'debit'			=> $cheque->amount - $tocash,
							'check_num'		=> $cheque->check_num,
							'note'			=> 'Cheque is withdrawed and partial amount is transferred to cash.',
							'created_by'	=> $_SESSION['user'],
							'active'		=> 1

						]);

					}

					//----------both cash and bank effect-------

					$transaction = AccountTransactions::create([

						'event'			=> 'Cheque withdrawed.',
						'type'			=> 'accounts',
						'amount'		=> $cheque->amount,
						'date'			=> date('Y-m-d'),
						'cash_effect'	=> 'Dr',
						'bank_effect'	=> 'Dr',
						'invoice'		=> $cheque->id,
						'invoice_type'	=> 'accounts_cheque',
						'created_by'	=> $_SESSION['user'],
						'active'		=> 1

					]);
					
					

				} else {

					//else means no amount to transfer to bank. full amount is goint to cash. that means only cash effect

					// cash effect only

					$transaction = AccountTransactions::create([

						'event'			=> 'Cheque withdrawed.',
						'type'			=> 'accounts',
						'amount'		=> $cheque->amount,
						'date'			=> date('Y-m-d'),
						'cash_effect'	=> 'Dr',
						'invoice'		=> $cheque->id,
						'invoice_type'	=> 'accounts_cheque',
						'created_by'	=> $_SESSION['user'],
						'active'		=> 1

					]);
				} 


				
			} else {
				//no amount is transfered to cash. full amount is entering bank.

				//-------bank effect only------

				$transaction = AccountTransactions::create([

					'event'			=> 'Cheque withdrawed.',
					'type'			=> 'accounts',
					'amount'		=> $cheque->amount,
					'date'			=> date('Y-m-d'),
					'bank_effect'	=> 'Dr',
					'invoice'		=> $cheque->id,
					'invoice_type'	=> 'accounts_cheque',
					'created_by'	=> $_SESSION['user'],
					'active'		=> 1

				]);


				if ($cheque->invoice_id && $cheque->type='sales') {

					$invoice = SalesInvoice::find($cheque->invoice_id);


					$accountBank = AccountBank::create([

						'invoice'		=> $invoice->id,
						'inv_type'		=> 'sales',
						'debit'			=> $cheque->amount,
						'check_num'		=> $cheque->check_num,
						'note'			=> 'Cheque from sales invoice is withdrawed.',
						'created_by'	=> $_SESSION['user'],
						'active'		=> 1

					]);

				} else {

					//if cheque is not from sales invoice
					
					$accountBank = AccountBank::create([

						'invoice'		=> $cheque->id,
						'inv_type'		=> 'accounts_cheque',
						'debit'			=> $cheque->amount,
						'check_num'		=> $cheque->check_num,
						'note'			=> 'Cheque is withdrawed.',
						'created_by'	=> $_SESSION['user'],
						'active'		=> 1

					]);

				}

			}

			if ($cheque->invoice_id && $cheque->type='sales') {
					
				$invoice = SalesInvoice::find($cheque->invoice_id);

				$amount_paid = $invoice->amount_paid;

				$new_amount_paid = $amount_paid + $tocashAmount;

				$invoice->amount_paid = $new_amount_paid;

				$invoice->save();


				//as it is an invoice cheque, credit the amount to customer
				$customerAccount = AccountCustomer::create([

					'invoice'		=> $invoice->id,
					'inv_type'		=> 'sales',
					'credit'		=> $cheque->amount,
					'note'			=> 'Cheques withdrawed successfully',
					'created_by'	=> $_SESSION['user'],
					'active'		=> 1

				]);

				//needed to do here because we are varifying all cheques now
				$cheque->status = 'Complete';

				$cheque->save();

				$allChecksOfInvoice = AccountChecks::where('invoice_id', $cheque->invoice_id)->get();

				$count = 0;
				$varify = 0;


				foreach ($allChecksOfInvoice as $cheques) {
					
					$count++;

					if ($cheques->status=='Complete') {
						
						$varify++;
					}
				}

				//complete the invoice
				if ($varify==$count) {
					
					$invoice->payment_status = 'Complete';
					$invoice->save();
					
				}

				

			} ///-----process else condition for cheques that are not from sales invoice

			//finally complete the cheque(needed if cheque is not from sales invoice)
			$cheque->status = 'Complete';
			$cheque->active = 0;

			$cheque->save();


			$_SESSION['success'] = 'success';

			$_SESSION['msg'] = "Cheque withdrawed successfully!";

			return $response->withRedirect($this->router->pathFor('balance.overview'));
			

		}

		$_SESSION['error'] = 'error';

		$_SESSION['msg'] = "No Cheque Found!";

		return $response->withRedirect($this->router->pathFor('balance.overview'));

	}

	public function bankSetupAction($request, $response)
	{
		if(!$this->auth->check())
		{
			return $response->withRedirect($this->router->pathFor('auth.login'));
		}
		

		$this->container->view->addAttribute('Title', "Bank Account Setup");


		return $this->view->render($response, "modules/balance/bankSetup.phtml");
	}

	public function bankSetupPostAction($request, $response)
	{
		
		if(!$this->auth->check())
		{
			return $response->withRedirect($this->router->pathFor('auth.login'));
		}

		$validation = $this->validator->validate($request, [

			'account_name'		=> v::notEmpty()->stringType(),
			'account_number'	=> v::notEmpty()->stringType(),
			'bank'				=> v::notEmpty()->stringType(),
			'branch'			=> v::notEmpty()->stringType(),
			'account_type'		=> v::stringType(),
			'opening_balance'	=> v::numeric(),
			'note'				=> v::stringType(),

		]);


		if ($validation->failed()) {
	
			return $response->withRedirect($this->router->pathFor('balance.bank.new'));
			
		}

		$account = AccountBankAC::create([

					'account_name'			=> $request->getParam('account_name'),
					'account_no'			=> $request->getParam('account_number'),
					'bank'					=> $request->getParam('bank'),
					'branch'				=> $request->getParam('branch'),
					'account_type'			=> $request->getParam('account_type'),
					'opening_balance'		=> $request->getParam('opening_balance'),
					'note'					=> $request->getParam('note'),
					'created_by'			=> $_SESSION['user'],
					'active'				=> 1

				]);

		$_SESSION['success'] = 'success';
		$_SESSION['msg'] = 'Bank Account created successfully!';

		return $response->withRedirect('/users/bank/'.$account->id);


	}

	public function bankAccountDetailsAction($request, $response, $args)
	{
		if(!$this->auth->check())
		{
			return $response->withRedirect($this->router->pathFor('auth.login'));
		}

		$account_id = $args['id'];
		
		$account = AccountBankAC::find($account_id);

		if ($account) {
			
			$this->container->view->addAttribute('Title', "Bank Account Details");
			$this->container->view->addAttribute('account', $account);

			return $this->view->render($response, "modules/balance/bankAccountDetails.phtml");

		}

		$_SESSION['error'] = 'error';
		$_SESSION['msg'] = 'No Account Found!';

		return $response->withRedirect($this->router->pathFor('balance.bank.all'));


		
	}

	public function allBanksAction($request, $response)
	{
		if(!$this->auth->check())
		{
			return $response->withRedirect($this->router->pathFor('auth.login'));
		}
		

		$this->container->view->addAttribute('Title', "All Bank Accounts");


		return $this->view->render($response, "modules/balance/allAccounts.phtml");
	}
	
}







/////---------backup code
public function withdrawPostAction($request, $response, $args)
	{

		if(!$this->auth->check())
		{
			return $response->withRedirect($this->router->pathFor('auth.login'));
		}
		


		$chequeId = $request->getParam('chequeid');

		$cheque = AccountChecks::find($chequeId);

		if ($cheque) {
			
			
			$bankname = $request->getParam('bankname');
			$branchname = $request->getParam('branchname');
			$withdrawDate = $request->getParam('withdrawDate');
			$comchecknote = $request->getParam('comchecknote');
			$note = $request->getParam('note');
			$tocash = $request->getParam('tocash');
			$tocashAmount = $request->getParam('tocashAmount');

			$dateformat =  explode( '/', $withdrawDate );
			$month = $dateformat[0];
			$day = $dateformat[1];
			$year = $dateformat[2];

			$withdrawDate = $year."-".$month."-".$day;


			$validation = $this->validator->validate($request, [
				'bankname'		=> v::notEmpty()->stringType(),
				'branchname'	=> v::notEmpty()->stringType(),
				'withdrawDate'  => v::notEmpty()->stringType(),
			]);

			if ($tocash) {
				
				$validation = $this->validator->validate($request, [

					'tocashAmount'		=> v::notEmpty()->numeric(),
				
				]);

			}

			if ($validation->failed()) {
				
				$_SESSION['error'] = 'error';
				$_SESSION['msg'] = 'Wrong input! Please try again.';
				return $response->withRedirect('/balance/chequedetails/'.$cheque->id);
				
			}

			$cheque->w_bank 	= $bankname;
			$cheque->w_branch 	= $branchname;
			$cheque->w_date 	= $withdrawDate;
			$cheque->w_note 	= $comchecknote;
			$cheque->remarks 	= $note;

			$cheque->save();

			if ($tocash) {
				


				$accountCash = AccountCash::create([

					'invoice'		=> $cheque->id,
					'inv_type'		=> 'accounts_cheque',
					'debit'			=> $tocashAmount,
					'note'			=> 'Balance from cheque is transferred to cash.',
					'created_by'	=> $_SESSION['user'],
					'active'		=> 1

				]);

				//effects the daily cash

				$dailyCash = AccountDailyCash::where('date', date('Y-m-d'))->first();

				$dailyCash->balance = $dailyCash->balance +$tocashAmount;

				$dailyCash->save();


				//rest of the amount goes to bank
				if ($tocashAmount<$cheque->amount) {


					//that means it has some amount to transfer to bank.

					if ($cheque->invoice_id && $cheque->type='sales') {

						$invoice = SalesInvoice::find($cheque->invoice_id);


						$accountBank = AccountBank::create([

							'invoice'		=> $invoice->id,
							'inv_type'		=> 'sales',
							'debit'			=> $cheque->amount - $tocashAmount,
							'check_num'		=> $cheque->check_num,
							'note'			=> 'Cheque from sales invoice is withdrawed and partial amount is transferred to cash.',
							'created_by'	=> $_SESSION['user'],
							'active'		=> 1

						]);

					} else {
						//if cheque is not from sales invoice
						
						$accountBank = AccountBank::create([

							'invoice'		=> $cheque->id,
							'inv_type'		=> 'accounts_cheque',
							'debit'			=> $cheque->amount - $tocash,
							'check_num'		=> $cheque->check_num,
							'note'			=> 'Cheque is withdrawed and partial amount is transferred to cash.',
							'created_by'	=> $_SESSION['user'],
							'active'		=> 1

						]);

					}

					//----------both cash and bank effect-------

					$transaction = AccountTransactions::create([

						'event'			=> 'Cheque withdrawed.',
						'type'			=> 'accounts',
						'amount'		=> $cheque->amount,
						'date'			=> date('Y-m-d'),
						'cash_effect'	=> 'Dr',
						'bank_effect'	=> 'Dr',
						'invoice'		=> $cheque->id,
						'invoice_type'	=> 'accounts_cheque',
						'created_by'	=> $_SESSION['user'],
						'active'		=> 1

					]);
					
					

				} else {

					//else means no amount to transfer to bank. full amount is goint to cash. that means only cash effect

					// cash effect only

					$transaction = AccountTransactions::create([

						'event'			=> 'Cheque withdrawed.',
						'type'			=> 'accounts',
						'amount'		=> $cheque->amount,
						'date'			=> date('Y-m-d'),
						'cash_effect'	=> 'Dr',
						'invoice'		=> $cheque->id,
						'invoice_type'	=> 'accounts_cheque',
						'created_by'	=> $_SESSION['user'],
						'active'		=> 1

					]);
				} 


				
			} else {
				//no amount is transfered to cash. full amount is entering bank.

				//-------bank effect only------

				$transaction = AccountTransactions::create([

					'event'			=> 'Cheque withdrawed.',
					'type'			=> 'accounts',
					'amount'		=> $cheque->amount,
					'date'			=> date('Y-m-d'),
					'bank_effect'	=> 'Dr',
					'invoice'		=> $cheque->id,
					'invoice_type'	=> 'accounts_cheque',
					'created_by'	=> $_SESSION['user'],
					'active'		=> 1

				]);


				if ($cheque->invoice_id && $cheque->type='sales') {

					$invoice = SalesInvoice::find($cheque->invoice_id);


					$accountBank = AccountBank::create([

						'invoice'		=> $invoice->id,
						'inv_type'		=> 'sales',
						'debit'			=> $cheque->amount,
						'check_num'		=> $cheque->check_num,
						'note'			=> 'Cheque from sales invoice is withdrawed.',
						'created_by'	=> $_SESSION['user'],
						'active'		=> 1

					]);

				} else {

					//if cheque is not from sales invoice
					
					$accountBank = AccountBank::create([

						'invoice'		=> $cheque->id,
						'inv_type'		=> 'accounts_cheque',
						'debit'			=> $cheque->amount,
						'check_num'		=> $cheque->check_num,
						'note'			=> 'Cheque is withdrawed.',
						'created_by'	=> $_SESSION['user'],
						'active'		=> 1

					]);

				}

			}

			if ($cheque->invoice_id && $cheque->type='sales') {
					
				$invoice = SalesInvoice::find($cheque->invoice_id);

				$amount_paid = $invoice->amount_paid;

				$new_amount_paid = $amount_paid + $tocashAmount;

				$invoice->amount_paid = $new_amount_paid;

				$invoice->save();


				//as it is an invoice cheque, credit the amount to customer
				$customerAccount = AccountCustomer::create([

					'invoice'		=> $invoice->id,
					'inv_type'		=> 'sales',
					'credit'		=> $cheque->amount,
					'note'			=> 'Cheques withdrawed successfully',
					'created_by'	=> $_SESSION['user'],
					'active'		=> 1

				]);

				//needed to do here because we are varifying all cheques now
				$cheque->status = 'Complete';

				$cheque->save();

				$allChecksOfInvoice = AccountChecks::where('invoice_id', $cheque->invoice_id)->get();

				$count = 0;
				$varify = 0;


				foreach ($allChecksOfInvoice as $cheques) {
					
					$count++;

					if ($cheques->status=='Complete') {
						
						$varify++;
					}
				}

				//complete the invoice
				if ($varify==$count) {
					
					$invoice->payment_status = 'Complete';
					$invoice->save();
					
				}

				

			} ///-----process else condition for cheques that are not from sales invoice

			//finally complete the cheque(needed if cheque is not from sales invoice)
			$cheque->status = 'Complete';
			$cheque->active = 0;

			$cheque->save();


			$_SESSION['success'] = 'success';

			$_SESSION['msg'] = "Cheque withdrawed successfully!";

			return $response->withRedirect($this->router->pathFor('balance.overview'));
			

		}

		$_SESSION['error'] = 'error';

		$_SESSION['msg'] = "No Cheque Found!";

		return $response->withRedirect($this->router->pathFor('balance.overview'));

	}