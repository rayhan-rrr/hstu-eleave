<?php

 use App\Helper\Includes\NumberToWord;
 use App\Helper\Includes\BanglaConverter;
  use App\Helper\AccountsInfo;
  use App\Helper\Includes\AddedFunctions;
  use App\Helper\CustomerAccount;

include $this->getTemplatePath().'php_includes/NumberToWord.php';

include $this->getTemplatePath().'php_includes/db_conx.php';

 $hasSuccess = '';

  if (isset($_SESSION['success'])) {
      
      $_Success = $_SESSION['success'];

      $_SESSION['success'] = '';
    }

  if (isset($_SESSION['error'])) {
      
      $_Error = $_SESSION['error'];

      $_SESSION['error'] = '';
    }

  if (isset($_SESSION['msg'])) {
    
    $_Message = $_SESSION['msg'];

    $_SESSION['msg'] = '';
  }

?>


<?php
if ($auth['user']->img!="") {
    $usrimg = 'profileimg/'.$auth['user']->img;
  } else {
    $usrimg = 'dist/img/avatar.png';
  }
?>
 

<!DOCTYPE html>
<html>
<head>
  
<? print $this->fetch('/ui_includes/head.phtml'); ?>

    <!-- autocomplete -->
    <link rel="stylesheet" href="<? echo $baseUrl ?>dist/css/easy-autocomplete.css">
    <!-- autocomplete -->
      <link rel="stylesheet" href="<? echo $baseUrl ?>dist/css/easy-autocomplete.themes.css">
      <!-- Select2 -->
<link rel="stylesheet" href="<?php echo htmlspecialchars($baseUrl); ?>plugins/select2/select2.min.css">
<!-- DataTables -->
  <link rel="stylesheet" href="<?php echo htmlspecialchars($baseUrl); ?>plugins/datatables/dataTables.bootstrap.css">
  <!-- iCheck for checkboxes and radio inputs -->
  <link rel="stylesheet" href="<?php echo htmlspecialchars($baseUrl); ?>plugins/iCheck/all.css">
  
<!-- jQuery Confirmation -->
  <link rel="stylesheet" href="<?php echo htmlspecialchars($baseUrl); ?>dist/css/jquery-confirm.min.css">

  <!-- rating -->
  <link href="<?php echo htmlspecialchars($baseUrl); ?>plugins/rating/css/star-rating.min.css" media="all" rel="stylesheet" type="text/css" />
  <link href="<?php echo htmlspecialchars($baseUrl); ?>plugins/rating/themes/krajee-svg/theme.css" media="all" rel="stylesheet" type="text/css" />

  <!-- jquery -->
  <script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/jQuery/jquery-2.2.3.min.js"></script>

  <script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/jQueryUI/jquery-ui.min.js"></script>

  

  <!-- angular -->
  <script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/angular/angular.min.js"></script>

  <!-- angular animate -->
  <script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/angular/angular-animate.min.js"></script>

  <!-- angular animate bootstrap -->
  <script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/angular/ui-bootstrap-tpls.min.js"></script>





  
  
  
  
  <style type="text/css">
    input.ng-invalid {
        background-color:yellow;
    }
  </style>
    
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    <? print $this->fetch('/ui_includes/header.phtml'); ?>

  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <? print $this->fetch('/ui_includes/leftpanel.phtml'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

    <!-- Content Header (Page header) -->
    <section class="content-header">
      
      <?php if (isset($_Error) && $_Error == 'error') { ?>
        <div class="alert alert-danger alert-dismissible">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
          <h4><? echo $_Message; ?></h4>
        </div>
      <?php } ?>


      <?php if (isset($_Success) && $_Success == 'success') { ?>
        <div class="alert alert-success alert-dismissible">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
          <? echo $_Message;?>
        </div>
      <?php } ?>
      
    </section>

    <!-- Main content -->
    <section class="invoice">
      <!-- title row -->
      <div class="row invoice-info">
        <div class="col-sm-4 invoice-col">
          Customer
          <address>
            <strong><? echo $customer->name; ?></strong><br>
            <? echo $customer->address; ?><br>
            <? if ($customer->remark) {
                    echo $customer->remark."<br>"; 
                }  ?>
            Phone: <? echo $customer->mobile; ?><br>
            Email: <? echo $customer->email; ?><br>
            <strong>Customer Type: </strong><? echo $customer->type; ?>
          </address>

              <?

              if (CustomerAccount::getCustomerBalance($invoice->customer)>0) { ?>
                

                Customer has credit or amount paid in advanced.
                <p>Advanced or Credit Amount: <? echo CustomerAccount::getCustomerBalance($invoice->customer)?> TK</p>

                


              <? } 

              ?>
          

        </div>
        <!-- /.col -->
        <div class="col-sm-4 invoice-col">
            <h4>Invoice Payment</h4>
            <h4><? echo $invoice->invoice; ?></h4>
            
        </div>
        <!-- /.col -->
        <div class="col-sm-4 invoice-col">

          <h4><b>Invoiced Amount:</b> <? echo AddedFunctions::taka_format($invoice->total_amount) ?> TK<br></h4>
          <h4><b>Discount: </b><? echo AddedFunctions::taka_format($invoice->discount) ?> TK <br></h4>
          <b>Date:</b> <? echo date(' d M, Y', strtotime($invoice->created_at)); ?><br>
          <b>Time:</b> <? echo date(' h:m:s A', strtotime($invoice->created_at)); ?><br>
          <b>Created By:</b> <? echo $created_by; ?><br>
          
          
        </div>
        <hr>

        <!-- <form action="/sales/payment/submit" method="get"> -->
          
        
        <div class="col-md-12" ng-app="app">
          
          <div ng-controller="TabCtrl">

            <uib-tabset class="tabbable">
              <uib-tab heading="Full Payment" ng-attr-active="tabs[0].active">
                
                <!-- full payment section -->
                <div class="row">
                  <br>

                  <div class="form-group col-md-7" id="changediscount">
                    <div class="col-md-12">
                      <h4 class="col-sm-5 text-right">Final Discount</h4>

                      <div class="col-sm-7">
                       <input name="newdiscount" type="number" class="form-control" id="newdiscount" placeholder="Enter new discount amount" ng-model="newdiscount" ng-keyup="finalpay = totalamt - newdiscount; remainingAmtToPay =  getRemainingAmt( finalpay, credit )" ng-change="finalpay = totalamt - newdiscount" my-directive-test>

                      </div>

                    </div>

                    <?
                      if (CustomerAccount::getCustomerBalance($invoice->customer)>0) { ?>
        
                    <div class="col-md-12">
                      
                      <h4 class="col-sm-5 text-right">Credit Adjustment </h4>
                      <div class="col-sm-7">
                        <input name="creditamt" type="number" class="form-control" id="creditamt" placeholder="Credit Adjusting" ng-disabled="creditAdjustable" ng-model="creditamt">
                      </div>

                    </div>

                    <? } ?>

                    <div class="col-md-12">
                      
                      <h4 class="col-sm-5 text-right">Received Amount</h4>


                      <div class="col-sm-7">
                        <input name="paid" type="number" class="form-control" id="paid" placeholder="Enter amount" ng-disabled="finalpay<0" ng-model="amountReceived" ng-keyup="amountToReturn = checkAmountToReturn(amountReceived, remainingAmtToPay, newdiscount); remainingAmtToPay = getRemainingAmt( finalpay, credit); isDisabled = amountToReturn<0" ng-change="isDisabled = amountToReturn<0" my-directive-test>
                      </div>

                      {{ newdiscount }}
                      <p>{{ amountToReturn }}</p>
                    </div>
                    
                    <!-- credit ajdustment -->
                    

                    
                  </div>

                  <div class="form-group col-md-5">


                    <h4 class="col-sm-12" ng-show="true" ng-class="{'bg-red': finalpay < 0}">Final Amount to Pay: {{ finalpay }} TK</h4>

                    <?

                    if (CustomerAccount::getCustomerBalance($invoice->customer)>0) { ?>

                    <h4 class="col-sm-12" ng-show="true" ng-class="{'bg-red': finalpay < 0}">Remaining Amount: {{ remainingAmtToPay }} TK</h4>

                    <? } ?>
                    <div class="col-sm-12">
                      <div class="col-sm-5 text-right">
                        <label for="behavior" class="control-label">Customer Payment Rating:</label>
                      </div>
                      <div class="col-sm-7">
                        <input id="payment" name="payment" class="rating rating-loading" data-min="0" data-max="5" data-step="1" data-size="xs" data-show-clear="false" data-show-caption="false">
                      </div>
                    </div>


                  </div>


                  <div class="form-group col-md-12">

                    

                    <div class="col-sm-4" id="ratings">
                      
                    </div>

                    

                  </div>


                  <div class="form-group col-md-12 text-red" ng-show="amountToReturn>0">
                    <h4 class="col-sm-3 text-right">Amount to Return </h4>

                    <div class="col-sm-4">
                      
                    
                      
                      <h4 class="">{{amountToReturn}} TK </h4>

                      
                    </div>
                  </div>
                  <div class="form-group col-md-12">
                    <br><br>
                    <h4 class="col-sm-3"></h4>
                    <button type="button" id="submitpayment" class="btn btn-success col-sm-4" ng-disabled="isDisabled" ng-model='submitfull' ng-click="submitFullPayment(newdiscount, amountReceived)"><i class="fa fa-check"></i> Submit Full Payment</button>
                  </div>
                
                </div>
                <!-- full payment section end -->

              </uib-tab>
                <uib-tab heading="Due" ng-attr-active="tabs[1].active">
                    <div class="row">
                      <br>

                      <div class="form-group col-md-7" id="changediscount">

                        <div class="col-md-12">
                          
                          <h4 class="col-sm-5 text-right">Final Discount</h4>

                          <div class="col-sm-7">
                            <input name="newdiscount" type="number" class="form-control" id="newdiscount" placeholder="Enter new discount amount" ng-model="newdiscount" ng-keyup="finalpay = totalamt - newdiscount" ng-change="finalpay = totalamt - newdiscount">

                          </div>

                        </div>
                        <?
                        if (CustomerAccount::getCustomerBalance($invoice->customer)>0) { ?>
                        <div class="col-md-12">
                          
                          <h4 class="col-sm-5 text-right">Credit Adjustment </h4>
                          <div class="col-sm-7">
                            <input name="creditamt" type="number" class="form-control" id="creditamt" placeholder="Credit Adjusting" ng-disabled="creditAdjustable" ng-model="creditamt">
                          </div>

                        </div>
                        <? } ?>


                        <div class="col-md-12">
                          
                          <h4 class="col-sm-5 text-right">Paid Amount</h4>

                          <div class="col-sm-7">
                            <input name="paid" type="number" class="form-control" id="paid" placeholder="Enter amount" ng-disabled="finalpay<0" ng-model="amountReceivedDue" ng-keyup="dueAmount = getDueAmount(finalpay, amountReceivedDue); isDisabled = dueAmount<0" ng-change=" isDisabled = dueAmount<0" ng-class="{'bg-red': dueAmount < 0}">
                          </div>

                        </div>
                        

                        

                        
                      </div>

                      <div class="col-md-5">
                        <h4 class="col-sm-12" ng-show="true" ng-class="{'bg-red': finalpay < 0}">Final Amount to Pay: {{ finalpay }} TK</h4>

                        <?
                        if (CustomerAccount::getCustomerBalance($invoice->customer)>0) { ?>

                        <h4 class="col-sm-12" ng-show="true" ng-class="{'bg-red': finalpay < 0}">Remaining Amount: {{ remainingAmtToPay }} TK</h4>

                        <? } ?>

                        <div class="col-sm-12" id="ratings">
                          <div class="col-sm-5 text-right">
                            <label for="behavior" class="control-label">Customer Payment Rating:</label>
                          </div>
                          <div class="col-sm-7">
                            <input id="payment" name="payment" class="rating rating-loading" data-min="0" data-max="5" data-step="1" data-size="xs" data-show-clear="false" data-show-caption="false">
                          </div>
                        </div>
                      </div>

                      <div class="form-group col-md-12">
                        

                        

                      </div>

                      <div class="form-group col-md-12 text-red">
                        <h4 class="col-sm-3 text-right">Due Amount </h4>

                        <div class="col-sm-4">
                          
                        
                          
                          <h4 class="">{{dueAmount}} TK </h4>

                          
                        </div>
                      </div>
                      <div class="form-group col-md-12">
                        
                        <uib-tabset class="tabbable">

                          <!-- cash only...... -->

                          <uib-tab heading="Cash Only" ng-attr-active="duetabs[0].active">
                              
                            <div class="row">
                              <div class="col-md-12">
                                <h4 class="text-center">Create Payment Dates</h4>
                              </div>

                              

                              <div class="col-md-12" style="margin-top: 5px;" ng-repeat="item in schedules">
                                <div class="col-md-4">
                                  <div class="form-group" show-errors>
                                    <div class="input-group date">
                                           <div class="input-group-content">
                                             <input type="text" datefield name="scheduledate[]" class="form-control" ng-model="startDate" readonly="readonly" style="cursor:pointer;" required>
                                      </div>
                                      <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                    </div>
                                  </div>
                                </div>

                                <div class="col-md-4">
                                  <input name="scheduleamount[]" type="number" class="form-control" placeholder="Enter amount" ng-model="item.temp" ng-change="updateTemp()" ng-required="true">
                                </div>

                                <div class="col-md-4">
                                  <input name="scheduleremarks[]" type="text" class="form-control" placeholder="Enter remarks">
                                </div>
                                  
                                  
                              </div>

                              <div class="col-md-12">
                                <div class="col-md-8">
                                  <h4 ng-class="{'text-red': dueAmount-tempTotal != 0, 'text-green': dueAmount-tempTotal == 0 }">Amount Remaining to Be Scheduled: {{dueAmount-tempTotal}} TK</h4>
                                </div>

                                <div class="col-md-4">
                                  <button type="button" class="btn btn-warning col-sm-12" ng-disabled="dueAmount<=0" ng-click="addfield()"><i class="fa fa-plus"></i> Add More Date</button>
                                </div>
                              </div>
                              <div class="col-md-12">
                                <div class="col-md-4"></div>
                                <div class="col-md-4">
                                  
                                  <button type="button" class="btn btn-success col-sm-12" ng-disabled="dueAmount!=tempTotal" ng-click="submitCashDue()"><i class="fa fa-check"></i> Submit Payment</button>

                                </div>
                                <div class="col-md-4"></div>
                              </div>

                            </div>
                          </uib-tab>
                          <uib-tab heading="Cheque Only" ng-attr-active="duetabs[1].active">
                              
                            <div class="row">
                              <div class="col-md-12">
                                <h4 class="text-center">Give Cheques Informations</h4>
                              </div>

                              

                              <div class="col-md-12" style="margin-top: 5px;" ng-repeat="check in checks">

                                <div class="col-sm-12">
                                  <div class="col-md-4">
                                    <input name="checkamount[]" type="number" class="form-control" placeholder="Cheque amount" ng-model="check.checkamount" ng-change="updateCheckamount()" ng-required="true">
                                  </div>

                                  <div class="col-md-4">
                                    <div class="form-group" show-errors>
                                      <div class="input-group date">
                                             <div class="input-group-content">
                                               <input type="text" datefield name="scheduledate[]" class="form-control" ng-model="check.startDate" readonly="readonly" style="cursor:pointer;" placeholder="Cheque Date" ng-required="true">
                                        </div>
                                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                      </div>
                                    </div>
                                  </div>

                                  <div class="col-md-4">
                                    <input name="checknum[]" type="text" class="form-control" placeholder="Cheque number" ng-model="check.checknumber" ng-required="true">
                                  </div>
                                
                                </div>
                                
                                <div class="col-sm-12">
                                  <div class="col-md-4">
                                    <input name="checkbank[]" type="text" class="form-control" placeholder="Bank name" ng-model="check.bank" ng-required="true">
                                  </div>

                                  <div class="col-md-4">
                                    <input name="checkbranch[]" type="text" class="form-control" placeholder="Branch name" ng-model="check.branch" ng-required="true">
                                  </div>

                                  <div class="col-md-4">
                                    <input name="checknote[]" type="text" class="form-control" placeholder="Note">
                                  </div>
                                </div>
                                  
                              </div>

                              <div class="col-md-12">
                                <div class="col-md-8">
                                  <h4 ng-class="{'text-red': dueAmount-checkTotal != 0, 'text-green': dueAmount-checkTotal == 0 }">Amount Remaining to be Paid by Cheque: {{dueAmount-checkTotal}} TK</h4>
                                </div>

                                <div class="col-md-4" style="margin-top: 10px;">
                                  <button type="button" class="btn btn-warning col-sm-12" ng-disabled="dueAmount<=0" ng-click="addChecks()"><i class="fa fa-plus"></i> Add More Cheque</button>
                                </div>
                              </div>
                              <div class="col-md-12">
                                <div class="col-md-4"></div>
                                <div class="col-md-4">
                                  
                                  <button type="button" class="btn btn-success col-sm-12" ng-disabled="dueAmount!=checkTotal"><i class="fa fa-check"></i> Submit Payment</button>

                                </div>
                                <div class="col-md-4"></div>
                              </div>

                            </div>
                          </uib-tab>
                          <uib-tab heading="Combined" ng-attr-active="duetabs[2].active">
                              
                            <div class="row">

                              <!-- cash portion -->

                              <div class="col-md-12">
                                <h4 class="text-center">Payment Dates</h4>
                              </div>

                              

                              <div class="col-md-12" style="margin-top: 5px;" ng-repeat="comSchedule in comSchedules">
                                <div class="col-md-4">
                                  <div class="form-group" show-errors>
                                    <div class="input-group date">
                                           <div class="input-group-content">
                                             <input type="text" datefield name="scheduledate[]" class="form-control" ng-model="comSchedule.date" readonly="readonly" style="cursor:pointer;" ng-required="true">
                                      </div>
                                      <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                    </div>
                                  </div>
                                </div>

                                <div class="col-md-4">
                                  <input name="comscheduleamount[]" type="number" class="form-control" placeholder="Enter amount" ng-model="comSchedule.amount" ng-change="updateCombined()" ng-required="true">
                                </div>

                                <div class="col-md-4">
                                  <input name="comScheduleremarks[]" type="text" class="form-control" placeholder="Enter remarks">
                                </div>
                                  
                                  
                              </div>
                              <div class="col-md-12">

                                <div class="col-md-4 pull-right">
                                  <button type="button" class="btn btn-warning col-sm-12" ng-disabled="dueAmount<=0" ng-click="addComDate()"><i class="fa fa-plus"></i> Add More Date</button>
                                </div>
                              </div>
                              
                              <!-- check portion -->
                              <div class="col-md-12">
                                <h4 class="text-center">Cheques Informations</h4>
                              </div>

                              

                              <div class="col-md-12" style="margin-top: 5px;" ng-repeat="comCheck in comChecks">

                                <div class="col-sm-12">
                                  <div class="col-md-4">
                                    <input name="comcheckamount[]" type="number" class="form-control" placeholder="Cheque amount" ng-model="comCheck.checkamount" ng-change="updateCombined()" ng-required="true">
                                  </div>

                                  <div class="col-md-4">
                                    <div class="form-group" show-errors>
                                      <div class="input-group date">
                                             <div class="input-group-content">
                                               <input type="text" datefield name="comCheckDate[]" class="form-control" ng-model="comCheck.startDate" readonly="readonly" style="cursor:pointer;" placeholder="Cheque Date" ng-required="true">
                                        </div>
                                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                      </div>
                                    </div>
                                  </div>

                                  <div class="col-md-4">
                                    <input name="comChecknum[]" type="text" class="form-control" placeholder="Cheque number" ng-model="comCheck.checknumber" ng-required="true">
                                  </div>
                                
                                </div>
                                
                                <div class="col-sm-12">
                                  <div class="col-md-4">
                                    <input name="checkbank[]" type="text" class="form-control" placeholder="Bank name" ng-model="comCheck.bank" ng-required="true">
                                  </div>

                                  <div class="col-md-4">
                                    <input name="checkbranch[]" type="text" class="form-control" placeholder="Branch name" ng-model="comCheck.branch" ng-required="true">
                                  </div>

                                  <div class="col-md-4">
                                    <input name="comChecknote[]" type="text" class="form-control" placeholder="Note">
                                  </div>
                                </div>

                                  
                              </div>

                              <div class="col-md-12">

                                <div class="col-md-8">
                                  <h4 ng-class="{'text-red': dueAmount-checkTotal != 0, 'text-green': dueAmount-combinedTotal == 0 }">Amount Remaining: {{dueAmount-combinedTotal}} TK</h4>
                                </div>

                                <div class="col-md-4 pull-right" style="margin-top: 10px;">
                                  <button type="button" class="btn btn-warning col-sm-12" ng-disabled="dueAmount<=0" ng-click="addComChecks()"><i class="fa fa-plus"></i> Add More Cheque</button>
                                </div>
                              </div>
                              <div class="col-md-12">
                                <div class="col-md-4"></div>
                                <div class="col-md-4">
                                  
                                  <button type="button" class="btn btn-success col-sm-12" ng-disabled="dueAmount!=combinedTotal"><i class="fa fa-check"></i> Submit Payment</button>

                                </div>
                                <div class="col-md-4"></div>
                              </div>
                            </div>
                          </uib-tab>
                        </uib-tabset>


                      </div>
                    
                    </div>
                </uib-tab>
              </uib-tabset>
          </div>

        </div>

        <!-- <input type="submit" name="submit test.....">

        </form> -->

        <script>
  
          var app = angular.module('app', ['ui.bootstrap']);

          app.controller('TabCtrl', function($scope) {

            $scope.dueAmount = 0;
            


            $scope.tabs = [{active: true}, {active: false}];

            $scope.totalamt = <? echo $invoice->total_amount;?>;
            $scope.newdiscount = <? echo $invoice->discount ?>;

            var newdiscount = $scope.newdiscount;

            


            ///  credit amount

            <?
            if (CustomerAccount::getCustomerBalance($invoice->customer)>0) { ?>

              var credit = <? echo CustomerAccount::getCustomerBalance($invoice->customer);?>;
            <? } else { ?>

              var credit = 0;

            <? } ?>

            // $scope.creditamt = credit;

            if ($scope.totalamt>=credit) {
              
              $scope.creditamt = credit;

            }



            if ($scope.creditamt>$scope.finalpay) {

              $scope.creditAdjustable = false;

            } else {

              $scope.creditAdjustable = true;
            }

            /// 
            
            $scope.finalpay = $scope.totalamt - $scope.newdiscount;

            $scope.remainingAmtToPay =  $scope.finalpay - credit;

            $scope.getRemainingAmt = function(finalpay) {
              return  finalpay - credit;
            }

            // check if credit is to be adjusted

            $scope.creditAdjust = function (checkboxModel) {

              if (checkboxModel) {

              }

            }
            $scope.checkAmountToReturn = function(amountReceived, remainingAmtToPay, newdiscount) {
              
              // return  amountReceived - remainingAmtToPay - newdiscount;

              return  $scope.finalpay - credit - amountReceived;

            }

            $scope.getDueAmount = function(finalpay, amountReceivedDue) {
              
              return  finalpay - amountReceivedDue - credit;
              // return  $scope.finalpay - $scope.amountReceivedDue;


            }

            

            // if (==true) {

            //   alert("dkshkjshd");
            // }



            $scope.isDisabled = true;

            $scope.tabs = [{active: true}, {active: false}, {active: false}];

            $scope.monthSelectorOptions = {
              start: "year",
              depth: "year"
            };
            $scope.getType = function(x) {
              return typeof x;
            };
            $scope.isDate = function(x) {
              return x instanceof Date;
            };


            $scope.schedules = [];
            $scope.schedules.push({});

            $scope.addfield=function(){
              $scope.schedules.push({})
            }

            $scope.checks = [];

            $scope.checks.push({});

            $scope.addChecks=function(){
              $scope.checks.push({})
            }

            $scope.comSchedules = [];
            $scope.comSchedules.push({});

            $scope.addComDate=function(){
              $scope.comSchedules.push({})
            }

            $scope.comChecks = [];
            $scope.comChecks.push({});

            $scope.addComChecks=function(){
              $scope.comChecks.push({})
            }

            



              $scope.permanentTotal = 0.0;
              $scope.tempTotal = 0.0;

              $scope.isokCashDue = true;

              $scope.updateTemp = function(){
                    $scope.tempTotal = 0.0;

                    angular.forEach($scope.schedules, function(value, key){
                      if (isNaN(value.temp)) {
                        value.temp = 0;
                      }
                      $scope.tempTotal = $scope.tempTotal + parseFloat(value.temp);
                     })
                  }

            //calculation of total cheque amount
            $scope.checkTotal = 0.0;


            $scope.updateCheckamount = function(){
                  $scope.checkTotal = 0.0;

                  angular.forEach($scope.checks, function(value, key){
                    if (isNaN(value.checkamount)) {
                      value.checkamount = 0;
                    }
                    $scope.checkTotal = $scope.checkTotal + parseFloat(value.checkamount);
                   })
                }

            //calculation of total fot combined
            $scope.combinedTotal = 0.0;

            $scope.updateCombined = function(){
                  $scope.combinedTotal = 0.0;

                  angular.forEach($scope.comSchedules, function(value, key){
                    if (isNaN(value.amount)) {
                      value.amount = 0;
                    }
                    $scope.combinedTotal = $scope.combinedTotal + parseFloat(value.amount);
                   })

                  angular.forEach($scope.comChecks, function(value, key){
                    if (isNaN(value.checkamount)) {
                      value.checkamount = 0;
                    }
                    $scope.combinedTotal = $scope.combinedTotal + parseFloat(value.checkamount);
                   })

                }


            //submit Cash Due----------------------

            $scope.submitCashDue = function(){
                  $scope.combinedTotal = 0.0;

                  angular.forEach($scope.comSchedules, function(value, key){
                    if (isNaN(value.amount)) {
                      value.amount = 0;
                    }
                    $scope.combinedTotal = $scope.combinedTotal + parseFloat(value.amount);
                   })

                  angular.forEach($scope.comChecks, function(value, key){
                    if (isNaN(value.checkamount)) {
                      value.checkamount = 0;
                    }
                    $scope.combinedTotal = $scope.combinedTotal + parseFloat(value.checkamount);
                   })

                }

            $scope.submitFullPayment = function(newdiscount, amountReceived) {
              alert(newdiscount);
            }





          });
          app.directive('datefield', function () {
              return {
                  restrict: 'AC',
                  link: function (scope, element, attrs) {
                      element.datepicker({ dateFormat: 'dd/mm/yy', autoclose: true, todayHighlight: true });
                  }
              }
          });

          // app.controller('cntr',function($scope){
              

          //   })

          

        </script>
        <!-- /.col -->

       
      </div>
      <!-- /.row -->
    </section>
<!-- /.content -->
<div class="clearfix"></div>
</div>
<!-- /.content-wrapper -->




  <!-- footer -->
  <? print $this->fetch('/ui_includes/footer.phtml'); ?>

  <!-- Control Sidebar -->
  <? print $this->fetch('/ui_includes/control-sidebar.phtml'); ?>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->


<!-- Bootstrap 3.3.6 -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>bootstrap/js/bootstrap.min.js"></script>


<!-- bootstrap-confirmation.min.js -->

<script src="<?php echo htmlspecialchars($baseUrl); ?>bootstrap/js/bootstrap-confirmation.min.js"></script>


<!-- FastClick -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>dist/js/app.min.js"></script>
<!-- sidebar toggle -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>dist/js/sidebar-toggle.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>dist/js/demo.js"></script>

<!-- iCheck 1.0.1 -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/iCheck/icheck.min.js"></script>

<!-- jQuery Confirmation -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>dist/js/jquery-confirm.min.js"></script>

<!-- rating -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/rating/js/star-rating.min.js" type="text/javascript"></script>
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/rating/themes/krajee-svg/theme.min.js"></script>

<!-- bootstrap datepicker -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/datepicker/bootstrap-datepicker.js"></script>

<script>
    //Date picker
  $('.datepicker').datepicker({
     todayHighlight: true,
    autoclose: true
  });

  $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
    checkboxClass: 'icheckbox_flat-green',
    radioClass: 'iradio_flat-green'
  });
</script>



</body>
</html>
