<?php

 use App\Helper\Includes\NumberToWord;
 use App\Helper\Includes\BanglaConverter;
  use App\Helper\AccountsInfo;

include $this->getTemplatePath().'php_includes/NumberToWord.php';

include $this->getTemplatePath().'php_includes/db_conx.php';

 $hasSuccess = '';

  if (isset($_SESSION['success'])) {
      
      $_Success = $_SESSION['success'];

      $_SESSION['success'] = '';
    }

  if (isset($_SESSION['error'])) {
      
      $_Error = $_SESSION['error'];

      $_SESSION['error'] = '';
    }

  if (isset($_SESSION['msg'])) {
    
    $_Message = $_SESSION['msg'];

    $_SESSION['msg'] = '';
  }

    
?>


<?php
if ($auth['user']->img!="") {
    $usrimg = 'profileimg/'.$auth['user']->img;
  } else {
    $usrimg = 'dist/img/avatar.png';
  }
?>
 

<!DOCTYPE html>
<html>
<head>
  
<? print $this->fetch('/ui_includes/head.phtml'); ?>

    <!-- autocomplete -->
    <link rel="stylesheet" href="<? echo $baseUrl ?>dist/css/easy-autocomplete.css">
    <!-- autocomplete -->
      <link rel="stylesheet" href="<? echo $baseUrl ?>dist/css/easy-autocomplete.themes.css">
      <!-- Select2 -->
<link rel="stylesheet" href="<?php echo htmlspecialchars($baseUrl); ?>plugins/select2/select2.min.css">
<!-- DataTables -->
  <link rel="stylesheet" href="<?php echo htmlspecialchars($baseUrl); ?>plugins/datatables/dataTables.bootstrap.css">
  <!-- iCheck for checkboxes and radio inputs -->
  <link rel="stylesheet" href="<?php echo htmlspecialchars($baseUrl); ?>plugins/iCheck/all.css">
  
<!-- jQuery Confirmation -->
  <link rel="stylesheet" href="<?php echo htmlspecialchars($baseUrl); ?>dist/css/jquery-confirm.min.css">

  <!-- rating -->
  <link href="<?php echo htmlspecialchars($baseUrl); ?>plugins/rating/css/star-rating.min.css" media="all" rel="stylesheet" type="text/css" />
  <link href="<?php echo htmlspecialchars($baseUrl); ?>plugins/rating/themes/krajee-svg/theme.css" media="all" rel="stylesheet" type="text/css" />
    
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    <? print $this->fetch('/ui_includes/header.phtml'); ?>

  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <? print $this->fetch('/ui_includes/leftpanel.phtml'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

    <!-- Content Header (Page header) -->
    <section class="content-header">
      
      <?php if (isset($_Error) && $_Error == 'error') { ?>
        <div class="alert alert-danger alert-dismissible">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
          <h4><? echo $_Message; ?></h4>
        </div>
      <?php } ?>


      <?php if (isset($_Success) && $_Success == 'success') { ?>
        <div class="alert alert-success alert-dismissible">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
          <? echo $_Message;?>
        </div>
      <?php } ?>
      
    </section>

    
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Sales Invoice
        <small><? echo $invoice->invoice; ?></small>
      </h1>

    </section>

    <!-- Main content -->
    <section class="invoice">
      <!-- title row -->
      <div class="row">
        <div class="col-xs-12">
          
          <h2 class="page-header">
            <? if ($invoice->is_returned==1) {
              echo "<span class='text-red'>Sales Invoice ( This Invoice Has Been Returned ) - <a href='/sales/invoice/returned/".$invoice->id."'>View Return Details</a></span>
              <span class='pull-right text-red'>Return Type:  " . $invoice->return_type. "
            </small>";

            } else { ?>

            Sales Invoice
            <small class="pull-right"><b>Status:</b> <span class="<? if($invoice->payment_status=='Pending') echo "text-yellow" ?>"><? echo $invoice->payment_status; ?></span>
            </small>

            <? } ?>

          </h2>
        </div>
        <!-- /.col -->
      </div>
      <!-- info row -->
      <div class="row invoice-info">
        <div class="col-sm-4 invoice-col">
          Customer
          <address>
            <strong><? echo $customer->name; ?></strong><br>
            <? echo $customer->address; ?><br>
            <? if ($customer->remark) {
                    echo $customer->remark."<br>"; 
                }  ?>
            Phone: <? echo $customer->mobile; ?><br>
            Email: <? echo $customer->email; ?><br>
            <strong>Customer Type: </strong><? echo $customer->type; ?>
          </address>


        </div>
        <!-- /.col -->
        <div class="col-sm-4 invoice-col">
            
            
        </div>
        <!-- /.col -->
        <div class="col-sm-4 invoice-col">
          <br>
          <b>Date:</b> <? echo date(' d M, Y', strtotime($invoice->created_at)); ?><br>
          <b>Time:</b> <? echo date(' h:m:s A', strtotime($invoice->created_at)); ?><br>
          <b>Created By:</b> <? echo $created_by; ?><br>
          
          
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <!-- Table row -->
      <div class="row">
        <div class="col-xs-12 table-responsive">
          <table class="table table-striped">
            <thead>
            <tr>
              <th>SL</th>
              <th>Product</th>
              <th>Price</th>
              <th>Qty</th>
              <th>Subtotal</th>
            </tr>
            </thead>
            <tbody>
              <?

              $sql = "SELECT id, (SELECT model_no FROM products WHERE id=sales_invoice_items.product) model_no, (SELECT has_serial FROM products WHERE id=sales_invoice_items.product) has_serial, (SELECT warranty FROM products WHERE id=sales_invoice_items.product) warranty, product, qty, sell_rate, sell_rate*qty AS subtotal FROM sales_invoice_items WHERE invoice_id='$invoice->id';";
              $result = mysqli_query($db_conx,$sql );
              $total_items = mysqli_num_rows($result);
              if($total_items>0){
                $count = 0;
                while($row = mysqli_fetch_array($result)){
                  
                  $itemWarranty = $row['warranty'];

              ?>
                <tr>
                  <td><? echo ++$count; ?></td>
                  <td><? echo $row['model_no']; ?></td>
                  <td><? echo $row['sell_rate']; ?></td>
                  <td><? echo $row['qty']; ?></td>
                  <td><? echo $row['subtotal']; ?></td>
                  
                </tr>
                <?php if ($row['has_serial']==1){ ?>
                  <tr>
                    <td colspan="5">
                      <b>Serials:</b> 
                      <?
                      $thisitemId = $row['id'];
                      $sql = "SELECT * FROM sales_invoice_item_serials WHERE invoice_item='$thisitemId';";
                      $resultSL = mysqli_query($db_conx,$sql );
                      $total_sl = mysqli_num_rows($resultSL);
                      if($total_sl>0){
                        $countsl = 0;
                        while($row = mysqli_fetch_array($resultSL)){
                          echo " <b>#". ++$countsl.". </b>";
                          echo $row['serial'];
                     
                      }}

                      ?>
                      <br>
                      <b>Warranty:</b> <? echo $itemWarranty; ?> Months
                    </td>
                  </tr>
                  <?php } else {

                  if($itemWarranty>0){
                  ?>

                  <tr>
                    <td colspan="5">
                      <b>Warranty:</b> <? echo $itemWarranty; ?> Months
                    </td>
                  </tr>

                  <?

                    }
                  }
                  ?>
                

                <?
              }}
                ?>

            </tbody>
          </table>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <div class="row">
        <!-- accepted payments column -->
        <div class="col-xs-6">
          <b>In Word: <?php echo getStringOfAmount($invoice->total_amount); ?> Taka</b>

          <br>
          <br>
          <?

          $generator = new Picqer\Barcode\BarcodeGeneratorPNG();
          echo '<img width="200" src="data:image/png;base64,' . base64_encode($generator->getBarcode($invoice->invoice, $generator::TYPE_CODE_128)) . '">';

          ?>
          
        </div>
        <!-- /.col -->

        <?
            if($invoice->payment_status=='Complete'){ ?>

          <div class="col-xs-6">
            <div class="table-responsive">
              <table class="table">
                <tr>
                  <th style="width:50%">Subtotal:</th>
                  <td><? echo $invoice->total_amount; ?></td>
                </tr>
                <tr>
                  <th>Discount</th>
                  <td>
                    <? 
                    if ($invoice->final_discount){

                      echo $invoice->final_discount;

                    } else echo $invoice->discount; ?>
                      
                  </td>
                </tr>
                <tr>
                  <th>Total:</th>
                  <td><? echo $invoice->amount_to_pay; ?></td>
                </tr>
                <tr>
                  <th>Received Amount:</th>
                  <td><? echo $invoice->amount_received; ?></td>
                </tr>
                <? if ($invoice->credit_pay>0) { ?>
                
                <tr>
                  <th>Advanced Paid Amount:</th>
                  <td><? echo $invoice->credit_pay; ?></td>
                </tr>
                
                <? } ?>
                <tr>
                  <th>Amount Returned:</th>
                  <td><? echo $invoice->amount_returned; ?></td>
                </tr>
              </table>
            </div>
          </div>

        <?

      } ?>


        <!-- /.col -->
      </div>
      <!-- /.row -->

      <!-- this row will not appear when printing -->
      <br><br><br>
      <div class="row no-print">
        <div class="col-xs-12">
          <?
            if($invoice->payment_status=='Pending'){ ?>

              

                <!-- <a class="btn btn-success pull-left" data-toggle="modal" data-target="#paymentBox" ><i class="fa fa-credit-card"></i> Payment  </a> -->
                <a class="btn btn-success pull-left" href="/sales/invoice/payment/<? echo $invoice->id?>"><i class="fa fa-credit-card"></i> Payment  </a>

              

              <a style="margin-left: 20px;" class='btn btn-md btn-danger' data-toggle='confirmation' data-btn-ok-label='Yes' data-btn-ok-icon='glyphicon glyphicon-share-alt' data-btn-ok-class='btn-success' data-btn-cancel-label='No' data-btn-cancel-icon='glyphicon glyphicon-ban-circle' data-btn-cancel-class='btn-danger' data-title='Are You Sure?' data-content='The invoice will be candelled.'><i class="fa fa-trash"></i> Cancel Invoice  </a> 
          <?  } 
          ?>


          <?
            if($invoice->payment_status=='Complete'){ ?>

              <a style="margin-left: 20px;" class="btn btn-warning" href="/sales/invoice/viewdetailsinfo/<? echo $invoice->id ?>" ;"><i class="fa fa-eye"></i> View Invoice Details Info</a>

            <? if ($invoice->is_returned==1) { ?>


            <a href="/sales/return/cancel/<? echo $invoice->id; ?>" class='btn btn-md btn-success' data-toggle='confirmation' data-btn-ok-label='Proceed' data-btn-ok-icon='glyphicon glyphicon-share-alt' data-btn-ok-class='btn-success' data-btn-cancel-label='Go Back' data-btn-cancel-icon='glyphicon glyphicon-ban-circle' data-btn-cancel-class='btn-danger' data-title='Are You Sure?' data-content='The return will be cancelled.'>
                                        <i class="fa fa-hand-o-right"></i> </i> Cancel Return of Invoice
                                      </a>

            <?  } else { ?>

              <a style="margin-left: 20px;" class="btn btn-warning" href="/sales/invoice/return/<? echo $invoice->id ?>" ;"><i class="fa fa-eye"></i> Return Invoice Items</a>

            <? } ?>

              

          <?
            }
          ?>

            <a class="btn btn-success pull-right" onclick="window.print();"> <i class="fa fa-print"></i> Print Invoice</a>
          <!-- <button type="button" class="btn btn-success pull-right"><i class="fa fa-credit-card"></i> Submit Payment
          </button>
          <button type="button" class="btn btn-primary pull-right" style="margin-right: 5px;">
            <i class="fa fa-download"></i> Generate PDF
          </button> -->
        </div>
        <!-- Modal Popup for edit profile-->
        <div class="modal fade no-print" id="paymentBox" role="dialog">
          <div class="modal-dialog">
          
            <!-- Modal content-->
            <div class="modal-content">
              <div class="modal-header bg-yellow">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h3 class="box-title">Invoice payment</h3>
              </div>
              <form class="form-horizontal" role="form" action="/public/sales/invoice/payment/<? echo $invoice->id;?>" method="post" id="paymentform">
              <div class="modal-body">
                <div class="box-body" id="refundcontent">

                  

                    <?php echo $csrf['field']; ?>

                      <input type="hidden" name="invoiceid" value="<? echo $invoice->id; ?>">

                      <div class="form-group" id="ratings">
                        <div class="col-sm-7 text-right">
                          <label for="behavior" class="control-label">Customer Rating for this payment:</label>
                        </div>
                        <div class="col-sm-5">
                          <input id="payment" name="payment" class="rating rating-loading" data-min="0" data-max="5" data-step="1" data-size="xs" data-show-clear="false" data-show-caption="false">
                        </div>
                      </div>

                    
                      <div class="form-group">
                        <h4 class="col-sm-4 text-right"><b>Total Bill: </b></h4>
                        <h4 class="col-sm-3"><? echo $invoice->total_amount ?> TK</h4>

                        <h4 class="col-sm-5"><b>Discount: </b><? echo $invoice->discount ?> TK</h4>
                        <label class="col-sm-5 pull-right">
                          <input type="checkbox" name="discount_cng" id="discount_cng" value='1' class="flat-red">
                          Change Discount
                        </label>

                        <h4 class="col-sm-4 text-right"><b>Amount to be paid: </b></h4>
                        <h4 class="col-sm-3" id="amountToPay"><? echo $invoice->total_amount-$invoice->discount ?> TK</h4>
                        

                        


                      </div>

                      

                      <div class="form-group <? if(isset($errors['payment_type'])) echo 'has-error' ?>">
                        <h4 class="col-sm-4 text-right">Payment Type: </h4>

                        <div class="col-sm-8">
                          <select class="form-control" name="payment_type" id="payment_type">
                            <option value="cash" selected>Cash</option>
                            <option value="check">Check</option>
                            <option value="combined">Combined</option>
                          </select>

                        </div>
                      </div>

                      <div class="form-group <? if(isset($errors['payment_type'])) echo 'has-error' ?>" id="cashDuebtn">
                        <div class="col-sm-4"></div>
                        <label class="col-sm-5">
                          <input type="radio" name="due_pay" id="due_pay" value='1' class="flat-red">
                          Cash Due
                        </label>
                      </div>

                      
                      <div class="form-group <? if(isset($errors['changediscount'])) echo 'has-error' ?>" id="changediscount" style="display: none;">
                        <h4 class="col-sm-4 text-right">New Discount</h4>

                        <div class="col-sm-8">
                          <input name="newdiscount" type="text" class="form-control" id="newdiscount" placeholder="Enter new discount amount" value="<? echo $invoice->discount ?>">

                        </div>
                      </div>

                      <div class="form-group receive_sec">
                        <h4 class="col-sm-4 text-right">Amount Received <span id="inc_check" style="display: none;">(Including Checks)</span></h4>


                        <div class="col-sm-8">
                          <input name="paid" type="text" class="form-control" id="paid" placeholder="Enter amount">
                        
                          <? if(isset($errors['paid'])) { ?>
                          <span class="help-block"><? echo $errors['paid'][0]; ?> </span>

                          <? } ?>
                        </div>
                      </div>


                      <div class="form-group receive_sec">
                        <h4 class="col-sm-4 text-right" id="remaining_amt">Amount Returned</h4>

                        <div class="col-sm-8">
                          <h4 id="returned_amt"></h4>
                        </div>

                        


                      </div>

                      <!-- check payment -->


                      <div class="form-group checkPay <? if(isset($errors['checkPay'])) echo 'has-error' ?>" id="check_container" style="display: none;">

                        <div class="col-sm-6">
                          <input name="checkamt[1]" type="text" class="form-control checkamt" id="checkamt1" key="1" placeholder="Check Amount">

                        </div>
                        <div class="col-sm-6">
                          <input name="checknumber[1]" type="text" class="form-control checknumber" id="checknumber1" key="1" placeholder="Check Number">

                        </div>
                        <div class="col-sm-6">
                          <input name="checkbank[1]" type="text" class="form-control checkbank" id="checkbank1" key="1"  placeholder="Bank Name" style="margin-top: 5px;">

                        </div>


                        <div class="col-sm-6">
                          <input name="checkbranch[1]" type="text" class="form-control checkbranch" id="checkbranch1" key="1" placeholder="Branch Name" style="margin-top: 5px;">

                        </div>
                        <div class="col-sm-6" style="margin-top: 5px;">
                          
                          <div class="input-group date">
                            <div class="input-group-addon">
                              <i class="fa fa-calendar"></i>
                            </div>
                            <input type="text" name="checkdate[1]" id="checkdate1" class="form-control pull-right datepicker checkdate" id="datepicker" key="1" placeholder="Date">
                          </div>
                        </div>

                        <div class="col-sm-6" style="margin-top: 5px; margin-bottom: 5px;">
                          <textarea name="checknote[1]" type="text" class="form-control" id="checknote1" placeholder="Remarks/Note"></textarea>

                        </div>
                        
                      </div>

                      <div class="form-group checkPay " style="display: none;">
                        <div class="col-sm-3"></div>
                        <a class="btn btn-default col-sm-6 pull-center" id="addcheck">
                          Add More Check
                        </a>
                      </div>


                      <!-- check payment end -->

                      <!-- combined payment -->

                      <div class="form-group combinedPay <? if(isset($errors['checkPay'])) echo 'has-error' ?>" style="display: none;">
                        <h4 class="col-sm-4 text-right">Cash Amount </h4>

                        <div class="col-sm-8">
                          <input name="combinedCash" type="text" class="form-control" id="combinedCash" placeholder="Enter cash amount">

                        </div>
                        
                      </div>

                      <div class="form-group combinedPay <? if(isset($errors['checkPay'])) echo 'has-error' ?>" style="display: none;">
                        <h4 class="col-sm-4 text-right">Cheque Amount </h4>

                        <div class="col-sm-8">
                          <input name="combinedCheckAmt" type="text" class="form-control" id="combinedCheckAmt" placeholder="Enter cheque amount">

                        </div>
                        
                      </div>

                      <div class="form-group combinedPay" id="comcheck_container" style="display: none;">

                        <div class="col-sm-6">
                          <input name="comcheckamt[1]" type="text" class="form-control comcheckamt" id="comcheckamt1" key="1" placeholder="Check Amount">

                        </div>
                        <div class="col-sm-6">
                          <input name="comchecknumber[1]" type="text" class="form-control comchecknumber" id="comchecknumber1" key="1" placeholder="Check Number">

                        </div>
                        <div class="col-sm-6">
                          <input name="comcheckbank[1]" type="text" class="form-control comcheckbank" id="comcheckbank1" key="1"  placeholder="Bank Name" style="margin-top: 5px;">

                        </div>


                        <div class="col-sm-6">
                          <input name="comcheckbranch[1]" type="text" class="form-control comcheckbranch" id="comcheckbranch1" key="1" placeholder="Branch Name" style="margin-top: 5px;">

                        </div>
                        <div class="col-sm-6" style="margin-top: 5px;">
                          
                          <div class="input-group date">
                            <div class="input-group-addon">
                              <i class="fa fa-calendar"></i>
                            </div>
                            <input type="text" name="comcheckdate[1]" id="comcheckdate1" class="form-control pull-right datepicker comcheckdate" id="datepicker" key="1" placeholder="Date">
                          </div>
                        </div>

                        <div class="col-sm-6" style="margin-top: 5px; margin-bottom: 5px;">
                          <textarea name="comchecknote[1]" type="text" class="form-control" id="comchecknote1" placeholder="Remarks/Note"></textarea>

                        </div>
                        
                      </div>

                      <div class="form-group combinedPay " style="display: none;">
                        <div class="col-sm-3"></div>
                        <a class="btn btn-default col-sm-6 pull-center" id="addcomcheck">
                          Add More Check
                        </a>
                      </div>

                      <!-- check payment end -->



                      
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" id="submitpayment" class="btn btn-success" style="margin-top: 0px;" disabled><i class="fa fa-check"></i> Submit</button>
                <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa  fa-remove"></i>Close</button>
              </div>
              </form>
              
            </div>
            
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
    <div class="clearfix"></div>
  </div>
  <!-- /.content-wrapper -->




  <!-- footer -->
  <? print $this->fetch('/ui_includes/footer.phtml'); ?>

  <!-- Control Sidebar -->
  <? print $this->fetch('/ui_includes/control-sidebar.phtml'); ?>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>bootstrap/js/bootstrap.min.js"></script>


<!-- bootstrap-confirmation.min.js -->

<script src="<?php echo htmlspecialchars($baseUrl); ?>bootstrap/js/bootstrap-confirmation.min.js"></script>


<!-- FastClick -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>dist/js/app.min.js"></script>
<!-- sidebar toggle -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>dist/js/sidebar-toggle.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>dist/js/demo.js"></script>

<!-- iCheck 1.0.1 -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/iCheck/icheck.min.js"></script>

<!-- jQuery Confirmation -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>dist/js/jquery-confirm.min.js"></script>

<!-- rating -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/rating/js/star-rating.min.js" type="text/javascript"></script>
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/rating/themes/krajee-svg/theme.min.js"></script>

<!-- bootstrap datepicker -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/datepicker/bootstrap-datepicker.js"></script>



<script>
 
 $(document).ready(function() {

  $("form").attr('autocomplete', 'off');

  $('[data-toggle=confirmation]').confirmation({
  rootSelector: '[data-toggle=confirmation]',
  onConfirm: function() {

    var url = "/sales/cancelinvoice/confirmation/<? echo $invoice->id; ?>";
    window.location.replace(url);
  
  }
  // other options
  });

  //Date picker
  $('.datepicker').datepicker({
    autoclose: true
  });



  var isChecked = null;

  var due_pay = null;

  var selected = 'cash';

  var total_amount = <? echo $invoice->total_amount; ?>;

  var discount = <? echo $invoice->discount; ?>;

  var amountToPay = total_amount - discount;

  //Flat red color scheme for iCheck
  $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
    checkboxClass: 'icheckbox_flat-green',
    radioClass: 'iradio_flat-green'
  });


  //for change of discount
  $("input[name='discount_cng']").on('ifChecked', function(event){

    isChecked = $(this).prop("checked");

    $("#changediscount").slideDown(200);

    $("#newdiscount").val('');

  });


  $("input[name='discount_cng']").on('ifUnchecked', function(event){

    isChecked = $(this).prop("checked");

    $("#changediscount").slideUp(200);

    amountToPay = total_amount - discount;
    $("#amountToPay").html(amountToPay);

    var paid = $('#paid').val();

    if (paid) {

      var returned_amt = paid - amountToPay;

      $('#returned_amt').html(returned_amt);
      
    }


  });

  // due pay-------------

  $("input[name='due_pay']").on('ifChecked', function(event){

    due_pay = $(this).prop("checked");

    $("#remaining_amt").html("Due Amount");
    $('#returned_amt').removeClass("text-red");



    var paid = $('#paid').val();

      

    if ($.isNumeric(paid)) {

        $("#submitpayment").removeAttr("disabled");

    } else $("#submitpayment").attr("disabled", "disabled");

    var selectedtype = $('#payment_type').val();

    if (selectedtype == 'combined') {

      $("#inc_check").show();

    } else {
      $("#inc_check").hide();
    }

    var due_amount = amountToPay - paid;

    $('#returned_amt').html(due_amount);

    if (due_amount<0) {

      $('#returned_amt').addClass("text-red");
      $("#submitpayment").attr("disabled", "disabled");
    
    } else {

      $('#returned_amt').removeClass("text-red");
      $("#submitpayment").removeAttr("disabled");
    
    }


  });

  //due pay end



  $("#newdiscount").keyup(function () {
    
    var newdiscount = $(this).val();

    amountToPay = total_amount - newdiscount;

    $("#amountToPay").html(amountToPay);

    if ($.isNumeric(amountToPay)) {
        
        $(this).removeClass("bg-red");
        $("#submitpayment").removeAttr("disabled");

    } else {
        $(this).addClass("bg-red");
        $("#submitpayment").attr("disabled", "disabled");
    }

    var paid = $('#paid').val();

    if (paid) {

      var returned_amt = paid - amountToPay;

      

      if (due_pay) {

        var due_amount = Math.abs(returned_amt);

        $('#returned_amt').html(due_amount);

        $('#returned_amt').removeClass("text-red");

      } else {

        $('#returned_amt').html(returned_amt);
      }

    }


  });

  //pay type

  $('#payment_type').change(function() {

      selected = $(this).val();

      if (selected=='check') {

        $('.checkPay').show();
        $('.combinedPay').hide();
        $('.receive_sec').hide();
        $("#cashDuebtn").hide();
      
      } else if(selected=='combined'){

        $("#cashDuebtn").show();

        if (due_pay) {

          $("#inc_check").show();

        } else {
          $("#inc_check").hide();
        }

        $('.combinedPay').show(); 
        $('.checkPay').hide();
        $('.receive_sec').show();
        
      } else{

        $("#cashDuebtn").show();

        $('.checkPay').hide();
        $('.combinedPay').hide();
        $('.receive_sec').show();
      }
  });

  $('#paid').keyup(function () {

      var paid = $('#paid').val();

      

      if ($.isNumeric(paid)) {
        
        $(this).removeClass("bg-red");
        $("#submitpayment").removeAttr("disabled");

        

          if (due_pay) {

            var due_amount = amountToPay - paid;


            $('#returned_amt').html(due_amount);

            $('#returned_amt').removeClass("text-red");

            if (due_amount<0) {

              $('#returned_amt').addClass("text-red");
              $("#submitpayment").attr("disabled", "disabled");
            
            } else {

              $('#returned_amt').removeClass("text-red");
              $("#submitpayment").removeAttr("disabled");
            
            }

          } else {

            var returned_amt = paid - amountToPay;

            $('#returned_amt').html(returned_amt);

            if (returned_amt<0) {

              $('#returned_amt').addClass("text-red");
              $("#submitpayment").attr("disabled", "disabled");
            
            } else {

              $('#returned_amt').removeClass("text-red");
              $("#submitpayment").removeAttr("disabled");
            
            }
          }

        



      } else {
        $(this).addClass("bg-red");
        $("#submitpayment").attr("disabled", "disabled");
      }
    });


  //------------------------add check options for check----------------
  var count = 1;

 

  $("#addcheck").click(function () {

    count++;

     var content = '<div class="col-sm-6"><input name="checkamt['+ count +']" type="text" class="form-control checkamt" key="'+ count +'" id="checkamt'+ count +'" placeholder="Check Amount"></div><div class="col-sm-6"><input name="checknumber['+ count +']" type="text" class="form-control checknumber" id="checknumber'+ count +'" key="'+ count +'" placeholder="Check Number"></div><div class="col-sm-6"><input name="checkbank['+ count +']" type="text" class="form-control checkbank" id="checkbank'+ count +'" key="'+ count +'" placeholder="Bank Name" style="margin-top: 5px;"></div><div class="col-sm-6"><input name="checkbranch['+ count +']" type="text" class="form-control checkbranch" id="checkbranch'+ count +'" key="'+ count +'" placeholder="Branch Name" style="margin-top: 5px;"></div><div class="col-sm-6" style="margin-top: 5px;"><div class="input-group date"><div class="input-group-addon"><i class="fa fa-calendar"></i></div><input type="text" name="checkdate['+ count +']" id="checkdate'+ count +'" class="form-control pull-right datepicker checkdate" id="datepicker" key="'+ count +'" placeholder="Date"></div></div><div class="col-sm-6" style="margin-top: 5px; margin-bottom: 5px;"><textarea name="checknote['+ count +']" type="text" class="form-control" id="checknote'+ count +'" placeholder="Remarks/Note"></textarea></div>';

    $("#check_container").append(content).promise().done(function() {

          /////////////------here goes the functions to run on appended elements------

            $(this).find('.datepicker').datepicker({
              autoclose: true
            });

            $(this).find(".checkamt").keyup(function () {

                if (!$(this).val()) {

                  $(this).addClass('bg-yellow');

                } else $(this).removeClass('bg-yellow');

                if ($.isNumeric($(this).val())) {
        
                  $(this).removeClass("bg-red");
                  $("#submitpayment").removeAttr("disabled");

                } else {
                  $(this).addClass("bg-red");
                  $("#submitpayment").attr("disabled", "disabled");
                }
      
                var key = $(this).attr('key');

                var thischeckNum = $("#checknumber"+key).val();

                if (!thischeckNum) {

                  $("#checknumber"+key).addClass('bg-yellow');

                } else $("#checknumber"+key).removeClass('bg-yellow');

                var thischeckBank= $("#checkbank"+key).val();

                if (!thischeckBank) {

                  $("#checkbank"+key).addClass('bg-yellow');
                  
                } else $("#checkbank"+key).removeClass('bg-yellow');

                var thischeckBranch= $("#checkbranch"+key).val();

                if (!thischeckBranch) {

                  $("#checkbranch"+key).addClass('bg-yellow');
                  
                } else $("#checkbranch"+key).removeClass('bg-yellow');

                var thischeckDate= $("#checkdate"+key).val();

                if (!thischeckDate) {

                  $("#checkdate"+key).addClass('bg-yellow');
                  
                } else $("#checkdate"+key).removeClass('bg-yellow');

            });

            $(this).find(".checknumber").keyup(function () {

                if (!$(this).val()) {

                  $(this).addClass('bg-yellow');

                } else $(this).removeClass('bg-yellow');
                
                var key = $(this).attr('key');

                var thischeckNum = $("#checkamt"+key).val();

                if (!thischeckNum) {

                  $("#checkamt"+key).addClass('bg-yellow');

                } else $("#checkamt"+key).removeClass('bg-yellow');

                var thischeckBank= $("#checkbank"+key).val();

                if (!thischeckBank) {

                  $("#checkbank"+key).addClass('bg-yellow');
                  
                } else $("#checkbank"+key).removeClass('bg-yellow');

                var thischeckBranch= $("#checkbranch"+key).val();

                if (!thischeckBranch) {

                  $("#checkbranch"+key).addClass('bg-yellow');
                  
                } else $("#checkbranch"+key).removeClass('bg-yellow');

                var thischeckDate= $("#checkdate"+key).val();

                if (!thischeckDate) {

                  $("#checkdate"+key).addClass('bg-yellow');
                  
                } else $("#checkdate"+key).removeClass('bg-yellow');


            });

            $(".checkbank").keyup(function () {
                if (!$(this).val()) {
                  $(this).addClass('bg-yellow');
                } else $(this).removeClass('bg-yellow');
                var key = $(this).attr('key');
                var thischeckNum = $("#checknumber"+key).val();
                if (!thischeckNum) {
                  $("#checknumber"+key).addClass('bg-yellow');
                } else $("#checknumber"+key).removeClass('bg-yellow');
                var thischeckAmt= $("#checkamt"+key).val();
                if (!thischeckAmt) {
                  $("#checkamt"+key).addClass('bg-yellow');
                } else $("#checkamt"+key).removeClass('bg-yellow');
                var thischeckBranch= $("#checkbranch"+key).val();
                if (!thischeckBranch) {
                  $("#checkbranch"+key).addClass('bg-yellow');
                } else $("#checkbranch"+key).removeClass('bg-yellow');
                var thischeckDate= $("#checkdate"+key).val();
                if (!thischeckDate) {
                  $("#checkdate"+key).addClass('bg-yellow');
                } else $("#checkdate"+key).removeClass('bg-yellow');
            });

            $(".checkbranch").keyup(function () {
                if (!$(this).val()) {
                  $(this).addClass('bg-yellow');
                } else $(this).removeClass('bg-yellow');
                var key = $(this).attr('key');
                var thischeckNum = $("#checknumber"+key).val();
                if (!thischeckNum) {
                  $("#checknumber"+key).addClass('bg-yellow');
                } else $("#checknumber"+key).removeClass('bg-yellow');
                var thischeckAmt= $("#checkamt"+key).val();
                if (!thischeckAmt) {
                  $("#checkamt"+key).addClass('bg-yellow');
                } else $("#checkamt"+key).removeClass('bg-yellow');
                var thischeckBank= $("#checkbank"+key).val();
                if (!thischeckBank) {
                  $("#checkbank"+key).addClass('bg-yellow');
                } else $("#checkbank"+key).removeClass('bg-yellow');
                var thischeckDate= $("#checkdate"+key).val();
                if (!thischeckDate) {
                  $("#checkdate"+key).addClass('bg-yellow');
                } else $("#checkdate"+key).removeClass('bg-yellow');
            });

            $(".checkdate").change(function () {
                if (!$(this).val()) {
                  $(this).addClass('bg-yellow');
                } else $(this).removeClass('bg-yellow');
                var key = $(this).attr('key');
                var thischeckNum = $("#checknumber"+key).val();
                if (!thischeckNum) {
                  $("#checknumber"+key).addClass('bg-yellow');
                } else $("#checknumber"+key).removeClass('bg-yellow');
                var thischeckAmt= $("#checkamt"+key).val();
                if (!thischeckAmt) {
                  $("#checkamt"+key).addClass('bg-yellow');
                } else $("#checkamt"+key).removeClass('bg-yellow');
                var thischeckBank= $("#checkbank"+key).val();
                if (!thischeckBank) {
                  $("#checkbank"+key).addClass('bg-yellow');
                } else $("#checkbank"+key).removeClass('bg-yellow');
                var checkbranch= $("#checkbranch"+key).val();
                if (!checkbranch) {
                  $("#checkbranch"+key).addClass('bg-yellow');
                } else $("#checkbranch"+key).removeClass('bg-yellow');
            });
      });;
    


  });

  $(".checkamt").keyup(function () {

      if (!$(this).val()) {

        $(this).addClass('bg-yellow');

      } else $(this).removeClass('bg-yellow');

      if ($.isNumeric($(this).val())) {
        
        $(this).removeClass("bg-red");
        $("#submitpayment").removeAttr("disabled");

      } else {
        $(this).addClass("bg-red");
        $("#submitpayment").attr("disabled", "disabled");
      }
      
      var key = $(this).attr('key');

      var thischeckNum = $("#checknumber"+key).val();

      if (!thischeckNum) {

        $("#checknumber"+key).addClass('bg-yellow');

      } else $("#checknumber"+key).removeClass('bg-yellow');

      var thischeckBank= $("#checkbank"+key).val();

      if (!thischeckBank) {

        $("#checkbank"+key).addClass('bg-yellow');
        
      } else $("#checkbank"+key).removeClass('bg-yellow');

      var thischeckBranch= $("#checkbranch"+key).val();

      if (!thischeckBranch) {

        $("#checkbranch"+key).addClass('bg-yellow');
        
      } else $("#checkbranch"+key).removeClass('bg-yellow');

      var thischeckDate= $("#checkdate"+key).val();

      if (!thischeckDate) {

        $("#checkdate"+key).addClass('bg-yellow');
        
      } else $("#checkdate"+key).removeClass('bg-yellow');


  });

  $(".checknumber").keyup(function () {
      if (!$(this).val()) {
        $(this).addClass('bg-yellow');
      } else $(this).removeClass('bg-yellow');
      var key = $(this).attr('key');
      var thischeckNum = $("#checkamt"+key).val();
      if (!thischeckNum) {
        $("#checkamt"+key).addClass('bg-yellow');
      } else $("#checkamt"+key).removeClass('bg-yellow');
      var thischeckBank= $("#checkbank"+key).val();
      if (!thischeckBank) {
        $("#checkbank"+key).addClass('bg-yellow');
      } else $("#checkbank"+key).removeClass('bg-yellow');
      var thischeckBranch= $("#checkbranch"+key).val();
      if (!thischeckBranch) {
        $("#checkbranch"+key).addClass('bg-yellow');
      } else $("#checkbranch"+key).removeClass('bg-yellow');
      var thischeckDate= $("#checkdate"+key).val();
      if (!thischeckDate) {
        $("#checkdate"+key).addClass('bg-yellow');
      } else $("#checkdate"+key).removeClass('bg-yellow');
  });

 $(".checkbank").keyup(function () {
      if (!$(this).val()) {
        $(this).addClass('bg-yellow');
      } else $(this).removeClass('bg-yellow');
      var key = $(this).attr('key');
      var thischeckNum = $("#checknumber"+key).val();
      if (!thischeckNum) {
        $("#checknumber"+key).addClass('bg-yellow');
      } else $("#checknumber"+key).removeClass('bg-yellow');
      var thischeckAmt= $("#checkamt"+key).val();
      if (!thischeckAmt) {
        $("#checkamt"+key).addClass('bg-yellow');
      } else $("#checkamt"+key).removeClass('bg-yellow');
      var thischeckBranch= $("#checkbranch"+key).val();
      if (!thischeckBranch) {
        $("#checkbranch"+key).addClass('bg-yellow');
      } else $("#checkbranch"+key).removeClass('bg-yellow');
      var thischeckDate= $("#checkdate"+key).val();
      if (!thischeckDate) {
        $("#checkdate"+key).addClass('bg-yellow');
      } else $("#checkdate"+key).removeClass('bg-yellow');
  });

  $(".checkbranch").keyup(function () {
      if (!$(this).val()) {
        $(this).addClass('bg-yellow');
      } else $(this).removeClass('bg-yellow');
      var key = $(this).attr('key');
      var thischeckNum = $("#checknumber"+key).val();
      if (!thischeckNum) {
        $("#checknumber"+key).addClass('bg-yellow');
      } else $("#checknumber"+key).removeClass('bg-yellow');
      var thischeckAmt= $("#checkamt"+key).val();
      if (!thischeckAmt) {
        $("#checkamt"+key).addClass('bg-yellow');
      } else $("#checkamt"+key).removeClass('bg-yellow');
      var thischeckBank= $("#checkbank"+key).val();
      if (!thischeckBank) {
        $("#checkbank"+key).addClass('bg-yellow');
      } else $("#checkbank"+key).removeClass('bg-yellow');
      var thischeckDate= $("#checkdate"+key).val();
      if (!thischeckDate) {
        $("#checkdate"+key).addClass('bg-yellow');
      } else $("#checkdate"+key).removeClass('bg-yellow');
  });

  $(".checkdate").change(function () {
      if (!$(this).val()) {
        $(this).addClass('bg-yellow');
      } else $(this).removeClass('bg-yellow');
      var key = $(this).attr('key');
      var thischeckNum = $("#checknumber"+key).val();
      if (!thischeckNum) {
        $("#checknumber"+key).addClass('bg-yellow');
      } else $("#checknumber"+key).removeClass('bg-yellow');
      var thischeckAmt= $("#checkamt"+key).val();
      if (!thischeckAmt) {
        $("#checkamt"+key).addClass('bg-yellow');
      } else $("#checkamt"+key).removeClass('bg-yellow');
      var thischeckBank= $("#checkbank"+key).val();
      if (!thischeckBank) {
        $("#checkbank"+key).addClass('bg-yellow');
      } else $("#checkbank"+key).removeClass('bg-yellow');
      var checkbranch= $("#checkbranch"+key).val();
      if (!checkbranch) {
        $("#checkbranch"+key).addClass('bg-yellow');
      } else $("#checkbranch"+key).removeClass('bg-yellow');
  });





  //-------------------COMBINED PAY----------------------
  var comcount = 1;
  $("#addcomcheck").click(function () {

    comcount++;

     var content = '<div class="col-sm-6"><input name="comcheckamt['+ comcount +']" type="text" class="form-control comcheckamt" key="'+ comcount +'" id="comcheckamt'+ comcount +'" placeholder="Check Amount"></div><div class="col-sm-6"><input name="comchecknumber['+ comcount +']" type="text" class="form-control comchecknumber" id="comchecknumber'+ comcount +'" key="'+ comcount +'" placeholder="Check Number"></div><div class="col-sm-6"><input name="comcheckbank['+ comcount +']" type="text" class="form-control comcheckbank" id="comcheckbank'+ comcount +'" key="'+ comcount +'" placeholder="Bank Name" style="margin-top: 5px;"></div><div class="col-sm-6"><input name="comcheckbranch['+ comcount +']" type="text" class="form-control comcheckbranch" id="comcheckbranch'+ comcount +'" key="'+ comcount +'" placeholder="Branch Name" style="margin-top: 5px;"></div><div class="col-sm-6" style="margin-top: 5px;"><div class="input-group date"><div class="input-group-addon"><i class="fa fa-calendar"></i></div><input type="text" name="comcheckdate['+ comcount +']" id="comcheckdate'+ comcount +'" class="form-control pull-right datepicker comcheckdate" id="datepicker" key="'+ comcount +'" placeholder="Date"></div></div><div class="col-sm-6" style="margin-top: 5px; margin-bottom: 5px;"><textarea name="comchecknote['+ comcount +']" type="text" class="form-control" id="comchecknote'+ comcount +'" placeholder="Remarks/Note"></textarea></div>';

    $("#comcheck_container").append(content).promise().done(function() {

          /////////////------here goes the functions to run on appended elements------

            $(this).find('.datepicker').datepicker({
              autoclose: true
            });

            $(this).find(".comcheckamt").keyup(function () {

                if (!$(this).val()) {

                  $(this).addClass('bg-yellow');

                } else $(this).removeClass('bg-yellow');

                if ($.isNumeric($(this).val())) {
        
                  $(this).removeClass("bg-red");
                  $("#submitpayment").removeAttr("disabled");

                } else {
                  $(this).addClass("bg-red");
                  $("#submitpayment").attr("disabled", "disabled");
                }
      
                var key = $(this).attr('key');

                var thischeckNum = $("#comchecknumber"+key).val();

                if (!thischeckNum) {

                  $("#comchecknumber"+key).addClass('bg-yellow');

                } else $("#comchecknumber"+key).removeClass('bg-yellow');

                var thischeckBank= $("#comcheckbank"+key).val();

                if (!thischeckBank) {

                  $("#comcheckbank"+key).addClass('bg-yellow');
                  
                } else $("#comcheckbank"+key).removeClass('bg-yellow');

                var thischeckBranch= $("#comcheckbranch"+key).val();

                if (!thischeckBranch) {

                  $("#comcheckbranch"+key).addClass('bg-yellow');
                  
                } else $("#comcheckbranch"+key).removeClass('bg-yellow');

                var thischeckDate= $("#comcheckdate"+key).val();

                if (!thischeckDate) {

                  $("#comcheckdate"+key).addClass('bg-yellow');
                  
                } else $("#comcheckdate"+key).removeClass('bg-yellow');

            });

            $(this).find(".comchecknumber").keyup(function () {

                if (!$(this).val()) {

                  $(this).addClass('bg-yellow');

                } else $(this).removeClass('bg-yellow');
                
                var key = $(this).attr('key');

                var thischeckNum = $("#comcheckamt"+key).val();

                if (!thischeckNum) {

                  $("#comcheckamt"+key).addClass('bg-yellow');

                } else $("#comcheckamt"+key).removeClass('bg-yellow');

                var thischeckBank= $("#comcheckbank"+key).val();

                if (!thischeckBank) {

                  $("#comcheckbank"+key).addClass('bg-yellow');
                  
                } else $("#comcheckbank"+key).removeClass('bg-yellow');

                var thischeckBranch= $("#comcheckbranch"+key).val();

                if (!thischeckBranch) {

                  $("#comcheckbranch"+key).addClass('bg-yellow');
                  
                } else $("#comcheckbranch"+key).removeClass('bg-yellow');

                var thischeckDate= $("#comcheckdate"+key).val();

                if (!thischeckDate) {

                  $("#comcheckdate"+key).addClass('bg-yellow');
                  
                } else $("#comcheckdate"+key).removeClass('bg-yellow');


            });

            $(".comcheckbank").keyup(function () {
                if (!$(this).val()) {
                  $(this).addClass('bg-yellow');
                } else $(this).removeClass('bg-yellow');
                var key = $(this).attr('key');
                var thischeckNum = $("#comchecknumber"+key).val();
                if (!thischeckNum) {
                  $("#comchecknumber"+key).addClass('bg-yellow');
                } else $("#comchecknumber"+key).removeClass('bg-yellow');
                var thischeckAmt= $("#comcheckamt"+key).val();
                if (!thischeckAmt) {
                  $("#comcheckamt"+key).addClass('bg-yellow');
                } else $("#comcheckamt"+key).removeClass('bg-yellow');
                var thischeckBranch= $("#comcheckbranch"+key).val();
                if (!thischeckBranch) {
                  $("#comcheckbranch"+key).addClass('bg-yellow');
                } else $("#comcheckbranch"+key).removeClass('bg-yellow');
                var thischeckDate= $("#comcheckdate"+key).val();
                if (!thischeckDate) {
                  $("#comcheckdate"+key).addClass('bg-yellow');
                } else $("#comcheckdate"+key).removeClass('bg-yellow');
            });

            $(".comcheckbranch").keyup(function () {
                if (!$(this).val()) {
                  $(this).addClass('bg-yellow');
                } else $(this).removeClass('bg-yellow');
                var key = $(this).attr('key');
                var thischeckNum = $("#comchecknumber"+key).val();
                if (!thischeckNum) {
                  $("#comchecknumber"+key).addClass('bg-yellow');
                } else $("#comchecknumber"+key).removeClass('bg-yellow');
                var thischeckAmt= $("#comcheckamt"+key).val();
                if (!thischeckAmt) {
                  $("#comcheckamt"+key).addClass('bg-yellow');
                } else $("#comcheckamt"+key).removeClass('bg-yellow');
                var thischeckBank= $("#comcheckbank"+key).val();
                if (!thischeckBank) {
                  $("#comcheckbank"+key).addClass('bg-yellow');
                } else $("#comcheckbank"+key).removeClass('bg-yellow');
                var thischeckDate= $("#comcheckdate"+key).val();
                if (!thischeckDate) {
                  $("#comcheckdate"+key).addClass('bg-yellow');
                } else $("#comcheckdate"+key).removeClass('bg-yellow');
            });

            $(".comcheckdate").change(function () {
                if (!$(this).val()) {
                  $(this).addClass('bg-yellow');
                } else $(this).removeClass('bg-yellow');
                var key = $(this).attr('key');
                var thischeckNum = $("#comchecknumber"+key).val();
                if (!thischeckNum) {
                  $("#comchecknumber"+key).addClass('bg-yellow');
                } else $("#comchecknumber"+key).removeClass('bg-yellow');
                var thischeckAmt= $("#comcheckamt"+key).val();
                if (!thischeckAmt) {
                  $("#comcheckamt"+key).addClass('bg-yellow');
                } else $("#comcheckamt"+key).removeClass('bg-yellow');
                var thischeckBank= $("#comcheckbank"+key).val();
                if (!thischeckBank) {
                  $("#comcheckbank"+key).addClass('bg-yellow');
                } else $("#comcheckbank"+key).removeClass('bg-yellow');
                var checkbranch= $("#comcheckbranch"+key).val();
                if (!checkbranch) {
                  $("#comcheckbranch"+key).addClass('bg-yellow');
                } else $("#comcheckbranch"+key).removeClass('bg-yellow');
            });
      });;
    


  });

  $(".comcheckamt").keyup(function () {

      if (!$(this).val()) {

        $(this).addClass('bg-yellow');

      } else $(this).removeClass('bg-yellow');

      if ($.isNumeric($(this).val())) {
        
        $(this).removeClass("bg-red");
        $("#submitpayment").removeAttr("disabled");

      } else {
        $(this).addClass("bg-red");
        $("#submitpayment").attr("disabled", "disabled");
      }
      
      var key = $(this).attr('key');

      var thischeckNum = $("#comchecknumber"+key).val();

      if (!thischeckNum) {

        $("#comchecknumber"+key).addClass('bg-yellow');

      } else $("#comchecknumber"+key).removeClass('bg-yellow');

      var thischeckBank= $("#comcheckbank"+key).val();

      if (!thischeckBank) {

        $("#comcheckbank"+key).addClass('bg-yellow');
        
      } else $("#comcheckbank"+key).removeClass('bg-yellow');

      var thischeckBranch= $("#comcheckbranch"+key).val();

      if (!thischeckBranch) {

        $("#comcheckbranch"+key).addClass('bg-yellow');
        
      } else $("#comcheckbranch"+key).removeClass('bg-yellow');

      var thischeckDate= $("#comcheckdate"+key).val();

      if (!thischeckDate) {

        $("#comcheckdate"+key).addClass('bg-yellow');
        
      } else $("#comcheckdate"+key).removeClass('bg-yellow');


  });

  $(".comchecknumber").keyup(function () {
      if (!$(this).val()) {
        $(this).addClass('bg-yellow');
      } else $(this).removeClass('bg-yellow');
      var key = $(this).attr('key');
      var thischeckNum = $("#comcheckamt"+key).val();
      if (!thischeckNum) {
        $("#comcheckamt"+key).addClass('bg-yellow');
      } else $("#comcheckamt"+key).removeClass('bg-yellow');
      var thischeckBank= $("#comcheckbank"+key).val();
      if (!thischeckBank) {
        $("#comcheckbank"+key).addClass('bg-yellow');
      } else $("#comcheckbank"+key).removeClass('bg-yellow');
      var thischeckBranch= $("#comcheckbranch"+key).val();
      if (!thischeckBranch) {
        $("#comcheckbranch"+key).addClass('bg-yellow');
      } else $("#comcheckbranch"+key).removeClass('bg-yellow');
      var thischeckDate= $("#comcheckdate"+key).val();
      if (!thischeckDate) {
        $("#comcheckdate"+key).addClass('bg-yellow');
      } else $("#comcheckdate"+key).removeClass('bg-yellow');
  });

 $(".comcheckbank").keyup(function () {
      if (!$(this).val()) {
        $(this).addClass('bg-yellow');
      } else $(this).removeClass('bg-yellow');
      var key = $(this).attr('key');
      var thischeckNum = $("#comchecknumber"+key).val();
      if (!thischeckNum) {
        $("#comchecknumber"+key).addClass('bg-yellow');
      } else $("#comchecknumber"+key).removeClass('bg-yellow');
      var thischeckAmt= $("#comcheckamt"+key).val();
      if (!thischeckAmt) {
        $("#comcheckamt"+key).addClass('bg-yellow');
      } else $("#comcheckamt"+key).removeClass('bg-yellow');
      var thischeckBranch= $("#comcheckbranch"+key).val();
      if (!thischeckBranch) {
        $("#comcheckbranch"+key).addClass('bg-yellow');
      } else $("#comcheckbranch"+key).removeClass('bg-yellow');
      var thischeckDate= $("#comcheckdate"+key).val();
      if (!thischeckDate) {
        $("#comcheckdate"+key).addClass('bg-yellow');
      } else $("#comcheckdate"+key).removeClass('bg-yellow');
  });

  $(".comcheckbranch").keyup(function () {
      if (!$(this).val()) {
        $(this).addClass('bg-yellow');
      } else $(this).removeClass('bg-yellow');
      var key = $(this).attr('key');
      var thischeckNum = $("#comchecknumber"+key).val();
      if (!thischeckNum) {
        $("#comchecknumber"+key).addClass('bg-yellow');
      } else $("#comchecknumber"+key).removeClass('bg-yellow');
      var thischeckAmt= $("#comcheckamt"+key).val();
      if (!thischeckAmt) {
        $("#comcheckamt"+key).addClass('bg-yellow');
      } else $("#comcheckamt"+key).removeClass('bg-yellow');
      var thischeckBank= $("#comcheckbank"+key).val();
      if (!thischeckBank) {
        $("#comcheckbank"+key).addClass('bg-yellow');
      } else $("#comcheckbank"+key).removeClass('bg-yellow');
      var thischeckDate= $("#comcheckdate"+key).val();
      if (!thischeckDate) {
        $("#comcheckdate"+key).addClass('bg-yellow');
      } else $("#comcheckdate"+key).removeClass('bg-yellow');
  });

  $(".comcheckdate").change(function () {
      if (!$(this).val()) {
        $(this).addClass('bg-yellow');
      } else $(this).removeClass('bg-yellow');
      var key = $(this).attr('key');
      var thischeckNum = $("#comchecknumber"+key).val();
      if (!thischeckNum) {
        $("#comchecknumber"+key).addClass('bg-yellow');
      } else $("#comchecknumber"+key).removeClass('bg-yellow');
      var thischeckAmt= $("#comcheckamt"+key).val();
      if (!thischeckAmt) {
        $("#comcheckamt"+key).addClass('bg-yellow');
      } else $("#comcheckamt"+key).removeClass('bg-yellow');
      var thischeckBank= $("#comcheckbank"+key).val();
      if (!thischeckBank) {
        $("#comcheckbank"+key).addClass('bg-yellow');
      } else $("#comcheckbank"+key).removeClass('bg-yellow');
      var checkbranch= $("#comcheckbranch"+key).val();
      if (!checkbranch) {
        $("#comcheckbranch"+key).addClass('bg-yellow');
      } else $("#comcheckbranch"+key).removeClass('bg-yellow');
  });



  $("#combinedCash").keyup(function () {
  
      var combinedCash = $(this).val();

      var paidamt = $('#paid').val();

      var combinedCheck = paidamt - combinedCash;

      $("#combinedCheckAmt").val(combinedCheck);


  });

  $("#combinedCheckAmt").keyup(function () {
  
      var combinedCheck = $(this).val();

      var paidamt = $('#paid').val();

      var combinedCash = paidamt - combinedCheck;

      $("#combinedCash").val(combinedCash);


  });


  $("#submitpayment").click(function () {
    //
    var rating = $("#payment").val();

    var paidamt = $('#paid').val();

    var haserrors = new Array();

    if (!paidamt && selected!='check') {

      haserrors.push(" <b>Amount Received</b>");
    
    }

    if (!rating) {
      haserrors.push(" <b>Payment Rating</b>");
    }

    if (isChecked) {

      var discountamt = $("#newdiscount").val();

      if (!discountamt) {
        haserrors.push(" <b>New Discount</b>");
      }
    
    }

    if (selected=='check') {

      var checktotal = 0;

      for (var i = count - 1; i >= 0; i--) {
        
        checktotal +=  parseFloat($("#checkamt"+ (i+1)).val());

      }


      if (checktotal!= parseFloat($("#amountToPay").html())) {

        haserrors.push(" <br><b class='text-red'>Total amount of checks do not match total amount to pay!</b>");

      }

    }

    if (selected=='combined') {

      var combinedCash = $("#combinedCash").val();

      if (!combinedCash) {

        haserrors.push(" <b>Cash Amount</b>");

      }

      var combinedCheckAmt = $("#combinedCheckAmt").val();

      if (!combinedCheckAmt) {

        haserrors.push(" <b>Check Amount</b>");

      }

      //check total amount of checks
      var comchecktotal = 0;

      for (var i = comcount - 1; i >= 0; i--) {
        
        comchecktotal +=  parseFloat($("#comcheckamt"+ (i+1)).val());

      }


      if (comchecktotal!= parseFloat(combinedCheckAmt)) {

        haserrors.push(" <br><b class='text-red'>Total amount of checks do not match Check Amount!</b>");

      }

      

    }



    if (haserrors[0]) {

      $.alert("<h4 class='text-red'>Please review: </h4> "+haserrors )
        
    } else {

      $("#paymentform").submit();

    }




  });

 }); 
 
</script>




</body>
</html>