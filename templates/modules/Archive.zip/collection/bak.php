<?php

 use App\Helper\Includes\NumberToWord;
 use App\Helper\Includes\BanglaConverter;

 use App\Models\Customers; 
 use App\Models\Accounts\AccountSupCheques;
 use App\Models\Accounts\AccountBankAC;
 

include $this->getTemplatePath().'php_includes/NumberToWord.php';

include $this->getTemplatePath().'php_includes/db_conx.php';

 $hasSuccess = '';

  if (isset($_SESSION['success'])) {
      
      $_Success = $_SESSION['success'];

      $_SESSION['success'] = '';
    }

  if (isset($_SESSION['error'])) {
      
      $_Error = $_SESSION['error'];

      $_SESSION['error'] = '';
    }

  if (isset($_SESSION['msg'])) {
    
    $_Message = $_SESSION['msg'];

    $_SESSION['msg'] = '';
  }

    
?>


<?php
if ($auth['user']->img!="") {
    $usrimg = 'profileimg/'.$auth['user']->img;
  } else {
    $usrimg = 'dist/img/avatar.png';
  }
?>
 

<!DOCTYPE html>
<html>
<head>
  
<? print $this->fetch('/ui_includes/head.phtml'); ?>

    <!-- autocomplete -->
    <link rel="stylesheet" href="<? echo $baseUrl ?>dist/css/easy-autocomplete.css">
    <!-- autocomplete -->
      <link rel="stylesheet" href="<? echo $baseUrl ?>dist/css/easy-autocomplete.themes.css">
      <!-- Select2 -->
<link rel="stylesheet" href="<?php echo htmlspecialchars($baseUrl); ?>plugins/select2/select2.min.css">
<!-- DataTables -->
  <link rel="stylesheet" href="<?php echo htmlspecialchars($baseUrl); ?>plugins/datatables/dataTables.bootstrap.css">
    
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    <? print $this->fetch('/ui_includes/header.phtml'); ?>

  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <? print $this->fetch('/ui_includes/leftpanel.phtml'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      
      <?php if (isset($_Error) && $_Error == 'error') { ?>
        <div class="alert alert-danger alert-dismissible">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
          <h4><? echo $_Message; ?></h4>
        </div>
      <?php } ?>


      <?php if (isset($_Success) && $_Success == 'success') { ?>
        <div class="alert alert-success alert-dismissible">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
          <? echo $_Message;?>
        </div>
      <?php } ?>
      
    </section>
    <section class="content-header">
      <h1>
        Due Collection
      </h1>

    </section>

    <!-- Main content -->
    <section class="invoice">
     
      <!-- info row -->
      <div class="row invoice-info" ng-app='myapp'>

        
        <div class="col-md-6">
          <div class="form-group <? if(isset($errors['mobile'])) echo 'has-error' ?>">
            <label for="invoice" class="col-sm-4 control-label">Invoice</label>

            <div class="col-sm-8">


                      
            </div>

          </div>
          <br>

        </div>

        <div class="col-sm-4 invoice-col">
          <b>Customer Name:</b> <span id="c_name"></span><br>
          <b>Mobile:</b> <span id="mobile"></span><br>
          <b>Address:</b> <span id="address"></span><br>
          <b>Email:</b> <span id="email"></span><br>
          <b>Total Amount:</b> <span id="total_amt"></span><br>
          <b>Total Paid:</b> <span id="total_paid"></span><br>
          <b>Remaining Due:</b> <span id="remaining_due"></span><br>
          
          <address>
            
          </address>
        </div>

        <!-- /.col -->
        <div class="col-sm-4 invoice-col">

        </div>
        <!-- /.col -->
        <div class="col-sm-4 invoice-col">         
          
          
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <!-- Table row -->
      
      <!-- /.row -->

      <div class="row">
        <!-- accepted payments column -->
        <div class="col-xs-6">
          <b>In Word: <?php echo getStringOfAmount(0); ?> Taka</b>
          
        </div>
        <!-- /.col -->
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <!-- this row will not appear when printing -->
      <div class="row no-print">
        <div class="col-xs-12">

         
          <!-- <button type="button" class="btn btn-success pull-right"><i class="fa fa-credit-card"></i> Submit Payment
          </button>
          <button type="button" class="btn btn-primary pull-right" style="margin-right: 5px;">
            <i class="fa fa-download"></i> Generate PDF
          </button> -->
        </div>
      </div>
    </section>
    <!-- /.content -->
    <div class="clearfix"></div>
  </div>
  <!-- /.content-wrapper -->




  <!-- footer -->
  <? print $this->fetch('/ui_includes/footer.phtml'); ?>

  <!-- Control Sidebar -->
  <? print $this->fetch('/ui_includes/control-sidebar.phtml'); ?>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>bootstrap/js/bootstrap.min.js"></script>


<!-- bootstrap-confirmation.min.js -->

<script src="<?php echo htmlspecialchars($baseUrl); ?>bootstrap/js/bootstrap-confirmation.min.js"></script>


<!-- FastClick -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>dist/js/app.min.js"></script>
<!-- sidebar toggle -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>dist/js/sidebar-toggle.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>dist/js/demo.js"></script>

<!-- autocomplete -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>dist/js/jquery.easy-autocomplete.js"></script>

<!-- Select2 -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/select2/select2.full.min.js"></script>

<!-- DataTables -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/datatables/dataTables.bootstrap.min.js"></script>
<!-- DataTables end-->



<script>


  // define variables

  var invoiceId = null;
  var invoice = null;

  var amount_to_pay = null;
  var amount_received = null;
  var total_due = null;
  var remaining_due = null;
  var amount_paid = null;

  var mobile = null;
  var name = null;
  var address = null;
  var email = null;

  



  $(document).ready(function() {

    var optionsinvoice = {
          url: function(phrase) {
            return "/collection/getinvoiceeasy?phrase=" + phrase + "&format=json";
          },

          getValue: "invoice",
          list: {

            onSelectItemEvent: function() {
 

              invoiceId = $("#invoice").getSelectedItemData().id;
              invoice = $("#invoice").getSelectedItemData().invoice;
              amount_to_pay = $("#invoice").getSelectedItemData().amount_to_pay;
              amount_received = $("#invoice").getSelectedItemData().amount_received;
              total_due = $("#invoice").getSelectedItemData().total_due;
              remaining_due = $("#invoice").getSelectedItemData().remaining_due;
              amount_paid = $("#invoice").getSelectedItemData().amount_paid;

              mobile = $("#invoice").getSelectedItemData().mobile;
              name = $("#invoice").getSelectedItemData().name;
              address = $("#invoice").getSelectedItemData().address;
              email = $("#invoice").getSelectedItemData().email;
              customertype = $("#invoice").getSelectedItemData().type;
              balance = $("#invoice").getSelectedItemData().balance;


              $("#c_name").html(name).trigger("change");
              $("#address").html(address).trigger("change");
              $("#email").html(email).trigger("change");
              $("#mobile").html(mobile).trigger("change");
              $("#total_amt").html(amount_to_pay).trigger("change");
              $("#total_paid").html(amount_received).trigger("change");
              $("#remaining_due").html(remaining_due).trigger("change");

              $("#oldcustomer").show();
              $("#newcustomer").hide();               

            },

            showAnimation: {
              type: "fade", //normal|slide|fade
              time: 200,
              callback: function() {}
            },

            hideAnimation: {
              type: "slide", //normal|slide|fade
              time: 200,
              callback: function() {

                if (invoiceId) {

                  jQuery.ajax({

                    url : '/public/collection/getschedules/',
                    type : 'post',
                    data : {
                      'invoice' : invoiceId,
                    },
                    success : function(response) {

                      if (response.data.msg=='success') {

                        alert(response.result);

                      }

                    }
                  });

                  // ///angular code
                  // var config = {
                  //   method : 'POST',
                  //   url : "/public/collection/getschedules/",
                  //   data : {
                  //     'invoice' : invoiceId,

                  //   }
                  // };

                  // var request = $http(config);

                  // request.then(function (response) {

                  //   if (response.data.msg=='success') {

                  //     alert(response.result);

                  //   }


                  // }),function (error) {
                  //   alert(error.data);
                  // }

                  // //angular-------

                }

                
              }
            }
          },
          template: {
              type: "description",
              fields: {
                  description: "name"
              }
          },
          theme: "blue-light",

          


        };
    $("#invoice").easyAutocomplete(optionsinvoice);



    // create the bill

    $("#createinvoice").click(function () {

      var inverrors = new Array();
      
      if (!customerid) {
        //new customer
        var name = $("#name").val();
        var address = $("#address").val();
        var email = $("#email").val();
        var c_type = $("#customer_type").val();

        var amount = $("#amount").val();

        if (!amount) {

          inverrors.push(" <b>Received Amount</b>")

        }

        if (!name) {
          inverrors.push(" <b>Name</b>")
        }
        if (!address) {
          inverrors.push(" <b>Address</b>")
        }
        if (!c_type) {
          inverrors.push(" <b>Customer Type</b>")
        }

        if (inverrors[0]) {

          $.alert("<h4 class='text-red'>Please give the following informations: </h4> "+inverrors )
        
        } else {

              createInvoice(null);
              $("#createinvoice").attr('disabled','true');

        }


      } else {
        //already customer

        var amount = $("#amount").val();

        if (!amount) {

          $.alert("<h4 class='text-red'>Please give the Received Amount </h4> "+inverrors )

        } else {

          createInvoice(customerid);
          $("#createinvoice").attr('disabled','true');
        }


      }

    });

    function createInvoice(customer_id) {
      
      if (!customer_id) {
        //for new customer

        var mobile = $("#mobile").val();
        var name = $("#name").val();
        var address = $("#address").val();
        var email = $("#email").val();
        var c_type = $("#customer_type").val();

        var amount = $("#amount").val();
        var remark = $("#remark").val();

        jQuery.ajax({

              url : '/public/collection/createadvanceinvoice',
              type : 'post',
              data : {
                type :        'new',
                mobile :      mobile,
                name :        name,
                address :     address,
                email :       email,
                c_type :      c_type,
                amount :      amount,
                remark :      remark
                
              },
              success : function(data) {

                    var returndata = JSON.parse(data);

                    if (returndata.reply=='done') {

                      $.confirm({

                          title: 'Advance Payment Created!',
                          content: 'Continue to View Advance Slip',
                          
                          buttons: {
                              continue: function () {
                                  // $.alert('Confirmed!');

                                  var url = "/collection/advanceslip/"+returndata.invoice;
                                  window.location.replace(url);

                              }
                              
                          }
                      });
                    }
                  }
                
        });

      
      } else {
        //for old customer

        var amount = $("#amount").val();
        var remark = $("#remark").val();

        jQuery.ajax({

              url : '/public/collection/createadvanceinvoice',
              type : 'post',
              data : {
                type :        'old',
                customer :    customerid,
                amount :      amount,
                remark :      remark
              },
              success : function(data) {

                    var returndata = JSON.parse(data);

                    if (returndata.reply=='done') {

                      $.confirm({

                          title: 'Advance Payment Created!',
                          content: 'Continue to View Advance Slip',
                          
                          buttons: {
                              continue: function () {
                                  // $.alert('Confirmed!');

                                  var url = "/collection/advanceslip/"+returndata.invoice;
                                  window.location.replace(url);

                              }
                              
                          }
                      });
                    }
                   
                    

                  }
                
        });

      }


    } //function end


} );


</script>


<script>
  
  $('[data-toggle=confirmation]').confirmation({
  rootSelector: '[data-toggle=confirmation]',
  // other options
  });
</script>




</body>
</html>