<?php

 use App\Helper\Includes\NumberToWord;
 use App\Helper\Includes\BanglaConverter;

 use App\Models\Customers; 
 use App\Models\Accounts\AccountSupCheques;
 use App\Models\Accounts\AccountBankAC;
 

include $this->getTemplatePath().'php_includes/NumberToWord.php';

include $this->getTemplatePath().'php_includes/db_conx.php';

 $hasSuccess = '';

  if (isset($_SESSION['success'])) {
      
      $_Success = $_SESSION['success'];

      $_SESSION['success'] = '';
    }

  if (isset($_SESSION['error'])) {
      
      $_Error = $_SESSION['error'];

      $_SESSION['error'] = '';
    }

  if (isset($_SESSION['msg'])) {
    
    $_Message = $_SESSION['msg'];

    $_SESSION['msg'] = '';
  }

    
?>


<?php
if ($auth['user']->img!="") {
    $usrimg = 'profileimg/'.$auth['user']->img;
  } else {
    $usrimg = 'dist/img/avatar.png';
  }
?>
 

<!DOCTYPE html>
<html>
<head>
  
<? print $this->fetch('/ui_includes/head.phtml'); ?>

    <!-- autocomplete -->
    <link rel="stylesheet" href="<? echo $baseUrl ?>dist/css/easy-autocomplete.css">
    <!-- autocomplete -->
      <link rel="stylesheet" href="<? echo $baseUrl ?>dist/css/easy-autocomplete.themes.css">
      <!-- Select2 -->
<link rel="stylesheet" href="<?php echo htmlspecialchars($baseUrl); ?>plugins/select2/select2.min.css">
<!-- DataTables -->
  <link rel="stylesheet" href="<?php echo htmlspecialchars($baseUrl); ?>plugins/datatables/dataTables.bootstrap.css">

    <!-- iCheck for checkboxes and radio inputs -->
  <link rel="stylesheet" href="<?php echo htmlspecialchars($baseUrl); ?>plugins/iCheck/all.css">

<!-- jQuery Confirmation -->
  <link rel="stylesheet" href="<?php echo htmlspecialchars($baseUrl); ?>dist/css/jquery-confirm.min.css">

  <!-- rating -->
  <link href="<?php echo htmlspecialchars($baseUrl); ?>plugins/rating/css/star-rating.min.css" media="all" rel="stylesheet" type="text/css" />
  <link href="<?php echo htmlspecialchars($baseUrl); ?>plugins/rating/themes/krajee-svg/theme.css" media="all" rel="stylesheet" type="text/css" />

   <!-- jquery -->
  <script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/jQuery/jquery-2.2.3.min.js"></script>

  <script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/jQueryUI/jquery-ui.min.js"></script>


  <!-- angular -->
  <script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/angular/angular.min.js"></script>

  <!-- angular animate -->
  <script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/angular/angular-animate.min.js"></script>

  <!-- angular animate bootstrap -->
  <script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/angular/ui-bootstrap-tpls.min.js"></script>

    
</head>
<body class="hold-transition skin-blue sidebar-mini">
<!-- --mod: menu wrapper custom end -->
  <? print $this->fetch('/ui_includes/main_navigation.phtml'); ?>
  <!-- --mod: menu wrapper custom end -->
  
  <div class="wrapper page-wrapper">

    <header class="main-header">
      <? print $this->fetch('/ui_includes/header.phtml'); ?>
    </header>
    <!-- Left side column. contains the logo and sidebar -->
    <?// print $this->fetch('/ui_includes/leftpanel.phtml'); ?>

    <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper" ng-app="app">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      
      <?php if (isset($_Error) && $_Error == 'error') { ?>
        <div class="alert alert-danger alert-dismissible">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
          <h4><? echo $_Message; ?></h4>
        </div>
      <?php } ?>


      <?php if (isset($_Success) && $_Success == 'success') { ?>
        <div class="alert alert-success alert-dismissible">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
          <? echo $_Message;?>
        </div>
      <?php } ?>
      
    </section>
    <section class="content-header">
      <h1>
        Collection
      </h1>

    </section>

    <!-- Main content -->
    <section class="invoice" ng-controller="schedulescontroller">
     
      <!-- info row -->
      <div class="row invoice-info">
        <div class="col-xs-12">
          <uib-tabset class="tabbable">

            <uib-tab heading="Invoice Due" ng-attr-active="duetabs[0].active">
              <br>
              <br>
              <div class="col-md-8">
                <div class="form-group <? if(isset($errors['mobile'])) echo 'has-error' ?>">
                  <label for="invoice" class="col-sm-4 control-label">Invoice</label>

                  <div class="col-sm-8">


                    <input type="text" class="form-control" id="invoice">
                            
                  </div>

                </div>
                <br>
                <br>
                <br>
                <div class="col-md-12">

                  <div id="schedulescontroller">
                    <table id="employee-grid" class="table table-hover">
                      <thead>
                        <tr>
                          <td><b>Amount</b></td>
                          <td><b>Date</b></td>
                          <td><b>Remarks</b></td>
                          <td><b>Action</b></td>
                        </tr>
                      </thead>
                      <tbody>
                        <tr ng-repeat="item in schedules" ng-show="item.has_paid==0 ? true : false" ng-class="{'text-red': item.status == 'Rescheduled'}">

                          <td>{{item.amount}}</td>
                          <td>{{ item.status=='Rescheduled' ? item.final_schedule : item.schedule_date}}</td>
                          <td>{{item.remarks}}</td>
                          <td>
                            <span class="btn btn-sm btn-success" ng-click="collect(item)">Collect</span>
                          </td>
                          
                        </tr>

                        
                        
                        
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

              <div class="col-md-4 invoice-col">
                <b>Customer Name:</b> <span id="c_name"></span><br>
                <b>Mobile:</b> <span id="mobile"></span><br>
                <b>Address:</b> <span id="address"></span><br>
                <b>Email:</b> <span id="email"></span><br>
                <b>Total Amount:</b> <span id="total_amt"></span><br>
                <b>Total Paid:</b> <span id="total_paid"></span><br>
                <b>Remaining Due:</b> <span id="remaining_due"></span><br>
                
                <address>
                  
                </address>
              </div>
              <!-- /.col -->
              <div class="col-sm-4 invoice-col">         
                
              </div>




            </uib-tab>


            <uib-tab heading="Combined Customer's Collection" ng-attr-active="duetabs[1].active">

              <div class="col-md-6">  

                <br>
                <br>
                <div class="form-group <? if(isset($errors['mobile'])) echo 'has-error' ?>">
                  <label for="mobileornname" class="col-md-5 control-label">Mobile Number or Name</label>

                  <div class="col-md-7 mobileornname">


                    <input type="text" class="form-control" id="mobileornname">
                            
                  </div>

                </div>

              </div>
              <div class="col-md-6">
                <br>
                <br>        
                <p class="col-md-6"><b>Name: </b><span id="customer_name"></span></p>
                <p class="col-md-6"><b>Address: </b><span id="c_addr"></span></p>
                <p class="col-md-6"><b>Email: </b><span id="c_email"></span></p>
                <p class="col-md-6"><b>Customer Type: </b><span id="c_type"></span></p>
                <p class="col-md-6"><b>Balance: </b><span id="c_due"></span></p>
                <p class="col-md-6"><b>Credit Limit: </b><span id="c_creditlimit"></span></p>
              


              </div>

              <div class="col-md-12">
                <br><br>
                

                <div class="col-md-6">
                
                  <div class="col-sm-12">
                    <h4 class="col-sm-5 text-right">Paid Amount</h4>

                    <div class="col-sm-7">
                     <input name="com_paidAmt" type="number" class="form-control" id="com_paidAmt" placeholder="Enter paid amount" ng-model="com_paidAmt">

                    </div>
                  </div>
                  <div class="col-sm-12">
                    <h4 class="col-sm-5 text-right">Paying Date</h4>
                    <div class="col-sm-7">
                      <div class="form-group">
                        <div class="input-group date">
                               <div class="input-group-content">
                                 <input type="text" datefield name="com_date" class="form-control" ng-model="com_date" id="com_date" readonly="readonly" style="cursor:pointer;" required autocomplete="off">
                          </div>
                          <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                        </div>
                      </div>
                    </div>
                  </div>

                </div>
                <div class="col-md-6">
                  
                  <div class="col-sm-12">
                    <div class="col-sm-6 text-right">
                      <label for="com_paymentrating" class="control-label"><h4>Customer Payment Rating:</h4></label>
                    </div>
                    <div class="col-sm-6">
                      <input id="com_paymentrating" name="com_paymentrating" ng-model="com_paymentrating" class="rating rating-loading" data-min="0" data-max="5" data-step="1" data-size="xs" data-show-clear="false" data-show-caption="false">
                    </div>
                  </div>

                  <div class="col-sm-12">
                    <h4 class="col-sm-3 text-right">Remarks:</h4>

                    <div class="col-sm-9">
                     <input name="com_feedback" type="text" class="form-control" id="com_feedback" placeholder="Enter remarks for this payment" ng-model="com_feedback">

                    </div>
                  </div>

                </div>

              </div>

              <div class="col-md-12">
                <br><br>

                <div class="col-sm-4"></div>

                <button type="button" class="btn btn-success col-sm-4" id="comTakepayment"><i class="fa fa-check"></i> Submit</button>

                
              </div>
              


            </uib-tab>

            <!-- ADVANCE COLLECTION -->
            <uib-tab heading="Advance Payment Collection" ng-attr-active="duetabs[2].active">

              <div class="col-md-6">  

                <br>
                <br>
                <div class="form-group <? if(isset($errors['mobile'])) echo 'has-error' ?>">
                  <label for="mobileornname" class="col-md-5 control-label">Mobile Number or Name</label>

                  <div class="col-md-7 mobileornname">


                    <input type="text" class="form-control" id="adv_mobile">
                            
                  </div>

                </div>

              </div>
              <div class="col-md-6">
                <br>
                <br>        
                 <div class="col-md-12" id="oldcustomer" style="display: none;">
                        
                  <p class="col-md-6"><b>Name: </b><span id="adv_name"></span></p>
                  <p class="col-md-6"><b>Address: </b><span id="adv_addr"></span></p>
                  <p class="col-md-6"><b>Email: </b><span id="adv_email"></span></p>
                  <p class="col-md-6"><b>Customer Type: </b><span id="adv_type"></span></p>
                  <p class="col-md-6"><b>Previous Balance: </b><span id="adv_balance"></span></p>
                
                </div> 

                <div class="col-md-12" id="newcustomer" style="display: none;">
                  <div class="form-group <? if(isset($errors['name'])) echo 'has-error' ?>">
                    <label for="ad_name" class="col-sm-3 control-label">Name</label>

                    <div class="col-sm-8">
                      <input name="ad_name" type="text" class="form-control" id="ad_name" placeholder="Enter Name" autocomplete="off" value="<? if(isset($old['name'])) echo $old['name']; ?>">
                    
                      <span class="nameerror"></span>
                    </div>

                  </div>
                  <div class="form-group <? if(isset($errors['address'])) echo 'has-error' ?>">
                    <label for="ad_address" class="col-sm-3 control-label">Address</label>

                    <div class="col-sm-8">
                      <input name="ad_address" type="text" class="form-control" id="ad_address" placeholder="Enter Address" autocomplete="off" value="<? if(isset($old['address'])) echo $old['address']; ?>">
                    
                      <span class="addresserror"></span>


                    </div>

                  </div>
                  <div class="form-group <? if(isset($errors['email'])) echo 'has-error' ?>">
                    <label for="ad_email" class="col-sm-3 control-label">Email</label>

                    <div class="col-sm-8">
                      <input name="ad_email" type="text" class="form-control" id="ad_email" placeholder="Enter Email" autocomplete="off" value="<? if(isset($old['email'])) echo $old['email']; ?>">
                    

                    </div>

                  </div>
                  <div class="form-group <? if(isset($errors['type'])) echo 'has-error' ?>">
                    <label for="ad_customer_type" class="col-sm-3 control-label">Type</label>

                    <div class="col-sm-8">
                      <select name="ad_customer_type" id="ad_customer_type" class="form-control supplier select2" style="width: 100%;">
                            
                          <option value="">Select Type</option>
                          <option value="Individual">Individual Customer</option>
                          <option value="Combined">Combined</option>
                      </select>
                      <span class="typeerror"></span>
                    </div>
                  </div>
                
                </div>


              </div>

              <div class="col-md-12">
                <br><br>
                

                <div class="col-md-6">
                
                  <div class="col-sm-12">
                    <h4 class="col-sm-4 text-right">Received Amount</h4>

                    <div class="col-sm-8">
                     <input name="adv_paidAmt" type="number" class="form-control" id="adv_paidAmt" placeholder="Enter paid amount" ng-model="adv_paidAmt">

                    </div>
                  </div>
                  <div class="col-sm-12">
                    <div class="form-group">
                      <h4 class="col-sm-4 text-right">Remarks</h4>

                      <div class="col-sm-8">

                        <input type="text" class="form-control" id="adv_remark">
                         
                      </div>

                    </div>
                  </div>

                </div>
                <div class="col-md-6">
                  
                  <div class="col-sm-12">
                    <div class="col-sm-6 text-right">
                      <label for="adv_paymentrating" class="control-label"><h4>Customer Payment Rating:</h4></label>
                    </div>
                    <div class="col-sm-6">
                      <input id="adv_paymentrating" name="adv_paymentrating" ng-model="adv_paymentrating" class="rating rating-loading" data-min="0" data-max="5" data-step="1" data-size="xs" data-show-clear="false" data-show-caption="false">
                    </div>
                  </div>

                  <div class="col-sm-12">
                    <h4 class="col-sm-3 text-right">Remarks:</h4>

                    <div class="col-sm-9">
                     <input name="adv_feedback" type="text" class="form-control" id="adv_feedback" placeholder="Enter remarks for this payment" ng-model="com_feedback">

                    </div>
                  </div>

                </div>

              </div>
              <div class="col-md-12">
                <br><br>

                <div class="col-sm-4"></div>

                <button type="button" class="btn btn-success col-sm-4" id="createinvoice"><i class="fa fa-check"></i> Submit</button>

                
              </div>


            </uib-tab>

          </uib-tabset>
        </div>
        
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <!-- Table row -->
      
      <!-- /.row -->

      <div class="row" ng-show="showCollect">
        
        <div class="col-md-12">
          
          <div class="col-md-6">
            <h4 class="col-sm-12 text-center text-green">Amount to Pay: <span ng-bind="collectingamt"></span> TK</h4>
            <hr>
            <div class="col-sm-12">
              <h4 class="col-sm-5 text-right">Paid Amount</h4>

              <div class="col-sm-7">
               <input name="paidAmt" type="number" class="form-control" id="paidAmt" placeholder="Enter paid amount" ng-model="paidAmt" ng-keyup="setPaidAmt(paidAmt);">

              </div>
            </div>
            <div class="col-sm-12">
              <h4 class="col-sm-5 text-right">Paying Date</h4>
              <div class="col-sm-7">
                <div class="form-group">
                  <div class="input-group date">
                         <div class="input-group-content">
                           <input type="text" datefield name="scheduledate" class="form-control" ng-model="paydate" readonly="readonly" style="cursor:pointer;" required autocomplete="off">
                    </div>
                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-sm-12">
              <h4 class="col-sm-5 text-right">Remaining Due</h4>
              <h4 class="col-sm-7"> {{ remainingDue }} TK</h4>
            </div>

            <div class="col-sm-12" ng-show="remainingDue>0">
              <div>

                <h4 class="col-sm-5 text-right">For remaining due:</h4>
                <div class="form-group col-sm-7">
                  <label>
                    <input type="radio" name="shift_to" class="flat-red shift_to" id="adjusttonext" value="nextpay">
                    Adjust to next payment
                  </label>
                  <label>
                    <input type="radio" name="shift_to" class="flat-red shift_to" value="newshedule">
                    Create new schedule
                  </label>
                </div>
                  
              </div>

              <div class="newSchedule" style="display: none;"> 
                <h4 class="col-sm-5 text-right">Next Paying Date:</h4>
                <div class="col-sm-7">
                  <div class="form-group" show-errors>
                    <div class="input-group date">
                           <div class="input-group-content">
                            <input type="text" datefield name="scheduledate" class="form-control" ng-model="nextpaydate" readonly="readonly" style="cursor:pointer;" required id="nextpaydate">
                      </div>
                      <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                    </div>
                  </div>
                </div>

              </div>
              
            </div>

            <div class=" col-sm-12">
              <br>
              <br>
              <h4 class="col-sm-5"></h4>
              <button id="submitcollectionbtn" class="col-sm-7 btn btn-success btn-sm" ng-disabled="remainingDue<0" ng-click="submitCollection()">Submit</button>
              
            </div>
            

            

          </div>
          <div class="col-md-6">
            
            <div class="col-sm-12">
              <div class="col-sm-6 text-right">
                <label for="behavior" class="control-label"><h4>Customer Payment Rating:</h4></label>
              </div>
              <div class="col-sm-6">
                <input id="paymentrating" name="payment" ng-model="fullpayrating" ng-change="applyRating()" class="rating rating-loading" data-min="0" data-max="5" data-step="1" data-size="xs" data-show-clear="false" data-show-caption="false">
              </div>
            </div>

            <div class="col-sm-12">
              <h4 class="col-sm-3 text-right">Remarks:</h4>

              <div class="col-sm-9">
               <input name="feedback" type="text" class="form-control" id="feedback" placeholder="Enter remarks for this payment" ng-model="feedback">

              </div>
            </div>

          </div>

        </div>

        
      </div>
      <!-- /.row -->

      <!-- this row will not appear when printing -->
      <div class="row no-print">
        <div class="col-xs-12">

        
        </div>
      </div>
    </section>
    <!-- /.content -->
    <div class="clearfix"></div>
  </div>
  <!-- /.content-wrapper -->

<style type="text/css">
  
 .mobileornname .easy-autocomplete{
  width:100% !important
}

.mobileornname .easy-autocomplete input{
  width: 100%;
}

.mobileornname .form-wrapper{
  width: 500px;
}

</style>


  <!-- footer -->
  <? print $this->fetch('/ui_includes/footer.phtml'); ?>

  <!-- Control Sidebar -->
  <? print $this->fetch('/ui_includes/control-sidebar.phtml'); ?>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->


<!-- Bootstrap 3.3.6 -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>bootstrap/js/bootstrap.min.js"></script>


<!-- bootstrap-confirmation.min.js -->

<script src="<?php echo htmlspecialchars($baseUrl); ?>bootstrap/js/bootstrap-confirmation.min.js"></script>


<!-- FastClick -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>dist/js/app.min.js"></script>
<!-- sidebar toggle -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>dist/js/sidebar-toggle.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>dist/js/demo.js"></script>

<!-- autocomplete -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>dist/js/jquery.easy-autocomplete.js"></script>

<!-- Select2 -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/select2/select2.full.min.js"></script>

<!-- DataTables -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/datatables/dataTables.bootstrap.min.js"></script>
<!-- DataTables end-->

<!-- iCheck 1.0.1 -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/iCheck/icheck.min.js"></script>

<!-- jQuery Confirmation -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>dist/js/jquery-confirm.min.js"></script>

<!-- rating -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/rating/js/star-rating.min.js" type="text/javascript"></script>
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/rating/themes/krajee-svg/theme.min.js"></script>


<script>

  // define variables

  var invoiceId = null;
  var invoice = null;

  var amount_to_pay = null;
  var amount_received = null;
  var total_due = null;
  var remaining_due = null;
  var amount_paid = null;

  var mobile = null;
  var name = null;
  var address = null;
  var email = null;

  var paymentDate = null;
  var amountToPay = null;
  var selectedOpt = null;
  var selectedSchedule = null;
  


  // var amountToPay = 0;


  var app = angular.module('app', ['ui.bootstrap']);

  app.controller('schedulescontroller', function($scope, $http) {

            $scope.showCollect = false;
            $scope.adjustable = false;



    // $scope.onReset = function(){
    //     $scope.firstName = "";
    //     $scope.lastName = "";
    // }


            $scope.setSchedules =  function(data, nonpaid) {
              
              $scope.schedules = data;


              if (nonpaid>1) {

                jQuery("#adjusttonext").removeAttr('disabled').iCheck('update');
              
              } else jQuery("#adjusttonext").attr('disabled', true).iCheck('update');

            }

            $scope.collect = function(data) {

              amountToPay = data.amount;
              $scope.amountToPay = data.amount;

              selectedSchedule = data.id;


              $scope.showCollect = true;
              
              $scope.collectingamt = data.amount;

              // collectTouched = true;

              

            }

            $scope.setPaidAmt = function(paidAmt) {
              $scope.remainingDue = amountToPay - paidAmt;
            }

            $scope.submitCollection = function() {
              
              var inverrors = new Array();


              if (!$("#paymentrating").val()) {
                inverrors.push(" <b>Payment Rating</b>")
              }

              if (!$scope.paidAmt) {

                inverrors.push(" <b>Paid Amount</b>")
              
              }

              if (!$scope.paydate) {

                inverrors.push(" <b>Payment Date</b>")
              
              }

              
              if (inverrors[0]) {

                $.alert("<h4 class='text-red'>Please give the following informations: </h4> "+inverrors )
              
              } else {

                

                if ($scope.paidAmt<amountToPay) {

                  if(selectedOpt=='nextpay'){
                    //process for nextpay adjust

                    $("#submitcollectionbtn").attr("disabled", "disabled");
                    $("#submitcollectionbtn").html("Processing...");
                    
                    //request process start
                      var config = {
                        method : 'POST',
                        url : "/public/collection/schedulecollect",
                        data : {
                          'invoiceid'  :       invoiceId, //
                          'scheduleid' :       selectedSchedule, //
                          'type'       :       'nextpay',
                          'paidamount' :       $scope.paidAmt, //
                          'date'       :       $scope.paydate, //
                          'rating'     :       $("#paymentrating").val(), //
                          'feedback'   :       $scope.feedback //

                        }
                      };

                      var request = $http(config);

                      request.then(function (response) {
                        
                        if (response.data.msg=='success') {

                          $.confirm({

                                title: 'Payment Created!',
                                content: 'Continue to View Payment Details.',
                                
                                buttons: {
                                    continue: function () {
                                        // $.alert('Confirmed!');

                                        var url = "/collection/slip/"+response.data.slip;
                                        window.location.replace(url);

                                    }
                                    
                                }
                            });



                        }

                      }),function (error) {
                        alert(error.data);
                      }

                      //processing end

                  } else if (selectedOpt == 'newshedule') {
                    //process for new schedule
                    $("#submitcollectionbtn").attr("disabled", "disabled");
                    $("#submitcollectionbtn").html("Processing...");

                    if (!$scope.nextpaydate) {

                      $.alert("<h4 class='text-red'>Please give the next payment date for remaining due.</h4>")
                    } else {

                      //process for nextpay adjust
                    
                      //request process start
                      var config = {
                        method : 'POST',
                        url : "/public/collection/schedulecollect",
                        data : {
                          'invoiceid'  :       invoiceId, //
                          'scheduleid' :       selectedSchedule, //
                          'type'       :       'newdate',
                          'nextdate'   :       $scope.nextpaydate,//new schedule date
                          'paidamount' :       $scope.paidAmt, //
                          'date'       :       $scope.paydate, //
                          'rating'     :       $("#paymentrating").val(), //
                          'feedback'   :       $scope.feedback //

                        }
                      };

                      var request = $http(config);

                      request.then(function (response) {
                        
                        if (response.data.msg=='success') {

                          $.confirm({

                                title: 'Payment Created!',
                                content: 'Continue to View Payment Details.',
                                
                                buttons: {
                                    continue: function () {
                                        // $.alert('Confirmed!');

                                        var url = "/collection/slip/"+response.data.slip;
                                        window.location.replace(url);

                                    }
                                    
                                }
                            });



                        }

                      }),function (error) {
                        alert(error.data);
                      }

                      //processing end


                    }                    

                  } else {
                     $.alert("<h4 class='text-red'>Please select an option for remaining due.</h4>")
                  }

                } else {
                  //if full amount is paid
                  $("#submitcollectionbtn").attr("disabled", "disabled");
                  $("#submitcollectionbtn").html("Processing...");

                  //request process start
                  var config = {
                    method : 'POST',
                    url : "/public/collection/schedulecollect",
                    data : {
                      'invoiceid'  :       invoiceId, //
                      'scheduleid' :       selectedSchedule, //
                      'type'       :       'full',
                      'paidamount' :       $scope.paidAmt, //
                      'date'       :       $scope.paydate, //
                      'rating'     :       $("#paymentrating").val(), //
                      'feedback'   :       $scope.feedback //

                    }
                  };

                  var request = $http(config);

                  request.then(function (response) {

                    
                    if (response.data.msg=='success') {

                      $.confirm({

                            title: 'Payment Created!',
                            content: 'Continue to View Payment Details.',
                            
                            buttons: {
                                continue: function () {
                                    // $.alert('Confirmed!');

                                    var url = "/collection/slip/"+response.data.slip;
                                    window.location.replace(url);

                                }
                                
                            }
                        });



                    }

                  }),function (error) {
                    alert(error.data);
                  }

                  //processing end


                }

              }

            }


          });

  app.directive('datefield', function () {
              return {
                  restrict: 'AC',
                  link: function (scope, element, attrs) {
                      element.datepicker({ dateFormat: 'dd/mm/yy', autoclose: true, todayHighlight: true });
                  }
              }
          });





  $(document).ready(function() {

//remaingin due section-------------------
    $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
      checkboxClass: 'icheckbox_flat-green',
      radioClass: 'iradio_flat-green'
    });

    $("input[name='shift_to']").on('ifChanged', function(event){

      value = $(this).val();
      selectedOpt = value;

      if (value=='newshedule') {
        $(".newSchedule").show();
      } else {
        $(".newSchedule").hide();
      }

    });

//searching invoice---------------
    var optionsinvoice = {
          url: function(phrase) {
            return "/collection/getinvoiceeasy?phrase=" + phrase + "&format=json";
          },

          getValue: "invoice",
          list: {

            onSelectItemEvent: function() {
 

              invoiceId = $("#invoice").getSelectedItemData().id;
              invoice = $("#invoice").getSelectedItemData().invoice;
              amount_to_pay = $("#invoice").getSelectedItemData().amount_to_pay;
              amount_received = $("#invoice").getSelectedItemData().amount_received;
              total_due = $("#invoice").getSelectedItemData().total_due;
              remaining_due = $("#invoice").getSelectedItemData().remaining_due;
              amount_paid = $("#invoice").getSelectedItemData().amount_paid;

              mobile = $("#invoice").getSelectedItemData().mobile;
              name = $("#invoice").getSelectedItemData().name;
              address = $("#invoice").getSelectedItemData().address;
              email = $("#invoice").getSelectedItemData().email;
              customertype = $("#invoice").getSelectedItemData().type;
              balance = $("#invoice").getSelectedItemData().balance;


              $("#c_name").html(name).trigger("change");
              $("#address").html(address).trigger("change");
              $("#email").html(email).trigger("change");
              $("#mobile").html(mobile).trigger("change");
              $("#total_amt").html(amount_to_pay).trigger("change");
              $("#total_paid").html(amount_received).trigger("change");
              $("#remaining_due").html(remaining_due).trigger("change");

              $("#oldcustomer").show();
              $("#newcustomer").hide();


              if (invoiceId) {
                  jQuery.ajax({

                    url : '/public/collection/getschedules',
                    type : 'post',
                    data : {
                      'invoice' : invoiceId,
                    },
                    success : function(response) {

                      data = JSON.parse(response);


                      if (data.msg=='success') {

                        angular.element(document.getElementById('schedulescontroller')).scope().setSchedules(data.result, data.nonpaid);

                        
                        angular.element(document.getElementById('schedulescontroller')).scope().$apply();

                        // setSchedules();

                      }

                    }
                  });
                }              

            },

            showAnimation: {
              type: "fade", //normal|slide|fade
              time: 200,
              callback: function() {}
            },

            hideAnimation: {
              type: "slide", //normal|slide|fade
              time: 200,
              callback: function() {

                

                
              }
            }
          },
          template: {
              type: "description",
              fields: {
                  description: "name"
              }
          },
          theme: "blue-light",

          


        };
    $("#invoice").easyAutocomplete(optionsinvoice);



    //combined customer section

    var com_customerid = null;

    var mobileornname = {
      url: function(phrase) {
        return "/customer/getcomcustomers?phrase=" + phrase + "&format=json";
      },

      getValue: "mobile",
      list: {

        onSelectItemEvent: function() {


          com_customerid = $("#mobileornname").getSelectedItemData().id;
          mobile = $("#mobileornname").getSelectedItemData().mobile;
          name = $("#mobileornname").getSelectedItemData().name;
          address = $("#mobileornname").getSelectedItemData().address;
          email = $("#mobileornname").getSelectedItemData().email;
          customertype = $("#mobileornname").getSelectedItemData().type;
          balance = $("#mobileornname").getSelectedItemData().balance;
          credit_limit = $("#mobileornname").getSelectedItemData().credit_limit;


          $("#customer_name").html(name).trigger("change");
          $("#c_addr").html(address).trigger("change");
          $("#c_email").html(email).trigger("change");
          $("#c_type").html(customertype).trigger("change");
          $("#c_due").html(balance).trigger("change");
          $("#c_creditlimit").html(credit_limit).trigger("change");

          $("#oldcustomer").show();
          $("#newcustomer").hide();               

        },

        showAnimation: {
          type: "fade", //normal|slide|fade
          time: 200,
          callback: function() {}
        },

        hideAnimation: {
          type: "slide", //normal|slide|fade
          time: 200,
          callback: function() {
              
            if ($("#mobileornname").getItemData(0)== -1) {

             $("#oldcustomer").hide();
             $("#newcustomer").show();

             com_customerid = null;

            }

            
          }
        }
      },
      template: {
          type: "description",
          fields: {
              description: "name"
          }
      },
      theme: "blue-light",

      


    };
    $("#mobileornname").easyAutocomplete(mobileornname);


     $("#comTakepayment").on('click', function () {


      var inverrors = new Array();
      
      if (com_customerid) {

        var com_amount = $("#com_paidAmt").val();

        if (!com_amount) {

          inverrors.push(" <b>Paid Amount</b>")

        }

        var com_date = $("#com_date").val();

        if (!com_date) {
          inverrors.push(" <b>Paying Date</b>")
        }

       if (!$("#com_paymentrating").val()) {
              inverrors.push(" <b>Payment Rating</b>")
        }


        if (inverrors[0]) {

          $.alert("<h4 class='text-red'>Please give the following informations: </h4> "+inverrors )
        
        } else {

              createComPayment(com_customerid);
              $("#comTakepayment").attr('disabled','true');
              $("#comTakepayment").html("Processing...");

        }


      } else {
        //no customer selected


          $.alert("<h4 class='text-red'>Please Select a customer first! </h4> "+inverrors )

        


      }

    });



     function createComPayment(customer_id) {
       
       var com_amount = $("#com_paidAmt").val();

       var com_date = $("#com_date").val();

       var com_rating = $("#com_paymentrating").val();
       var com_feedback = $("#com_feedback").val();


       jQuery.ajax({

              url : '/public/collection/createcompayment',
              type : 'post',
              data : {
                customer_id : customer_id,
                amount :      com_amount,
                date :        com_date,
                rating :     com_rating,
                feedback :       com_feedback
              },
              success : function(data) {

                console.error(data);

                    var returndata = JSON.parse(data);

                    if (returndata.msg=='success') {

                      $.confirm({

                                title: 'Payment Created!',
                                content: 'Continue to View Payment Details.',
                                
                                buttons: {
                                    continue: function () {
                                        // $.alert('Confirmed!');

                                        var url = "/collection/slip/"+returndata.slip;
                                        window.location.replace(url);

                                    }
                                    
                                }
                            });
                    }
                  }
                
        });
     }




} );




</script>


<script>
  
  $('[data-toggle=confirmation]').confirmation({
  rootSelector: '[data-toggle=confirmation]',
  // other options
  });
</script>



<!-- advanced payment -->

<script>

  // define variables

  var adv_customerid = null;

  var adv_mobile = null;
  var adv_name = null;
  var adv_address = null;
  var adv_email = null;
  var adv_customertype = null;
  var adv_balance = null;

  



  $(document).ready(function() {

    var advoptionsmobile = {
          url: function(phrase) {
            return "/customer/getcustomerseasy?phrase=" + phrase + "&format=json";
          },

          getValue: "mobile",
          list: {

            onSelectItemEvent: function() {
 

              adv_customerid = $("#adv_mobile").getSelectedItemData().id;
              adv_mobile = $("#adv_mobile").getSelectedItemData().mobile;
              adv_name = $("#adv_mobile").getSelectedItemData().name;
              adv_address = $("#adv_mobile").getSelectedItemData().address;
              adv_email = $("#adv_mobile").getSelectedItemData().email;
              adv_customertype = $("#adv_mobile").getSelectedItemData().type;
              adv_balance = $("#adv_mobile").getSelectedItemData().balance;


              $("#adv_name").html(adv_name).trigger("change");
              $("#adv_addr").html(adv_address).trigger("change");
              $("#adv_email").html(adv_email).trigger("change");
              $("#adv_type").html(adv_customertype).trigger("change");
              $("#adv_balance").html(adv_balance).trigger("change");

              $("#oldcustomer").show();
              $("#newcustomer").hide();

              if (adv_customertype=='Combined') {
              
                $("#createinvoice").removeClass('btn-success');
                $("#createinvoice").addClass('btn-danger');
                $("#createinvoice").html("Combined Customer!");
                $("#createinvoice").attr('disabled', true);
              
              } else {

                if (adv_balance>=0) {
                  $("#createinvoice").removeClass('btn-danger');
                  $("#createinvoice").addClass('btn-success');
                  $("#createinvoice").html("Take advanced Payment");
                  $("#createinvoice").removeAttr('disabled');
                } else {
                  $("#createinvoice").removeClass('btn-success');
                  $("#createinvoice").addClass('btn-danger');
                  $("#createinvoice").html("Clear customer's due first!");
                  $("#createinvoice").attr('disabled', true);
                }

                
              }



            },

            showAnimation: {
              type: "fade", //normal|slide|fade
              time: 200,
              callback: function() {}
            },

            hideAnimation: {
              type: "slide", //normal|slide|fade
              time: 200,
              callback: function() {
                  
                if ($("#adv_mobile").getItemData(0)== -1) {

                 $("#oldcustomer").hide();
                 $("#newcustomer").show();

                 adv_customerid = null;

                }

                
              }
            }
          },
          template: {
              type: "description",
              fields: {
                  description: "name"
              }
          },
          theme: "blue-light",

          


        };
    $("#adv_mobile").easyAutocomplete(advoptionsmobile);



    // create the bill

    $("#createinvoice").click(function () {

      var inverrors = new Array();
      
      if (!adv_customerid) {
        //new customer
        var adv_name = $("#ad_name").val();
        var adv_address = $("#ad_address").val();
        var adv_email = $("#ad_email").val();
        var adv_c_type = $("#ad_customer_type").val();

        var adv_amount = $("#adv_paidAmt").val();

        if (!adv_amount) {

          inverrors.push(" <b>Received Amount</b>")

        }

        if (!adv_name) {
          inverrors.push(" <b>Name</b>")
        }
        if (!adv_address) {
          inverrors.push(" <b>Address</b>")
        }
        if (!adv_c_type) {
          inverrors.push(" <b>Customer Type</b>")
        }

        if (inverrors[0]) {

          $.alert("<h4 class='text-red'>Please give the following informations: </h4> "+inverrors )
        
        } else {

              createInvoice(null);
              $("#createinvoice").attr('disabled','true');

        }


      } else {
        //already customer

        var adv_amount = $("#adv_paidAmt").val();

        if (!adv_amount) {

          $.alert("<h4 class='text-red'>Please give the Received Amount </h4> "+inverrors )

        } else {

          createInvoice(adv_customerid);
          $("#createinvoice").attr('disabled','true');
        }


      }

    });

    function createInvoice(customer_id) {
      
      if (!customer_id) {
        //for new customer

        $("#createinvoice").attr("disabled", "disabled");
        $("#createinvoice").html("Processing...");

        var mobile = $("#adv_mobile").val();
        var name = $("#ad_name").val();
        var address = $("#ad_address").val();
        var email = $("#ad_email").val();
        var c_type = $("#ad_customer_type").val();

        var amount = $("#adv_paidAmt").val();
        var remark = $("#adv_remark").val();

        jQuery.ajax({

              url : '/public/collection/createadvanceinvoice',
              type : 'post',
              data : {
                type :        'new',
                mobile :      mobile,
                name :        name,
                address :     address,
                email :       email,
                c_type :      c_type,
                amount :      amount,
                remark :      remark
                
              },
              success : function(data) {

                    var returndata = JSON.parse(data);

                    if (returndata.reply=='done') {

                      $.confirm({

                          title: 'Advance Payment Created!',
                          content: 'Continue to View Advance Slip',
                          
                          buttons: {
                              continue: function () {
                                  // $.alert('Confirmed!');

                                  var url = "/collection/advanceslip/"+returndata.invoice;
                                  window.location.replace(url);

                              }
                              
                          }
                      });
                    }
                  }
                
        });

      
      } else {
        //for old customer

        $("#createinvoice").attr("disabled", "disabled");
        $("#createinvoice").html("Processing...");

        var amount = $("#adv_paidAmt").val();
        var remark = $("#adv_remark").val();

        jQuery.ajax({

              url : '/public/collection/createadvanceinvoice',
              type : 'post',
              data : {
                type :        'old',
                customer :    adv_customerid,
                amount :      amount,
                remark :      remark
              },
              success : function(data) {

                // console.error(data);

                    var returndata = JSON.parse(data);

                    if (returndata.reply=='done') {

                      $.confirm({

                          title: 'Advance Payment Created!',
                          content: 'Continue to View Advance Slip',
                          
                          buttons: {
                              continue: function () {
                                  // $.alert('Confirmed!');

                                  var url = "/collection/advanceslip/"+returndata.invoice;
                                  window.location.replace(url);

                              }
                              
                          }
                      });
                    }
                   
                    

                  }
                
        });

      }


    } //function end


} );


</script>




</body>
</html>