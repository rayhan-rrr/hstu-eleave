<?php

 use App\Helper\Includes\NumberToWord;
 use App\Helper\Includes\BanglaConverter;

  include $this->getTemplatePath().'php_includes/db_conx.php';

  $hasSuccess = '';

  if (isset($_SESSION['success'])) {
      
      $hasSuccess = $_SESSION['success'];

      $_SESSION['success'] = '';
    }  

  
?>


<!DOCTYPE html>
<html>
<head>
  
<? print $this->fetch('/ui_includes/head.phtml'); ?>

<!-- Select2 -->
<link rel="stylesheet" href="<?php echo htmlspecialchars($baseUrl); ?>plugins/select2/select2.min.css">
<style type="text/css">
  .left_child , .right_child{
    border: 1px solid #dddddd;
    margin-bottom: 5%;
    padding-top: 2%;
    padding-left: 1%;
    padding-right: 1%;
    border-radius: 6px;
  }
  .month_input, .serial_range, .withinRange, .individual, .combined{
    display: none;
  }
  .col-md-12.input_box {
    margin-bottom: 4px;
  }

/*label.btn span {
  font-size: 1.5em ;
}*/

label input[type="radio"] ~ i.fa.fa-circle-o{
    color: #c8c8c8;    display: inline;
}
label input[type="radio"] ~ i.fa.fa-dot-circle-o{
    display: none;
}
label input[type="radio"]:checked ~ i.fa.fa-circle-o{
    display: none;
}
label input[type="radio"]:checked ~ i.fa.fa-dot-circle-o{
    color: #7AA3CC;    display: inline;
}
label:hover input[type="radio"] ~ i.fa {
color: #7AA3CC;
}

label input[type="checkbox"] ~ i.fa.fa-square-o{
    color: #c8c8c8;    display: inline;
}
label input[type="checkbox"] ~ i.fa.fa-check-square-o{
    display: none;
}
label input[type="checkbox"]:checked ~ i.fa.fa-square-o{
    display: none;
}
label input[type="checkbox"]:checked ~ i.fa.fa-check-square-o{
    color: #7AA3CC;    display: inline;
}
label:hover input[type="checkbox"] ~ i.fa {
color: #7AA3CC;
}

div[data-toggle="buttons"] label.active{
    color: #7AA3CC;
}

div[data-toggle="buttons"] label {
display: inline-block;
padding: 6px 12px;
margin-bottom: 0;
font-size: 14px;
font-weight: normal;
line-height: 2em;
text-align: left;
white-space: nowrap;
vertical-align: top;
cursor: pointer;
background-color: none;
border: 0px solid 
#c8c8c8;
border-radius: 3px;
color: #c8c8c8;
-webkit-user-select: none;
-moz-user-select: none;
-ms-user-select: none;
-o-user-select: none;
user-select: none;
}

div[data-toggle="buttons"] label:hover {
color: #7AA3CC;
}

div[data-toggle="buttons"] label:active, div[data-toggle="buttons"] label.active {
-webkit-box-shadow: none;
box-shadow: none;
}




</style>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    <? print $this->fetch('/ui_includes/header.phtml'); ?>

  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <? print $this->fetch('/ui_includes/leftpanel.phtml'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

    <!-- Content Header (Page header) -->

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- Horizontal Form -->
        <div class="box box-info">
          <div class="box-header with-border">
            <h3 class="box-title">Product Description:</h3>
          </div>
          <form class="form-horizontal" id="addproductform" role="form" action="/products/new" method="post">
            <?php echo $csrf['field']; ?>
            <div class="box-body">
              <div class="col-md-12">
                <div class="col-md-6 left_part">
                    <!-- category -->
                  <div class="left_child">
                    <div class="form-group <? if(isset($errors['category'])) echo 'has-error' ?> " id="categoryf">
                      <label for="category" class="col-sm-2 control-label">Category</label>
                      <div class="col-sm-10">
                        <select name="category" id="category" required class="form-control select2" style="width: 100%;">
                          <option value="">Select category</option>
                          <?php
                          $sql = "SELECT * FROM `category` WHERE `active`=1;";
                          $result = mysqli_query($db_conx,$sql );
                          $total_cat = mysqli_num_rows($result);
                          if($total_cat>0){
                            while($row = mysqli_fetch_array($result)){
                              echo "<option value=".$row['id'].">".$row['name']."</option>";
                            }
                          }
                          ?>
                        </select>
                        <? if(isset($errors['category'])) { ?>
                          <span class="help-block"><? //echo $errors['password'][0]; ?> Select a category</span>
                        <? } ?>
                      </div>
                    </div>
                    <!-- brand -->
                    <!-- brand -->
                <div class="form-group <? if(isset($errors['brand'])) echo 'has-error' ?>" id="brandf">
                  <label for="brand" class="col-sm-2 control-label">Brands</label>
                  <div class="col-sm-10">
                    <select name="brand" id="brand" required class="form-control select2" style="width: 100%;">
                      <option value="">Select Brand</option>
                      <?php 

                      $sql = "SELECT * FROM `brands` WHERE `active`=1;";
                    $result = mysqli_query($db_conx,$sql );
                    $total_cat = mysqli_num_rows($result);
                    if($total_cat>0){
                      
                      while($row = mysqli_fetch_array($result)){
                        echo "<option value=".$row['id'].">".$row['name']."</option>";
                        }
                      }
                       ?>
                      
                    </select>

                    <? if(isset($errors['brand'])) { ?>
                    <span class="help-block"><? //echo $errors['password'][0]; ?>Select a brand</span>

                    <? } ?>


                  </div>
                </div>
                    <div class="form-group <? if(isset($errors['product_group'])) echo 'has-error' ?>" id="product_groupf">
                      <label for="product_group" class="col-sm-2 control-label">Group</label>
                      <div class="col-sm-10">
                        <select name="product_group" required id="product_group" class="form-control select2" style="width: 100%;">
                          <option value="">Select Group</option>
                          <?php
                          $sql = "SELECT * FROM `product_group` WHERE `is_active`=1;";
                          $result = mysqli_query($db_conx,$sql );
                          $total_cat = mysqli_num_rows($result);
                          if($total_cat>0){
                            while($row = mysqli_fetch_array($result)){
                            echo "<option value=".$row['id'].">".$row['name']."</option>";
                            }
                          }
                          ?>
                        </select>
                        <? if(isset($errors['product_group'])) { ?>
                          <span class="help-block"><? //echo $errors['password'][0]; ?> Select a Product Group</span>
                        <? } ?>
                      </div>
                    </div>
                  </div>

                  <div class="left_child">
                    <div class="form-group <? if(isset($errors['name'])) echo 'has-error' ?>" id="namef">
                      <div class="col-md-12 input_box">
                        <div class="col-sm-4">
                          <label for="name" class="control-label">Product Name</label>
                        </div>
                        <div class="col-sm-8">
                          <input name="name" required type="text" class="form-control" id="name" placeholder="Name the product" value="<? if(isset($old['name'])) echo $old['name']; ?>">
                          <? if(isset($errors['name'])) { ?>
                          <span class="help-block"><? //echo $errors['password'][0]; ?>Name the product</span>
                        <? } ?>
                        </div>
                      </div>
                    </div>
                    <div class="form-group <? if(isset($errors['model_no'])) echo 'has-error' ?>" id="model_nof">  
                      <div class="col-md-12 input_box">
                        <div class="col-sm-3">
                          <label for="name" class="control-label">Model</label>
                        </div>
                        <div class="col-sm-9">
                          <input name="model_no" type="text" class="form-control" id="model_no" placeholder="Name the product" value="<? if(isset($old['model_no'])) echo $old['model_no']; ?>">
                          <? if(isset($errors['model_no'])) { ?>
                          <span class="help-block"><? //echo $errors['password'][0]; ?>Model the product</span>
                        <? } ?>
                        </div>
                      </div>
                    </div>
                    <div class="form-group <? if(isset($errors['code'])) echo 'has-error' ?>" id="pro_codef">
                      <div class="col-md-12 input_box">
                        <div class="col-sm-3">
                          <label for="code" class="control-label">Code</label>
                        </div>
                        <div class="col-sm-9">
                          <input name="code" type="text" class="form-control" id="pro_code" placeholder="Name the product" value="<? if(isset($old['code'])) echo $old['code']; ?>">
                          <? if(isset($errors['code'])) { ?>
                          <span class="help-block"><? //echo $errors['password'][0]; ?>Name the product</span>
                        <? } ?>
                        </div>
                      </div>
                    </div>

                    <div class="form-group <? if(isset($errors['description'])) echo 'has-error' ?>" id="descriptionf">  
                      <div class="col-md-12 input_box">
                        <div class="col-sm-3">
                          <label for="description" class="control-label">Description</label>
                        </div>
                        <div class="col-sm-9">
                          <input name="description" type="text" class="form-control" id="description" placeholder="Name the product" value="<? if(isset($old['description'])) echo $old['description']; ?>">
                          <? if(isset($errors['description'])) { ?>
                          <span class="help-block"><? //echo $errors['password'][0]; ?>Name the product</span>
                        <? } ?>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!--  end left child -->
                  <div  class="left_child col-md-12">
                    <div class="form-group <? if(isset($errors['warranty'])) echo 'has-error' ?>" id="warrantyf">
                      <div class="col-md-12"> Do you have Product Warranty</div>
                      <div class="btn-group btn-group-vertical" data-toggle="buttons">
                        <div class="col-md-6">
                          <label class="btn">
                            <input type="radio" name="warranty" id="warranty" value="yes" style="display: none;"><i class="fa fa-circle-o fa-1x"></i><i class="fa fa-dot-circle-o fa-1x"></i> <span>  Yes</span>
                          </label>
                        </div>
                         <div class="col-md-6">
                            <label class="btn">
                            <input type="radio" name="warranty" id="warranty" value="no" style="display: none;"><i class="fa fa-circle-o fa-1x"></i><i class="fa fa-dot-circle-o fa-1x"></i> <span>  No</span>
                          </label>
                         </div>
                        
                       
                      </div>
                      <div class="col-md-12 month_input">
                        <div class="col-sm-4">
                          <label for="description" class="control-label">warranty Period</label>
                        </div>
                        <div class="col-sm-8">
                          <input name="warranty" type="text" class="form-control" id="sellrate" placeholder="2 month" value="<? if(isset($old['warranty'])) echo $old['warranty']; ?>">
                        </div>
                        
                      </div>
                      
                     
                      
                    </div>
                  
              
                  </div>

                </div>

               
                <!-- close left part -->
                <!-- start right part -->
                <div class="col-md-6 ">
                  
                  <div class="col-md-12 right_child">

                    <div class="col-md-12 input_box">
                      <div class="form-group <? if(isset($errors['buyrate'])) echo 'has-error' ?>" id="buyratef">
                        <div class="col-sm-3">
                          <label for="buyrate" class="control-label">Bye rate</label>
                        </div>
                        <div class="col-sm-9">
                          <input name="buyrate" required type="text" class="form-control" id="buyrate" placeholder="Ex: 100.67" value="<? if(isset($old['buyrate'])) echo $old['buyrate']; ?>">
                          <? if(isset($errors['buyrate'])) { ?>
                                <span class="help-block"><? //echo $errors['password'][0]; ?>Give the purchase price (number) of the product</span>
                            <? } ?>
                        </div>
                      </div>
                    
                      <div class="form-group <? if(isset($errors['wholesalerate'])) echo 'has-error' ?>" id="wholesaleratef">
                        <div class="col-sm-3"  style="margin: 0; padding: 0;">
                          <label for="wholesalerate" class="control-label">Wholesale price</label>
                        </div>
                        <div class="col-sm-9">
                          <input name="wholesalerate" required type="text" class="form-control" id="wholesalerate" placeholder="Ex: 100.67" value="<? if(isset($old['wholesalerate'])) echo $old['wholesalerate']; ?>">
                          <? if(isset($errors['wholesalerate'])) { ?>
                                <span class="help-block"><? //echo $errors['password'][0]; ?>Give the wholesale price numbers</span>
                              <? } ?>
                        </div>
                      </div>
                    
                      <div class="form-group <? if(isset($errors['sell_rate'])) echo 'has-error' ?>" id="sell_ratef">
                        <div class="col-sm-3"   style="margin: 0; padding: 0;">
                           <label for="sell_rate" class="control-label">Sale price</label>
                        </div>
                        <div class="col-sm-9">
                          <input name="sell_rate" required type="text" class="form-control" id="sell_rate" placeholder="Ex: 107" value="<? if(isset($old['sell_rate'])) echo $old['sell_rate']; ?>">
                        </div>
                      </div>

                      <div class="form-group <? if(isset($errors['warehouse'])) echo 'has-error' ?>" id="warehousef">
                        <div class="col-sm-3"   style="margin: 0; padding: 0;">
                           <label for="warehouse" class="control-label">Product location</label>
                        </div>
                        <div class="col-sm-9">
                          <input name="warehouse" type="text" class="form-control" id="warehouse" placeholder="Describe the place where the product is stored" value="<? if(isset($old['warehouse'])) echo $old['warehouse']; ?>">
                        </div>
                      </div>




                  </div>

                  <!-- child end -->



                </div>
                

                <div class="col-md-12 right_child">

                    <div class="form-group <? if(isset($errors['warranty'])) echo 'has-error' ?>" id="warrantyf">

                      <h4>Does this product has serial number?</h4>
                      <div class="col-md-6">
                        <label class="btn active">
                          <input type="radio" name="has_serial" id="has_serial" value="1" style="display: none;"><i class="fa fa-circle-o fa-1x"></i><i class="fa fa-dot-circle-o fa-1x"></i> <span>  Yes</span>
                        </label>
                      </div>
                      <div class="col-md-6">
                           <label class="btn">
                              <input type="radio" name="has_serial" id="has_serial" style="display: none;" value="0"><i class="fa fa-circle-o fa-1x"></i><i class="fa fa-dot-circle-o fa-1x"></i><span> No</span>
                            </label>
                      </div>
                        
                      <!-- chose range format -->

                      <div class="col-md-12 serial_range">
                          <h4>Add Serial Numbers</h4>
                        <div class="col-md-4">
                          <label class=" active">
                            <input type="radio" name="rangeChoice" id="rangeChoice" value="withinRange" style="display: none;"><i class="fa fa-circle-o fa-1x"></i><i class="fa fa-dot-circle-o fa-1x"></i> <span> Serial Within Range</span>
                          </label>
                        </div>
                       <div class="col-md-4">
                           <label class="">
                              <input type="radio" name="rangeChoice" id="rangeChoice" style="display: none;" value="individual"><i class="fa fa-circle-o fa-1x"></i><i class="fa fa-dot-circle-o fa-1x"></i><span> Individual</span>
                            </label>
                       </div>
                       <div class="col-md-4">
                           <label class="">
                              <input type="radio" name="rangeChoice" id="rangeChoice" style="display: none;" value="combined"><i class="fa fa-circle-o fa-1x"></i><i class="fa fa-dot-circle-o fa-1x"></i><span> Combined</span>
                            </label>
                       </div>
                      </div>

                      <!-- range format for SERIAL WITHIN RANGE -->

                      <div class="col-md-12 withinRange">

                        <div class="form-group" id="commonPart">  
                          <div class="col-md-12 input_box">
                            <div class="col-sm-3">
                              <label for="commonPart" class="control-label">Common Part</label>
                            </div>
                            <div class="col-sm-9">
                              <input name="commonPart" type="text" class="form-control" id="commonPart" placeholder="Common Part of the Serials" >
                              
                            </div>
                          </div>
                        </div>


                        <div class="form-group" id="varryingPart">  
                          <div class="col-md-12 input_box">
                            <div class="col-md-4">
                              <label for="varryingPart" class="control-label">Varrying Part</label>
                            </div>
                            <div class="col-md-8">

                              <div class="form-group" class="col-md-6">  
                                
                                <div class="col-md-4">
                                  <label for="varryingPartStart" class="control-label">Start From</label>
                                </div>
                                <div class="col-md-8">
                                  <input name="varryingPartStart" type="text" class="form-control" id="varryingPartStart" placeholder="Common Part of the Serials">
                                  
                                </div>
                               
                              </div>

                              <div class="form-group" class="col-md-6">  
                                
                                <div class="col-md-4">
                                  <label for="varryingPartEnd" class="control-label">End</label>
                                </div>
                                <div class="col-md-8">
                                  <input name="varryingPartEnd" type="text" class="form-control" id="varryingPartEnd" placeholder="Common Part of the Serials">
                                  
                                </div>
                               
                              </div>
                               
                                                          
      
                            </div>
                          </div>
                        </div>
                        
                      </div>

                      <!-- range format for SERIAL WITHIN RANGE  end -->

                      <!-- range format for  INDIVIDUAL SERIAL -->

                      <div class="col-md-12 individual">

                        <div class="box-item" id="itemsform">
                          <div class="col-sm-1" id="itemsl">1.</div>
                          <div class="col-sm-11 invcart" >
                            <input style="margin-right:2px;" type="text" class="col-sm-6" id="item1" placeholder="Serial">
                          
                            <input style="margin-left: :2px;" type="text" class="col-sm-5 itemtotal" id="itemtotal1" placeholder="Remarks">
                          </div>
                        </div>
                        <div class="col-sm-5"></div>
                        <button type="button" id="addnew" class="col-sm-4 btn bg-gray" style="margin-top: 10px;"><b><i class="fa fa-plus"></i> Add More</b></button>
                        <div class="col-sm-5"></div>


                      
                      
                    </div>

                    <!-- range format for  INDIVIDUAL SERIAL  end -->

                    <!-- range format for  Combined SERIAL -->

                    <div class="col-md-12 combined">

                        <div class="form-group" id="commonPart">  
                          <div class="col-md-12 input_box">
                            <div class="col-sm-3">
                              <label for="commonPart" class="control-label">Common Part</label>
                            </div>
                            <div class="col-sm-9">
                              <input name="commonPart" type="text" class="form-control" id="commonPart" placeholder="Common Part of the Serials" >
                              
                            </div>
                          </div>
                        </div>


                        <div class="form-group" id="varryingPart">  
                          <div class="col-md-12 input_box">
                            <div class="col-md-4">
                              <label for="varryingPart" class="control-label">Varrying Part</label>
                            </div>
                            <div class="col-md-8">

                              <div class="form-group" class="col-md-6">  
                                
                                <div class="col-md-4">
                                  <label for="varryingPartStart" class="control-label">Start From</label>
                                </div>
                                <div class="col-md-8">
                                  <input name="varryingPartStart" type="text" class="form-control" id="varryingPartStart" placeholder="Common Part of the Serials">
                                  
                                </div>
                               
                              </div>

                              <div class="form-group" class="col-md-6">  
                                
                                <div class="col-md-4">
                                  <label for="varryingPartEnd" class="control-label">End</label>
                                </div>
                                <div class="col-md-8">
                                  <input name="varryingPartEnd" type="text" class="form-control" id="varryingPartEnd" placeholder="Common Part of the Serials">
                                  
                                </div>
                               
                              </div>
                               
                                                          
      
                            </div>
                          </div>

                          <div class="box-item" id="itemsform">
                            <div class="col-sm-1" id="itemsl">1.</div>
                            <div class="col-sm-11 invcart" >
                              <input style="margin-right:2px;" type="text" class="col-sm-6" id="item1" placeholder="Serial">
                            
                              <input style="margin-left: :2px;" type="text" class="col-sm-5 itemtotal" id="itemtotal1" placeholder="Remarks">
                            </div>
                          </div>
                          <div class="col-sm-5"></div>
                          <button type="button" id="addnew" class="col-sm-4 btn bg-gray" style="margin-top: 10px;"><b><i class="fa fa-plus"></i> Add More</b></button>
                          <div class="col-sm-5"></div>




                        </div>
                        
                      </div>
                  
              
                  </div>



              </div>


              
                <!-- close right child -->

              </div>
            </div>
             <!-- /.box-body -->
              <div class="box-footer">
                
                <button type="submit" id="submitbtn" class="col-sm-10 btn btn-success pull-right"><b>পণ্য তৈরি করুন</b></button>
              </div>
          </form>
        </div>
      </div>
    
    </section>

    <!-- /.content -->

  </div>
  <!-- /.content-wrapper -->





  <!-- footer -->
  <? print $this->fetch('/ui_includes/footer.phtml'); ?>

  <!-- Control Sidebar -->
  <? print $this->fetch('/ui_includes/control-sidebar.phtml'); ?>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>bootstrap/js/bootstrap.min.js"></script>

<!-- bootstrap-confirmation.min.js -->

<script src="<?php echo htmlspecialchars($baseUrl); ?>bootstrap/js/bootstrap-confirmation.min.js"></script>


<!-- FastClick -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>dist/js/app.min.js"></script>
<!-- sidebar toggle -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>dist/js/sidebar-toggle.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>dist/js/demo.js"></script>

<!-- Select2 -->
<script src="<?php echo htmlspecialchars($baseUrl); ?>plugins/select2/select2.full.min.js"></script>

<script>
  
  $('[data-toggle=confirmation]').confirmation({
  rootSelector: '[data-toggle=confirmation]',
  // other options
  });
</script>

<script>

  //for select2
  $(".select2").select2();

  //select2 end
  
  jQuery('#code').change(function () {

      jQuery("#codeWarning").hide();
      jQuery("#checkok").hide();
      
      
      var nocode = "<div class='alert alert-danger alert-dismissible'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button><h4><i class='icon fa fa-ban'></i> Alert!</h4>আপনি কোন কোড প্রদান করেননি</div>"; 
      var notok = "<div class='alert alert-danger alert-dismissible'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button><h4><i class='icon fa fa-ban'></i> Alert!</h4>কোডটি অন্য একটি পণ্যে ব্যাবহার করা হয়েছে।</div>";
      var correct = "<i class='fa fa-check' style='color: green;'></i>";

      var code = jQuery('#code').val();


      if (code=='') {
        jQuery("#codeWarning").html(nocode);
      }
        else {

            jQuery("#codecheckok").hide();
            
            jQuery("#codecheck").show();
    
        jQuery.ajax({
        url : '/public/products/codecheck',
        type : 'post',
        data : {
          code : code
        },
        success : function(data) {
          
              jQuery("#codecheck").hide();
                
                  if(data==0){
                      jQuery("#codeWarning").show();
                      jQuery("#codeWarning").html(notok);
                      
                  }
                  if(data==1){
                      jQuery("#checkok").show();


                  } 
                
              }
          
     });

    }
    
  });

  // jQuery('#submitbtn').click(function () {

  //     var category = jQuery('#category').val();

  //     if (category=='') {
  //       jQuery("#categoryf").addClass("has-error");
  //     }

  //     var brand = jQuery('#brand').val();

  //     if (brand=='') {
  //       jQuery("#brandf").addClass("has-error");
  //     }

  //     var group  = jQuery('#product_group').val();

  //     if (group=='') {
  //       jQuery("#product_groupf").addClass("has-error");
  //     }
  //     var model_no = jQuery('model_no').val();
  //     if (model_no=='') {
  //       jQuery("#model_nof").addClass("has-error");
  //     }
  //     var name = jQuery('#name').val();

  //     if (name=='') {
  //       jQuery("#namef").addClass("has-error");
  //     }

  //     var pro_code = jQuery('#pro_code').val();

  //     if (pro_code=='') {
  //       jQuery("#pro_codef").addClass("has-error");
  //     }

  //     var buyrate = jQuery('#buyrate').val();

  //     if (buyrate=='') {
  //       jQuery("#buyratef").addClass("has-error");
  //     }

  //     var sell_rate = jQuery('#sell_rate').val();

  //     if (sell_rate=='') {
  //       jQuery("#sell_ratef").addClass("has-error");
  //     }

  //     var wholesalerate = jQuery('#wholesalerate').val();

  //     if (wholesalerate=='') {

  //       jQuery("#wholesaleratef").addClass("has-error");
  //     }

  //     var qty = jQuery('#qty').val();
  //     if (qty=='') {
  //       jQuery("#qtyf").addClass("has-error");
  //     }

  //     if (category!='' && brand!='' && name!='' && pro_code!='' && buyrate!='' && sell_rate!='' && model_no!='' && group!='' && qty!='') {
      
  //       jQuery("#addproductform").submit();
      
  //     }

  // });
  $("input[name='warranty']").change(function(){


   if($(this).val()=="yes")
   {
      $(".month_input").show();
   }
   else
   {
       $(".month_input").hide(); 
   }

});

    $("input[name='has_serial']").change(function(){

   if($(this).val()=="1")
   {
      $(".serial_range").show();
   }
   else
   {
       $(".serial_range").hide(); 
   }

});
    $("input[name='rangeChoice']").change(function(){



     if($(this).val()=="withinRange")
     {

        $(".withinRange").show();
        $(".individual").hide(); 
         $(".combined").hide(); 

     } else if($(this).val()=="individual"){

      $(".individual").show();
      $(".withinRange").hide(); 
      $(".combined").hide(); 

     } else if($(this).val()=="combined"){

      $(".combined").show();
      $(".withinRange").hide(); 
      $(".individual").hide(); 

     }

  });


    //draw individual serial input box------------
  var count = 1;
  $('#addnew').click(function () {
    count = count+1;

    var itemsformcon = '<div class="col-sm-1" id="items'+count+'">'+count+'.</div><div class="col-sm-11" ><input style="margin-right:2px;" type="text" class="col-sm-6" id="item'+count+'" placeholder="Serial"><input style="margin-right:2px;" type="text" class="col-sm-5 itmprice" id="itemrate'+count+'" placeholder="Remarks" /></div>';

    $("#itemsform").append($(itemsformcon).on('keyup',{name: count }));

  });

  
</script>

</body>
</html>